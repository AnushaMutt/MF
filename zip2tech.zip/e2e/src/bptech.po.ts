import { browser, by, element } from 'protractor';

export class AppBpTechPage {
  navigateTo(): Promise<unknown> {
    return browser.get(browser.baseUrl) as Promise<unknown>;
  }

  selectdbenv() {
    return element(by.id('dbenv')).getText() as Promise<string>;
  }

  checkTab() {
    return element.all(by.css('#mat-tab-label-0-1 > div')).getText() as Promise<string>;
  }

  searchBpTechkey(column : string) {
    element(by.tagName('input#searchBpTechkey')).sendKeys(column);
  }

  checkBpTechKey() {
    return element(by.id('bptechkey')).getText() as Promise<string>;
  }

  checkService() {
    return element(by.id('service')).getText() as Promise<string>;
  }

  searchService(column : string) {
    return element(by.id('searchService')).sendKeys(column);
  }

  checkBpCode() {
    return element(by.id('bpcode')).getText() as Promise<string>;
  }

  searchBpcode(column : string) {
    return element(by.id('searchBpcode')).sendKeys(column);
  }

  checkProductKey() {
    return element(by.id('productKey')).getText() as Promise<string>;
  }

  searchProductKey(column : string) {
    element(by.tagName('input#searchProductKey')).sendKeys(column);
  }

  filterTable(value : string) {
    element(by.id('filter')).sendKeys(value);
  }

  enterTechkey(column : string) {
    return element(by.id('addTechkey')).sendKeys(column);
  }

  addTechkey() {
    return element(by.id('addTechkey')).getAttribute('value') as Promise<string>;
  }

  enterService(column : string) {
    return element(by.id('addService')).sendKeys(column);
  }

  addService() {
    return element(by.id('addService')).getAttribute('value') as Promise<string>;
  }

  enterBpCode(column : string) {
    return element(by.id('addBpcode')).sendKeys(column);
  }

  addBpCode() {
    return element(by.id('addBpcode')).getAttribute('value') as Promise<string>;
  }

  enterProductKey(column : string) {
    return element(by.id('addProductkey')).sendKeys(column);
  }

  addProductkey() {
    return element(by.id('addProductkey')).getAttribute('value') as Promise<string>;
  }


  checkAddButton() {
    return element(by.id('label')).getText() as Promise<string>;
  }

  addBpTech() {
    return element.all(by.css('div.ui-toast-detail')).getText() as Promise<string>;
  }

}
