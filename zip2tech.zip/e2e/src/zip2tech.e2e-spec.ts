import { AppZip2TechPage } from './zip2tech.po';
import { browser, logging, by, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppZip2TechPage;
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

  beforeEach(() => {
    page = new AppZip2TechPage();
  });

  it('should select dbenv', () => {
    browser.ignoreSynchronization = true;
    page.navigateTo();
    element(by.tagName("mat-select#dbenv")).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'COP-DEV-SITF')).click();
    expect(page.selectdbenv()).toEqual('COP-DEV-SITF');
  });

  it('goto zip2tech tab', () => {
    let elems = element.all(by.css('.mat-tab-label'))
    elems.get(0).click();
    expect(page.checkTab()).toMatch('Zip2Tech')
    //  browser.sleep(3000);
  });

  it('check state drop down', () => {
    browser.ignoreSynchronization = true;
      browser.sleep(1000)
    element(by.id('state')).click();
    expect(page.checkState()).toEqual('STATE');
    //browser.sleep(3000);
  });

  it('search states', () => {
    page.searchState('AK');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'AK')).isPresent).toBeTrue;
    //browser.sleep(3000);
  });

  it('select states', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'AK')).click();
    //browser.sleep(1000);
    expect(page.checkState()).toEqual('AK');
    element(by.tagName('body')).click();
  });

  it('check county drop down', () => {
    element(by.id('county')).click();
    expect(page.checkCounty()).toEqual('COUNTY');
  });

  it('search county', () => {
    page.searchCounty('SITKA');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'SITKA')).isPresent()).toBeTrue;
    //browser.sleep(3000);
  });

  it('select county', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'SITKA')).click();
    expect(page.checkCounty()).toEqual('SITKA');
    // browser.sleep(8000);
    element(by.tagName('body')).click();
  });

  it('check service drop down', () => {
    element(by.tagName('body')).click();
    element(by.id('service')).click();
    expect(page.checkService()).toEqual('SERVICE');
    //browser.sleep(3000);
  });

  it('search service', () => {
    page.searchService('AUDIO');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'AUDIO')).isPresent).toBeTrue;
    //browser.sleep(3000);
  });

  it('select service', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'AUDIO')).click();
    expect(page.checkService()).toEqual('AUDIO');
    //browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('check techkey drop down', () => {
    element(by.id('techkey')).click();
    expect(page.checkTechkey()).toEqual('TECHKEY');
  });

  it('search techkey', () => {
    page.searchTechkey('CARCON');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'CARCON')).isPresent).toBeTrue;
    //browser.sleep(3000);
  });

  it('select techkey', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'CARCON')).click();
    expect(page.checkTechkey()).toEqual('CARCON');
    //browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('enter zip code', () => {
    page.enterZipcode('99835');
    // browser.sleep(5000)
    expect(page.checkZipcode()).toEqual('99835');
    //browser.sleep(3000);
  });

  it('click search button', () => {
    element(by.tagName('body')).click();
    element(by.id('search')).click();
    expect(element(by.tagName('ngx-datatable')).isPresent).toBeTrue;
    //browser.sleep(3000);
  });

  it('search results', () => {
    expect(element(by.tagName('ngx-datatable')).isPresent).toBeTrue;
  });

  it('add button', () => {
    element(by.tagName('body')).click();
    expect(page.checkAddButton()).toEqual('Add New');
  });

  it('click add button', () => {
    element(by.tagName('body')).click();
    element(by.id('label')).click();
    expect(element(by.id('addLabel')).isPresent).toBeTrue;
    //  browser.sleep(3000);
  });

  it('enter value for language', () => {
    element(by.tagName('body')).click();
    element(by.id('languageValue')).click();
    page.enterLanguage('EN');
    expect(page.addLanguage()).toEqual('EN');
    element(by.tagName('body')).click();
    // browser.sleep(3000);
  });

  it('enter value for service', () => {
    element(by.tagName('body')).click();
    element(by.id('addService')).click();
    page.enterService('AUDIO');
    expect(page.addService()).toEqual('AUDIO');
    element(by.tagName('body')).click();
    // browser.sleep(3000);
  });

  it('enter value for techkey', () => {
    element(by.tagName('body')).click();
    element(by.id('addTechkey')).click();
    page.enterTechkey('GSM5');
    expect(page.addTechkey()).toEqual('GSM5');
    element(by.tagName('body')).click();
    // browser.sleep(3000);
  });

  it('select states', () => {
    browser.ignoreSynchronization = true;
    element(by.tagName('body')).click();
    element(by.id('addSatate')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'AK')).click();
    expect(page.addState()).toEqual('AK');
    //browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('select parent id', () => {
    browser.ignoreSynchronization = true;
    element(by.tagName('body')).click();
    element(by.id('addParentId')).click();
    element(by.cssContainingText('mat-option .mat-option-text', '5')).click();
    expect(page.addParent()).toEqual('5');
    //browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('select county', () => {
    browser.ignoreSynchronization = true;
    element(by.tagName('body')).click();
    element(by.id('addCounty')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'ACCOMACK')).click();
    expect(page.addCounty()).toEqual('ACCOMACK');
    //browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('enter value for zipcode', () => {
    element(by.tagName('body')).click();
    page.addZipcode('99835');
    // browser.sleep(5000)
    expect(page.getZipcode()).toEqual('99835');
    element(by.tagName('body')).click();
    // browser.sleep(3000);
  });

  it('add zip2tech', () => {
    element(by.tagName('body')).click();
    element(by.id('addButton')).click();
    expect(page.addZip2Tech()).toMatch('Zip2Tech has been added successfully');
    browser.sleep(3000);
  });

  // afterEach(async () => {
  //   // Assert that there are no errors emitted from the browser
  //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
  //   expect(logs).not.toContain(jasmine.objectContaining({
  //     level: logging.Level.SEVERE,
  //   } as logging.Entry));
  // });
});
