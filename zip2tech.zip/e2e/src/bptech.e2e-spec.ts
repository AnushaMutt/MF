import { AppBpTechPage } from './bptech.po';
import { browser, logging, by, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppBpTechPage;
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

  beforeEach(() => {
    page = new AppBpTechPage();
  });

  it('should select dbenv', () => {
    browser.ignoreSynchronization = true;
    page.navigateTo();
    element(by.tagName("mat-select#dbenv")).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'COP-DEV-SITF')).click();
    expect(page.selectdbenv()).toEqual('COP-DEV-SITF');
  });

  it('goto bptech tab', async () => {
    let elems = element.all(by.css('.mat-tab-label'))
    elems.get(1).click();
    expect(page.checkTab()).toMatch('BPTech')
  });

  it('check techkey drop down', () => {
    element(by.id('bptechkey')).click();
    expect(page.checkBpTechKey()).toEqual('TECHKEY');
    //browser.sleep(3000);
  });

  it('search techkey', () => {
    page.searchBpTechkey('CDMA');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'CDMA')).isPresent).toBeTrue;
    // browser.sleep(3000);
  });

  it('select techkey value', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'CDMA')).click();
    // browser.sleep(5000);
    expect(page.checkBpTechKey()).toEqual('CDMA');
    element(by.tagName('body')).click();
  });

  it('check service drop down', () => {
    element(by.tagName('body')).click();
    element(by.id('service')).click();
    expect(page.checkService()).toEqual('SERVICE');
    // browser.sleep(3000);
  });

  it('search service', () => {
    page.searchService('NTHS');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'NTHS')).isPresent).toBeTrue;
    // browser.sleep(3000);
  });

  it('select service', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'NTHS')).click();
    expect(page.checkService()).toEqual('NTHS');
    element(by.tagName('body')).click();
  });

  it('check bpcode drop down', () => {
    element(by.tagName('body')).click();
    element(by.id('bpcode')).click();
    expect(page.checkBpCode()).toEqual('BPCODE');
    //browser.sleep(3000);
  });

  it('search bpcode', () => {
    page.searchBpcode('CARCON');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'CARCON')).isPresent).toBeTrue;
    // browser.sleep(3000);
  });

  it('select bpcode', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'CARCON')).click();
    expect(page.checkBpCode()).toEqual('CARCON');
    // browser.sleep(1000);
    element(by.tagName('body')).click();
  });

  it('check productKey drop down', () => {
    element(by.tagName('body')).click();
    element(by.id('productKey')).click();
    expect(page.checkProductKey()).toEqual('PRODUCT KEY');
  });

  it('search productKey', () => {
    page.searchProductKey('HOTSPOT');
    expect(element(by.cssContainingText('mat-option .mat-option-text', 'HOTSPOT')).isPresent).toBeTrue;
    //browser.sleep(3000);
  });

  it('select productKey', () => {
    browser.ignoreSynchronization = true;
    element(by.cssContainingText('mat-option .mat-option-text', 'HOTSPOT')).click();
    expect(page.checkProductKey()).toEqual('HOTSPOT');
    element(by.tagName('body')).click();
  });

  it('click search button', () => {
    element(by.tagName('body')).click();
    element(by.id('searchBptech')).click();
    expect(element(by.tagName('ngx-datatable')).isPresent).toBeTrue;
    // browser.sleep(5000);
  });

  it('search results', () => {
    expect(element(by.tagName('ngx-datatable')).isPresent).toBeTrue;
  });

  it('add button', () => {
    element(by.tagName('body')).click();
    expect(page.checkAddButton()).toEqual('Add New');
  });

  it('click add button', () => {
    element(by.tagName('body')).click();
    element(by.id('label')).click();
    expect(element(by.id('addLabel')).isPresent).toBeTrue;
    // browser.sleep(8000);
  });

  it('enter value for tech key', () => {
    element(by.tagName('body')).click();
    element(by.id('addTechkey')).click();
    page.enterTechkey('CDMA');
    // browser.sleep(5000);
    element(by.tagName('body')).click();
    expect(page.addTechkey()).toEqual('CDMA');
    element(by.tagName('body')).click();
    // browser.sleep(3000);
  });

  it('enter value for service', () => {
    element(by.tagName('body')).click();
    element(by.id('addService')).click();
    page.enterService('AUDIO');
    expect(page.addService()).toEqual('AUDIO');
    element(by.tagName('body')).click();
    // browser.sleep(8000);
  });

  it('enter value for bpcode', () => {
    element(by.tagName('body')).click();
    element(by.id('addBpcode')).click();
    page.enterBpCode('CO');
    expect(page.addBpCode()).toEqual('CO');
    element(by.tagName('body')).click();
    // browser.sleep(8000);
  });

  it('enter value for product key', () => {
    element(by.tagName('body')).click();
    element(by.id('addProductkey')).click();
    page.enterProductKey('HOTSPOT');
    expect(page.addProductkey()).toEqual('HOTSPOT');
    element(by.tagName('body')).click();
    // browser.sleep(8000);
  });

  it('add bptech', () => {
    element(by.tagName('body')).click();
    element(by.id('addButton')).click();
    expect(page.addBpTech()).toMatch('BPTech has been added successfully')
    browser.sleep(3000);
  });

  // afterEach(async () => {
  //   // Assert that there are no errors emitted from the browser
  //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
  //   expect(logs).not.toContain(jasmine.objectContaining({
  //     level: logging.Level.SEVERE,
  //   } as logging.Entry));
  // });
});
