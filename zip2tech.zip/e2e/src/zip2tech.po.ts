import { browser, by, element } from 'protractor';
import { __values } from 'tslib';

export class AppZip2TechPage {
  navigateTo(): Promise<unknown> {
    return browser.get(browser.baseUrl) as Promise<unknown>;
  }

  selectdbenv() {
    return element(by.id('dbenv')).getText() as Promise<string>;
  }

  checkTab() {
    return element.all(by.css('#mat-tab-label-0-0 > div')).getText() as Promise<string>;
  }

  checkState() {
    return element(by.id('state')).getText() as Promise<string>;
  }

  searchState(column: string) {
    return element(by.id('searchState')).sendKeys(column);
  }

  checkCounty() {
    return element(by.id('county')).getText() as Promise<string>;
  }

  searchCounty(column: string) {
    element(by.tagName('input#searchCounty')).sendKeys(column);
  }

  checkService() {
    return element(by.id('service')).getText() as Promise<string>;
  }

  searchService(column: string) {
    return element(by.id('searchService')).sendKeys(column);
  }

  checkTechkey() {
    return element(by.id('techkey')).getText() as Promise<string>;
  }

  searchTechkey(column: string) {
    element(by.tagName('input#searchTechkey')).sendKeys(column);
  }

  checkZipcode() {
    return element(by.tagName('textarea#zipCode')).getAttribute('value') as Promise<string>;
  }

  enterZipcode(column: string) {
    return element(by.id('zipCode')).sendKeys(column);
  }

  filterTable(value: string) {
    element(by.id('filter')).sendKeys(value);
  }

  searchLanguage(column: string) {
    return element(by.id('language')).sendKeys(column);
  }

  checkAddButton() {
    return element(by.id('label')).getText() as Promise<string>;
  }

  enterLanguage(column: string) {
    return element(by.id('languageValue')).sendKeys(column);
  }

  addLanguage() {
    return element(by.tagName('input#languageValue')).getAttribute('value') as Promise<string>;
  }

  enterService(column: string) {
    return element(by.id('addService')).sendKeys(column);
  }

  addService() {
    return element(by.tagName('input#addService')).getAttribute('value') as Promise<string>;
  }

  enterTechkey(column: string) {
    return element(by.id('addTechkey')).sendKeys(column);
  }

  addTechkey() {
    return element(by.tagName('input#addTechkey')).getAttribute('value') as Promise<string>;
  }

  addState() {
    return element(by.id('addSatate')).getText() as Promise<string>;
  }

  addParent() {
    return element(by.id('addParentId')).getText() as Promise<string>;
  }

  addCounty() {
    return element(by.id('addCounty')).getText() as Promise<string>;
  }

  addZipcode(column: string) {
    return element(by.id('addZips')).sendKeys(column);
  }

  getZipcode() {
    return element(by.tagName('input#addZips')).getAttribute('value') as Promise<string>;
  }

  addZip2Tech() {
    return element.all(by.css('div.ui-toast-detail')).getText() as Promise<string>;
  }

}
