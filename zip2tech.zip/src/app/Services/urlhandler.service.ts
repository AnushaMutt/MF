import { Injectable } from '@angular/core';
import { environmentLocal } from '../../environments/environmentLocal';
import { environmentSit1 } from '../../environments/environmentSit1';
import { environmentTst } from '../../environments/environmentTst';
import { environment } from '../../environments/environment';

@Injectable()
export class URLHandlerService {

    readonly HTTP_URL_ADMIN: string;
    readonly HTTP_URL_REPORT: string;
    readonly HTTP_URL_ACTION: string;
    readonly HTTP_URL_TOOLS: string;
	readonly HTTP_URL_APIFULL: string;
    readonly HTTP_URL_TRANSACTION: string;
    readonly HTTP_URL_SERVICERATEPLANWIZARD: string;
    readonly HTTP_URL_WIZARD: string;
    readonly HTTP_URL_USER_INQUIRY: string;
	readonly HTTP_URL_CARRIER: string;
    readonly HTTP_URL_MULE: string;
    readonly HTTP_URL_BALANCE_INQUIRY: string;
    readonly HTTP_URL_INQUIRE_SUB: string;
    readonly HTTP_URL_VIEWAID:string;
    readonly HTTP_URL_SERVICEPLANVIEW:string;
    readonly HTTP_URL_MIRRORSERVICEPLANWIZARD:string;
    readonly HTTP_URL_CARRIERMAINTENANCEWIZARD:string;
    readonly HTTP_URL_RETAILSTOREWIZARD:string;
    readonly RETAILSTOREWIZARD_DATABASE:any;
    readonly HTTP_URL_RETAILTRAITANALYSIS:string;
    readonly HTTP_URL_CARRIEROUTAGE: string;
	readonly HTTP_URL_USER_REPORTING: string;
    readonly HTTP_URL_THROTTLE_TRANS : string;
	readonly HTTP_URL_PCRF_TRANS : string;
	readonly HTTP_URL_DB2_IG_VIEW: string;
	readonly HTTP_URL_DB2IG_MAINTENANCE: string;
	readonly HTTP_URL_IG_CONFIG: string;
	readonly HTTP_URL_IG_CONFIG_MAINTENANCE: string;
	readonly HTTP_URL_ZIP2TECH_MAINTENANCE: string;
	readonly HTTP_URL_CARRIER_ZONES_DEPLOYMENT: string

    constructor() {
		if(window && window.location && window.location.href && window.location.href.split('/')[2] && window.location.href.split('/')[2].indexOf('local') > -1){
		   this.HTTP_URL_APIFULL = environmentLocal.HTTP_URL_APIFULL;
		   this.HTTP_URL_ADMIN = environmentLocal.HTTP_URL_ADMIN;
		   this.HTTP_URL_REPORT = environmentLocal.HTTP_URL_REPORT;
		   this.HTTP_URL_ACTION = environmentLocal.HTTP_URL_ACTION;
		   this.HTTP_URL_TOOLS = environmentLocal.HTTP_URL_TOOLS;
		   this.HTTP_URL_USER_INQUIRY = environmentLocal.HTTP_URL_USER_INQUIRY;
		   this.HTTP_URL_TRANSACTION = environmentLocal.HTTP_URL_TRANSACTION;
		   this.HTTP_URL_SERVICERATEPLANWIZARD = environmentLocal.HTTP_URL_SERVICERATEPLANWIZARD; 
		   this.HTTP_URL_CARRIER = environmentLocal.HTTP_URL_CARRIER; 
		   this.HTTP_URL_WIZARD = environmentLocal.HTTP_URL_WIZARD;
		   this.HTTP_URL_SERVICEPLANVIEW = environmentLocal.HTTP_URL_SERVICEPLANVIEW;
		   this.HTTP_URL_MIRRORSERVICEPLANWIZARD = environmentLocal.HTTP_URL_MIRRORSERVICEPLANWIZARD;
		   this.HTTP_URL_CARRIERMAINTENANCEWIZARD = environmentLocal.HTTP_URL_CARRIERMAINTENANCEWIZARD;
		   this.HTTP_URL_RETAILSTOREWIZARD = environmentLocal.HTTP_URL_RETAILSTOREWIZARD;
		   this.RETAILSTOREWIZARD_DATABASE = environmentLocal.RETAILSTOREWIZARD_DATABASE;
		   this.HTTP_URL_RETAILTRAITANALYSIS = environmentLocal.HTTP_URL_RETAILTRAITSANALYSIS;
		   this.HTTP_URL_CARRIEROUTAGE = environmentLocal.HTTP_URL_CARRIEROUTAGE;
		   this.HTTP_URL_USER_REPORTING = environmentLocal.HTTP_URL_USER_REPORTING;
		   this.HTTP_URL_THROTTLE_TRANS = environmentLocal.HTTP_URL_THROTTLE_TRANS;
		   this.HTTP_URL_MULE = environmentLocal.HTTP_URL_MULE;
		   this.HTTP_URL_BALANCE_INQUIRY = environmentLocal.HTTP_URL_BALANCE_INQUIRY;
		   this.HTTP_URL_PCRF_TRANS = environmentLocal.HTTP_URL_PCRF_TRANS;
		   this.HTTP_URL_DB2_IG_VIEW = environmentLocal.HTTP_URL_DB2_IG_VIEW;
		   this.HTTP_URL_DB2IG_MAINTENANCE = environmentLocal.HTTP_URL_DB2_IG_MAINTENANCE;
		   this.HTTP_URL_IG_CONFIG = environmentLocal.HTTP_URL_IG_CONFIG;
		   this.HTTP_URL_IG_CONFIG_MAINTENANCE = environmentLocal.HTTP_URL_IG_CONFIG_MAINTENANCE;
		   this.HTTP_URL_ZIP2TECH_MAINTENANCE = environmentLocal.HTTP_URL_ZIP2TECH_MAINTENANCE
		   this.HTTP_URL_CARRIER_ZONES_DEPLOYMENT = environmentLocal.HTTP_URL_CARRIER_ZONES_DEPLOYMENT;
		   sessionStorage.setItem('ENVIRONMENT', "LOCAL");
		}
		else if(window && window.location && window.location.href && window.location.href.split('/')[2] && window.location.href.split('/')[2].indexOf('sit') > -1){
		   this.HTTP_URL_APIFULL = environmentSit1.HTTP_URL_APIFULL;
		   this.HTTP_URL_ADMIN = environmentSit1.HTTP_URL_ADMIN;
		   this.HTTP_URL_REPORT = environmentSit1.HTTP_URL_REPORT;
		   this.HTTP_URL_ACTION = environmentSit1.HTTP_URL_ACTION;
		   this.HTTP_URL_TOOLS = environmentSit1.HTTP_URL_TOOLS;
		   this.HTTP_URL_USER_INQUIRY = environmentSit1.HTTP_URL_USER_INQUIRY;
		   this.HTTP_URL_TRANSACTION = environmentSit1.HTTP_URL_TRANSACTION;
		   this.HTTP_URL_SERVICERATEPLANWIZARD = environmentSit1.HTTP_URL_SERVICERATEPLANWIZARD; 
		   this.HTTP_URL_CARRIER = environmentSit1.HTTP_URL_CARRIER; 
		   this.HTTP_URL_WIZARD = environmentSit1.HTTP_URL_WIZARD;
		   this.HTTP_URL_SERVICEPLANVIEW = environmentSit1.HTTP_URL_SERVICEPLANVIEW;
		   this.HTTP_URL_MIRRORSERVICEPLANWIZARD = environmentSit1.HTTP_URL_MIRRORSERVICEPLANWIZARD;
		   this.HTTP_URL_CARRIERMAINTENANCEWIZARD = environmentSit1.HTTP_URL_CARRIERMAINTENANCEWIZARD;
		   this.HTTP_URL_RETAILSTOREWIZARD = environmentSit1.HTTP_URL_RETAILSTOREWIZARD;
		   this.RETAILSTOREWIZARD_DATABASE = environmentSit1.RETAILSTOREWIZARD_DATABASE;
		   this.HTTP_URL_RETAILTRAITANALYSIS = environmentSit1.HTTP_URL_RETAILTRAITSANALYSIS;
		   this.HTTP_URL_CARRIEROUTAGE = environmentSit1.HTTP_URL_CARRIEROUTAGE;
		   this.HTTP_URL_USER_REPORTING = environmentSit1.HTTP_URL_USER_REPORTING;
		   this.HTTP_URL_THROTTLE_TRANS = environmentSit1.HTTP_URL_THROTTLE_TRANS;
		   this.HTTP_URL_MULE = environmentSit1.HTTP_URL_MULE;
		   this.HTTP_URL_BALANCE_INQUIRY = environmentSit1.HTTP_URL_BALANCE_INQUIRY;
		   this.HTTP_URL_PCRF_TRANS = environmentSit1.HTTP_URL_PCRF_TRANS;
		   this.HTTP_URL_DB2_IG_VIEW = environmentSit1.HTTP_URL_DB2_IG_VIEW;
		   this.HTTP_URL_DB2IG_MAINTENANCE = environmentSit1.HTTP_URL_DB2_IG_MAINTENANCE;
		   this.HTTP_URL_IG_CONFIG = environmentSit1.HTTP_URL_IG_CONFIG;
		   this.HTTP_URL_IG_CONFIG_MAINTENANCE = environmentSit1.HTTP_URL_IG_CONFIG_MAINTENANCE;
		   this.HTTP_URL_ZIP2TECH_MAINTENANCE = environmentSit1.HTTP_URL_ZIP2TECH_MAINTENANCE
		   this.HTTP_URL_CARRIER_ZONES_DEPLOYMENT = environmentSit1.HTTP_URL_CARRIER_ZONES_DEPLOYMENT;
		   sessionStorage.setItem('ENVIRONMENT', "SIT");
		}
		else if(window && window.location && window.location.href && window.location.href.split('/')[2] && window.location.href.split('/')[2].indexOf('testcop') > -1){
		   this.HTTP_URL_APIFULL = environmentTst.HTTP_URL_APIFULL;
		   this.HTTP_URL_ADMIN = environmentTst.HTTP_URL_ADMIN;
		   this.HTTP_URL_REPORT = environmentTst.HTTP_URL_REPORT;
		   this.HTTP_URL_ACTION = environmentTst.HTTP_URL_ACTION;
		   this.HTTP_URL_TOOLS = environmentTst.HTTP_URL_TOOLS;
		   this.HTTP_URL_USER_INQUIRY = environmentTst.HTTP_URL_USER_INQUIRY;
		   this.HTTP_URL_TRANSACTION = environmentTst.HTTP_URL_TRANSACTION;
		   this.HTTP_URL_SERVICERATEPLANWIZARD = environmentTst.HTTP_URL_SERVICERATEPLANWIZARD; 
		   this.HTTP_URL_CARRIER = environmentTst.HTTP_URL_CARRIER; 
		   this.HTTP_URL_WIZARD = environmentTst.HTTP_URL_WIZARD;
		   this.HTTP_URL_SERVICEPLANVIEW = environmentTst.HTTP_URL_SERVICEPLANVIEW;
		   this.HTTP_URL_MIRRORSERVICEPLANWIZARD = environmentTst.HTTP_URL_MIRRORSERVICEPLANWIZARD;
		   this.HTTP_URL_CARRIERMAINTENANCEWIZARD = environmentTst.HTTP_URL_CARRIERMAINTENANCEWIZARD;
		   this.HTTP_URL_RETAILSTOREWIZARD = environmentTst.HTTP_URL_RETAILSTOREWIZARD;
		   this.RETAILSTOREWIZARD_DATABASE = environmentTst.RETAILSTOREWIZARD_DATABASE;
		   this.HTTP_URL_RETAILTRAITANALYSIS = environmentTst.HTTP_URL_RETAILTRAITSANALYSIS;
		   this.HTTP_URL_CARRIEROUTAGE = environmentTst.HTTP_URL_CARRIEROUTAGE;
		   this.HTTP_URL_USER_REPORTING = environmentTst.HTTP_URL_USER_REPORTING;
		   this.HTTP_URL_THROTTLE_TRANS = environmentTst.HTTP_URL_THROTTLE_TRANS;
		   this.HTTP_URL_MULE = environmentTst.HTTP_URL_MULE;
		   this.HTTP_URL_BALANCE_INQUIRY = environmentTst.HTTP_URL_BALANCE_INQUIRY;
		   this.HTTP_URL_PCRF_TRANS = environmentTst.HTTP_URL_PCRF_TRANS;
		   this.HTTP_URL_DB2_IG_VIEW = environmentTst.HTTP_URL_DB2_IG_VIEW;
		   this.HTTP_URL_DB2IG_MAINTENANCE = environmentTst.HTTP_URL_DB2_IG_MAINTENANCE;
		   this.HTTP_URL_IG_CONFIG = environmentTst.HTTP_URL_IG_CONFIG;
		   this.HTTP_URL_IG_CONFIG_MAINTENANCE = environmentTst.HTTP_URL_IG_CONFIG_MAINTENANCE;
		   this.HTTP_URL_ZIP2TECH_MAINTENANCE = environmentTst.HTTP_URL_ZIP2TECH_MAINTENANCE
		   this.HTTP_URL_CARRIER_ZONES_DEPLOYMENT = environmentTst.HTTP_URL_CARRIER_ZONES_DEPLOYMENT;
		   sessionStorage.setItem('ENVIRONMENT', "TST");
		}
		else {
		   this.HTTP_URL_APIFULL = environment.HTTP_URL_APIFULL;
		   this.HTTP_URL_ADMIN = environment.HTTP_URL_ADMIN;
		   this.HTTP_URL_REPORT = environment.HTTP_URL_REPORT;
		   this.HTTP_URL_ACTION = environment.HTTP_URL_ACTION;
		   this.HTTP_URL_TOOLS = environment.HTTP_URL_TOOLS;
		   this.HTTP_URL_USER_INQUIRY = environment.HTTP_URL_USER_INQUIRY;
		   this.HTTP_URL_TRANSACTION = environment.HTTP_URL_TRANSACTION;
		   this.HTTP_URL_SERVICERATEPLANWIZARD = environment.HTTP_URL_SERVICERATEPLANWIZARD; 
		   this.HTTP_URL_CARRIER = environment.HTTP_URL_CARRIER; 
		   this.HTTP_URL_WIZARD = environment.HTTP_URL_WIZARD;
		   this.HTTP_URL_SERVICEPLANVIEW = environment.HTTP_URL_SERVICEPLANVIEW;
		   this.HTTP_URL_MIRRORSERVICEPLANWIZARD = environment.HTTP_URL_MIRRORSERVICEPLANWIZARD;
		   this.HTTP_URL_CARRIERMAINTENANCEWIZARD = environment.HTTP_URL_CARRIERMAINTENANCEWIZARD;
		   this.HTTP_URL_RETAILSTOREWIZARD = environment.HTTP_URL_RETAILSTOREWIZARD;
		   this.RETAILSTOREWIZARD_DATABASE = environment.RETAILSTOREWIZARD_DATABASE;
		   this.HTTP_URL_RETAILTRAITANALYSIS = environment.HTTP_URL_RETAILTRAITSANALYSIS;
		   this.HTTP_URL_CARRIEROUTAGE = environment.HTTP_URL_CARRIEROUTAGE;
		   this.HTTP_URL_USER_REPORTING = environment.HTTP_URL_USER_REPORTING;
		   this.HTTP_URL_THROTTLE_TRANS = environment.HTTP_URL_THROTTLE_TRANS;
		   this.HTTP_URL_MULE = environment.HTTP_URL_MULE;
		   this.HTTP_URL_BALANCE_INQUIRY = environment.HTTP_URL_BALANCE_INQUIRY;
		   this.HTTP_URL_PCRF_TRANS = environment.HTTP_URL_PCRF_TRANS;
		   this.HTTP_URL_DB2_IG_VIEW = environment.HTTP_URL_DB2_IG_VIEW;
		   this.HTTP_URL_DB2IG_MAINTENANCE = environment.HTTP_URL_DB2_IG_MAINTENANCE;
		   this.HTTP_URL_IG_CONFIG = environment.HTTP_URL_IG_CONFIG;
		   this.HTTP_URL_IG_CONFIG_MAINTENANCE = environment.HTTP_URL_IG_CONFIG_MAINTENANCE;
		   this.HTTP_URL_ZIP2TECH_MAINTENANCE = environment.HTTP_URL_ZIP2TECH_MAINTENANCE
		   this.HTTP_URL_CARRIER_ZONES_DEPLOYMENT = environment.HTTP_URL_CARRIER_ZONES_DEPLOYMENT;
		   sessionStorage.setItem('ENVIRONMENT', "PROD");
		}
    }
}
