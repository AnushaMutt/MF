
import {forkJoin as observableForkJoin,  Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { DatabaseEnv } from './../model/serviceModel/DatabaseEnv';
import { URLHandlerService } from './urlhandler.service';

@Injectable()
export class DatabaseEnvService {

  readonly HTTP_URL_DBENVS = "dbenvs";
  readonly LOCALSTORAGE_DBENVS = "databseEnvs";
  
  public dbenvsStored: boolean;
  
  constructor(private http: HttpClient, private urlHandler: URLHandlerService) { }
    
  ngOnInit(){

  }
 
  public isDBEnvsInStorage():boolean{
	  
	  var dbEnvs = JSON.parse(sessionStorage.getItem(this.LOCALSTORAGE_DBENVS)); 
	  
	  try{
		  //console.log("------- Checking for DB ENV ---------");
		 return (dbEnvs != null && dbEnvs.length > 0);
	  }
	  catch(exception){
		  //console.log("------- ENV ERRROR - False ---------");
		  return false;		  
	  }
  }
  
  /**
   * Store DB envs in local storage.
   */
  public storeDbEnvs(dbEnvs: DatabaseEnv[]){
	  sessionStorage.setItem(this.LOCALSTORAGE_DBENVS, JSON.stringify(dbEnvs));
  }
  
  /**
   * Retrieve the list of available DB envs from local storage.
   */
  public getDbEnvsFromStorage():DatabaseEnv[]{
	  return JSON.parse(sessionStorage.getItem(this.LOCALSTORAGE_DBENVS));  
  }
  

  /**
   * Retrieve the list of available DB envs from service request.
   */
  public getDbEnvsFromService(){	  
		return observableForkJoin(
				this.http.get<DatabaseEnv[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_DBENVS)
		); 
  }
}
