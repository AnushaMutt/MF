
import { forkJoin as observableForkJoin } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ServiceResponse } from './../model/serviceModel/ServiceResponse';
import { ApiFullToken } from './../model/authModel/ApiFullToken';
import { URLHandlerService } from './urlhandler.service';

@Injectable()
export class APIFullService {

	public static readonly LOCALSTORAGE_APIFULL_TOKEN = "LDAPTOKEN";
	public static readonly LOCALSTORAGE_REFRESH_TOKEN = "LDAPREFRESHTOKEN";
	public static LOCALSTORAGE_REFRESH_TOKEN_COUNT = "LDAPREFRESHTOKENCOUNT";
	public static readonly INTERCEPTOR_SKIPHEADER = 'COP-Skip-Interceptor';

	constructor(private http: HttpClient, private urlHandler: URLHandlerService) { }
	
	/**
	 * Retrieve the LDAP token by calling API Full Service.
	 */
	getAPIFullToken(username:string, password:string) {
		
		const headers = new HttpHeaders().set(APIFullService.INTERCEPTOR_SKIPHEADER, 'Y');
		
		let usernameBody = "&username="+username;
		let passwordBody = "&password=" + password; 
		var body = "grant_type=password&scope=cop&client_id=IntegrateCop_RO&client_secret=abc123**&brandName=csr&sourceSystem=WEB" + usernameBody  + passwordBody;
		return observableForkJoin(
				this.http.post<ApiFullToken>(this.urlHandler.HTTP_URL_APIFULL, body, {headers: headers})
		);		
	  }	

	getAPIRefreshToken(username:string, password:string, newToken:string) {
		const headers = new HttpHeaders().set(APIFullService.INTERCEPTOR_SKIPHEADER, 'Y');
		let usernameBody = "&username="+username;
		let passwordBody = "&password=" + password;
		var body = "grant_type=password&scope=cop&client_id=IntegrateCop_RO&client_secret=abc123**&brandName=csr&sourceSystem=WEB" + usernameBody  + passwordBody + "&refresh_token="+newToken;
		return observableForkJoin(
				this.http.post<ApiFullToken>(this.urlHandler.HTTP_URL_APIFULL, body, {headers: headers})
		);
	  }
}