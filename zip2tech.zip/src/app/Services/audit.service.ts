
import { forkJoin as observableForkJoin, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuditDetail } from './../model/serviceModel/AuditDetail';
import { URLHandlerService } from './urlhandler.service';

@Injectable()
export class AuditService {
  
  readonly HTTP_GETAUDITDETAILS = "audithistory";
  
  constructor(private http: HttpClient, private urlHandler: URLHandlerService) { }
    
  getAuditDetail(userId:number):Observable<AuditDetail[]>{
         return this.http.get<AuditDetail[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_GETAUDITDETAILS + "/" + userId);
    }
  
  getAuditDetailsJoined(userId){
        return observableForkJoin(
                this.getAuditDetail(userId)
        ); 
    }
}
