import { forkJoin as observableForkJoin } from "rxjs";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { URLHandlerService } from "./urlhandler.service";

@Injectable()
export class CarrierZip2TechService {
    readonly HTTP_GET_COLUMN = "getcolumn";
    readonly HTTP_SEARCH_ZIP2TECH = "searchzip2tech";
    readonly HTTP_GET_PARENT_NAME = "viewparentnames";
    readonly HTTP_UPDATE_ZIP2TECH = "updatezip2techs";
    readonly HTTP_GET_BPTECH_COLUMN = "getbptechcolumn";
    readonly HTTP_SEARCH_BPTECH = "searchbptech";
    readonly HTTP_UPDATE_BPTECH = "updatebptechs";
    readonly HTTP_DELETE_ZIP2TECH = "deletezip2tech";
    readonly HTTP_ADD_ZIP2TECH = "addzip2tech";
    readonly HTTP_BULK_INSERT_ZIP2TECH = "bulkinsertzip2tech";
    readonly HTTP_BULK_DELETE_ZIP2TECH = "bulkdeletezip2tech";
    readonly HTTP_BULK_INSERT_SUMMARY_ZIP2TECH = "bulkinsertzip2techsummary";
    readonly HTTP_BULK_INSERT_SUMMARY_ZIP2TECH_ERROR_DETAILS = "getbulkinserterrorrecorddetails";
    readonly HTTP_ADD_BPTECH = "addbptech";
    readonly HTTP_DELETE_BPTECH = "deletebptech";
    readonly HTTP_BULK_INSERT_BPTECH = "bulkinsertbptech";
    readonly HTTP_BULK_DELETE_BPTECH = "bulkdeletebptech";
    readonly HTTP_BULK_INSERT_SUMMARY_BPTECH = "bulkinsertbptechsummary";
    readonly HTTP_BULK_INSERT_SUMMARY_BPTECH_ERROR_DETAILS = "getbulkbptechinserterrorrecorddetails";

    constructor(
        private http: HttpClient,
        private urlHandler: URLHandlerService
    ) { }

    public bulkInsertBPTechSummary(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_SUMMARY_BPTECH,
                data
            )
        );
    }

    public getBulkInsertBpTechErrorRecordDetails(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_SUMMARY_BPTECH_ERROR_DETAILS,
                data
            )
        );
    }

    public bulkDeleteBPTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_DELETE_BPTECH,
                data
            )
        );
    }

    public bulkInsertBPTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_BPTECH,
                data
            )
        );
    }

    public deleteBpTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_DELETE_BPTECH,
                data
            )
        );
    }

    public addBPTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_ADD_BPTECH,
                data
            )
        );
    }

    public bulkInsertZip2TechSummary(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_SUMMARY_ZIP2TECH,
                data
            )
        );
    }

    public bulkInsertErrorRecordDetails(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_SUMMARY_ZIP2TECH_ERROR_DETAILS,
                data
            )
        );
    }

    public addZip2Tech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_ADD_ZIP2TECH,
                data
            )
        );
    }

    public bulkInsertZip2Tech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_INSERT_ZIP2TECH,
                data
            )
        );
    }

    public bulkDeleteZip2Tech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_BULK_DELETE_ZIP2TECH,
                data
            )
        );
    }

    public deleteZip2Techs(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_DELETE_ZIP2TECH,
                data
            )
        );
    }

    public updateBPTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_UPDATE_BPTECH,
                data
            )
        );
    }

    public getService(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_BPTECH_COLUMN + "/SERVICE",
                data
            )
        );
    }

    public getProductKey(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_BPTECH_COLUMN + "/PRODUCT_KEY",
                data
            )
        );
    }

    public getBpCode(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_BPTECH_COLUMN + "/BP_CODE",
                data
            )
        );
    }

    public searchBpTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_SEARCH_BPTECH,
                data
            )
        );
    }

    public updateZip2Tech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_UPDATE_ZIP2TECH,
                data
            )
        );
    }

    public getTechKey(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_BPTECH_COLUMN + "/TECHKEY",
                data
            )
        );
    }

    public searchZip2Tech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_SEARCH_ZIP2TECH,
                data
            )
        );
    }

    public getServcies(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/SERVICE",
                data
            )
        );
    }

    public getParentId(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/X_PREF_PARENT",
                data
            )
        );
    }

    public getParentNames(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_PARENT_NAME,
                data
            )
        );
    }

    public getStates(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/STATE",
                data
            )
        );
    }

    public getCountry(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/COUNTY",
                data
            )
        );
    }

    public getLanguage(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/LANGUAGE",
                data
            )
        );
    }

    public getAction(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/ACTION",
                data
            )
        );
    }

    public getMarket(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/MARKET",
                data
            )
        );
    }

    public getSahcid(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/SAHCID",
                data
            )
        );
    }

    public getAid(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/AID",
                data
            )
        );
    }

    public getVid(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/VID",
                data
            )
        );
    }

    public getVc(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/VC",
                data
            )
        );
    }

    public getCom(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/COM",
                data
            )
        );
    }

    public getLocale(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/LOCALE",
                data
            )
        );
    }

    public getSiteType(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/SITETYPE",
                data
            )
        );
    }

    public getGotoPhoneList(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/GOTOPHONELIST",
                data
            )
        );
    }

    public getTech(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_ZIP2TECH_MAINTENANCE + this.HTTP_GET_COLUMN + "/TECH",
                data
            )
        );
    }
}
