
import {throwError as observableThrowError, Subject, Observable } from 'rxjs';
import {catchError, map, takeUntil} from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import {
  HttpRequest,
  HttpResponse,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from './../auth.service';
import { APIFullService } from './../apifull.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
	
	public readonly HTTP_BADREQUEST = 400;
	public readonly HTTP_UNAUTHORIZED = 401;
	public readonly HTTP_INTERNALERROR = 500;
	public readonly HTTP_SERVICEDOWN = 0;
	
	private auth:AuthService;
	
  	constructor(private inj: Injector, private router: Router ) { }

  	/**
  	 * Intercepts request for all services to add the auth token. 
  	 * On response, check 
  	 */
  	public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		
		// If header flag has skip intercepter, do not proceed let it continue.
		 if (request.headers.has(APIFullService.INTERCEPTOR_SKIPHEADER)) {

		      const headers = request.headers.delete(APIFullService.INTERCEPTOR_SKIPHEADER);
		      return next.handle(request.clone({ headers }));
		 }
		
		const auth = this.inj.get(AuthService);  	
		var currentLDAPToken = JSON.parse(sessionStorage.getItem(auth.LOCALSTORAGE_APIFULL_TOKEN));
		
		// Check Token for credentials. (comment below to bypass datapower, testing only)
//		if(currentLDAPToken == null || currentLDAPToken.length === 0)
//			throw observableThrowError("Auth API Token not found.");
		
		request = request.clone({
			  setHeaders: {
				  coptoken: `${auth.getToken()}`,
				  Authorization: `Bearer ${currentLDAPToken}`
			  }
		});
		
		// Intercept response for Invalid HTTP Error Codes.
		return next.handle(request).pipe(map((event: HttpEvent<any>) => {
			
			// Check for error flag in HTTP 200 body response.
	        if (event instanceof HttpResponse && ~~(event.status == 200)) {
	        	// Error response in body contain an httpCode field.
	        	if(event.body.httpCode === undefined || event.body.httpCode ==null)
	    	        return event;
	        	
	        	switch(event.body.httpCode){	        	
					case this.HTTP_UNAUTHORIZED:
						throw event;
					case this.HTTP_BADREQUEST:
						throw event;
					default:
						throw observableThrowError("Application Error encountered with services.");
	        	}
	        } 
	        return event;
	      }),
		catchError((err: HttpErrorResponse) => {
			console.log("Error error");
			switch(err.status){
				case this.HTTP_UNAUTHORIZED:
				    return this.handleHTTPUnauthorized(err);
				case this.HTTP_INTERNALERROR:
				case this.HTTP_SERVICEDOWN:
				    return this.handleHTTPInternalError(err);
				default:{
					let mainObject: any = err;
					if(mainObject.body && mainObject.body.errorMessage){
						let errorObject: any = {};
						if(mainObject.body.errorCode)
							errorObject.error = mainObject.body.errorCode + " : " + mainObject.body.errorMessage;
						else
							errorObject.error = mainObject.body.errorMessage;
						return observableThrowError(errorObject);
					}
					else{
						let errorObject: any = err;
						return observableThrowError(errorObject);
					}
				}
			}
		}),) as any;			 
  	}
  	
  	/**
  	 * Handles event for HTTP 401 Unauthorized Status.
  	 * Clear local storage for user fields and routes to login page.
  	 */
  	private handleHTTPUnauthorized(err?: HttpErrorResponse){
		this.router.navigateByUrl('/login');
	    
	    if(err!=null)
	    	return observableThrowError(err);
	    else
	    	return observableThrowError("Unauthorized session. Please login.");	 
  	}
  	
  	/**
  	 * Handles event for HTTP 500 Internal Error Status.
  	 */
  	private handleHTTPInternalError(err: HttpErrorResponse){
	    this.router.navigateByUrl('/error');	
	    return observableThrowError(err);
  	}
}