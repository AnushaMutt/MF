
import { throwError as observableThrowError, Subject, Observable, of } from 'rxjs';
import { Injectable, Injector } from '@angular/core';
import {
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';

const urls = [

    {
        url: 'http://localhost:8080/tracfone/main/dbenvs',
        json: [{ "id": 3, "name": "jndi/cop", "description": "COP-DEV-SIT1" }, { "id": 4, "name": "jndi/copb", "description": "COP-DEV-SITB" }, { "id": 5, "name": "jndi/copa", "description": "COP-DEV-SITA" }, { "id": 6, "name": "jndi/copci", "description": "COP-DEV-SITCI" }, { "id": 7, "name": "jndi/copz", "description": "COP-DEV-SITZ" }, { "id": 8, "name": "jndi/copd", "description": "COP-DEV-SITD" }, { "id": 9, "name": "jndi/copf", "description": "COP-DEV-SITF" }, { "id": 10, "name": "jndi/copg", "description": "COP-DEV-SITG" }, { "id": 11, "name": "jndi/cope", "description": "COP-DEV-SITE" }]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/STATE',
        json: ["AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NA", "NC", "ND", "NE", "PA", "PR", "RI", "SC", "SD", "SP", "ST", "TN", "TX", "UT", "VA", "VI"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/COUNTY',
        json: ["ACCOMACK", "ADA", "ADAIR", "ADAMS", "ADDISON", "ADJUNTAS", "AGUADA", "ALEXANDER", "ALEXANDRIA CITY", "ALEXANDRIA, CITY OF", "ALFALFA", "ALGER", "ALLAMAKEE", "ALLEGAN", "ALLEGANY", "ALLEGHANY", "ALLEGHENY", "ALLEGHSPY", "SITKA", "ZAPATA", "ZAVALA"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/SERVICE',
        json: ["AUDIO", "AUDIOTMO", "AUDIOVZW", "CDMA", "CSRNT10", "CSRST", "CSRTR", "GSM5CDMA", "H", "NT", "NT10", "NTHF", "NTHS", "STHA", "STHF", "STHS", "STT", "TC", "TCHF", "TR", "TW", "TWHS", "WFM"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getbptechcolumn/TECHKEY',
        json: ["1", "11", "22", "4567", "BP_TEST", "CA", "CARCON", "CDMA", "CDMASPR", "COSPR", "GSM10", "GSM4", "GSM4CDMA", "GSM4GSM7", "GSM4SPR", "GSM4SPRCO", "GSM5", "GSM5ATCO", "GSM5ATSPR", "GSM5CDMA", "GSM5GSM4", "GSM5SPR", "GSM5SPRCO", "GSM7", "GSMSPRCO", "HAVZW", "HFCDMAV", "HSTMO", "gsm1001", "gsm11", "ww"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/LANGUAGE',
        json: ["EN", "SP"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/ACTION',
        json: ["action="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/MARKET',
        json: ["&market=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/SAHCID',
        json: ["&sahcid=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/AID',
        json: ["&aid=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/VID',
        json: ["&vid=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/VC',
        json: ["&vc=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/COM',
        json: ["&com=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/LOCALE',
        json: ["&locale=EN", "&locale=en", "&locale=en_US", "&locale=es_US", "=en", "=es_US"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/SITETYPE',
        json: ["&siteType=", "&siteType= CITY OF\"", "&siteType=&siteType=SL", "&siteType=&siteType=TR", "&siteType=AUDIOTMO", "&siteType=AUDIOVZW", "&siteType=CDR", "&siteType=CSR", "&siteType=CSRTR", "&siteType=NONE", "&siteType=NT10", "&siteType=SL", "&siteType=ST", "&siteType=TC", "&siteType=TR", "&siteType=UMBULL", "&siteType=US", "=", "=AUDIOVZW", "=CSR", "=SL", "=TR"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/GOTOPHONELIST',
        json: ["&gotoPhonelist=", "="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/TECH',
        json: ["tech="]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getcolumn/X_PREF_PARENT',
        json: ["5", "55", "6", "66", "68", "76", "77", "78", "79", "NULL"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/searchzip2tech',
        json: [{ "dbEnv": null, "zips": "99835", "state": "AK", "county": "SITKA", "pref1": null, "pref2": null, "service": "AUDIO", "language": "EN", "action": "action=", "market": "&market=", "zip2": "&zip=99835", "aid": "&aid=", "vid": "&vid=", "vc": "&vc=", "sahcid": "&sahcid=", "com": "&com=", "locale": "&locale=en", "siteType": "&siteType=", "gotoPhoneList": "&gotoPhonelist=", "tech": "tech=", "techZip": "&techzip=99835", "techkey": "CARCON", "prefParent": "76", "paginationSearch": { "startIndex": 1, "endIndex": 5000, "total": 2 } }, { "dbEnv": null, "zips": "99835", "state": "AK", "county": "SITKA", "pref1": null, "pref2": null, "service": "AUDIO", "language": "SP", "action": "action=", "market": "&market=", "zip2": "&zip=99835", "aid": "&aid=", "vid": "&vid=", "vc": "&vc=", "sahcid": "&sahcid=", "com": "&com=", "locale": "&locale=es_US", "siteType": "&siteType=", "gotoPhoneList": "&gotoPhonelist=", "tech": "tech=", "techZip": "&techzip=99835", "techkey": "CARCON", "prefParent": "76", "paginationSearch": null }]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/addzip2tech',
        json: { "status": "Success", "message": "812981125" }
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getbptechcolumn/SERVICE',
        json: ["AUDIO", "AUDIOTMO", "AUDIOVZW", "CSRNT10", "CSRST", "CSRTR", "GOSMART", "NT10", "NTHF", "NTHS", "SAS", "SIMPLE", "SL", "ST", "STHA", "STHF", "STHS", "TC", "TCHF", "TR", "TW", "TWHS", "WFM"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getbptechcolumn/BP_CODE',
        json: ["CARCON", "CARCONTMO", "CO", "COGSM4", "COGSM5", "COSPR", "GSM4", "GSM4SPR", "GSM4SPRCO", "GSM5", "GSM5AT", "GSM5ATCO", "GSM5ATSPR", "GSM5ATSPRCO", "GSM5SPR", "GSM5SPRCO", "GSM7", "GSM7AT", "HAVZW", "HFCDMAV", "HSTMO", "HSVZW", "MPERSVZW", "SASGSM", "SPR"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/getbptechcolumn/PRODUCT_KEY',
        json: ["CARCONNECT", "HOMEPHONE", "HOTSPOT", "MPERS", "PHONE", "REMOTEALERT"]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/searchbptech',
        json: [{ "techkey": "CDMA", "service": "NTHS", "bpCode": "CO", "productKey": "HOTSPOT" }]
    },

    {
        url: 'http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/addbptech',
        json: { "status": "Success", "message": "398577629" }
    }
];

@Injectable()
export class MockTokenInterceptor implements HttpInterceptor {

    public readonly HTTP_BADREQUEST = 400;
    public readonly HTTP_UNAUTHORIZED = 401;
    public readonly HTTP_INTERNALERROR = 500;
    public readonly HTTP_SERVICEDOWN = 0;


    constructor(private inj: Injector, private router: Router) { }

    /**
     * Intercepts request for all services to add the auth token. 
     * On response, check 
     */
    public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        for (const element of urls) {
            if (request.url === element.url) {
                return of(new HttpResponse({ status: 200, body: (element.json) }));
            }
        }
    }

    /**
     * Handles event for HTTP 401 Unauthorized Status.
     * Clear local storage for user fields and routes to login page.
     */
    private handleHTTPUnauthorized(err?: HttpErrorResponse) {
        this.router.navigateByUrl('/login');

        if (err != null)
            return observableThrowError(err);
        else
            return observableThrowError("Unauthorized session. Please login.");
    }

    /**
     * Handles event for HTTP 500 Internal Error Status.
     */
    private handleHTTPInternalError(err: HttpErrorResponse) {
        this.router.navigateByUrl('/error');
        return observableThrowError(err);
    }
}