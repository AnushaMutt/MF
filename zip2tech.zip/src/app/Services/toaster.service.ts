import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import { IGrowlMsgType } from './interfaces/common.interface';


@Injectable()
export class ToasterService {

  private _severities = {
    success: "success",
    warn: "warn",
    info: "info",
    error: "error",
  }
  constructor(public growlService: MessageService) {
  }

  showSingle(msg: IGrowlMsgType) {
    let msgObj = {
      severity: msg.type || this._severities.info,
      summary: msg.title || '',
      detail: msg.desc || '',
      life:6000
    };
    this.growlService.add(msgObj)
  }

  showMultiple(messages: Array<object>) {
    this.growlService.addAll(messages);
  }

  clear() {
    this.growlService.clear();
  }

  getMessageBody() {
    let msgBody: IGrowlMsgType = {
      type: '',
      title: '',
      desc: ''
    };
    return msgBody;
  }

  showSuccessMessage(message, title?: string) {
    let msgObj: IGrowlMsgType = this.getMessageBody();
    msgObj.title = title || "";
    msgObj.desc = message || '';;
    msgObj.type = this._severities.success;
    this.showSingle(msgObj);
  }

  showErrorMessage(message?, title?: string) {
    let msgObj: IGrowlMsgType = this.getMessageBody();
    msgObj.title = title || "";
    msgObj.desc = message || "";;
    msgObj.type = this._severities.error;
    this.showSingle(msgObj);
  }

  showInfoMessage(message, title?: string) {
    let msgObj: IGrowlMsgType = this.getMessageBody();
    msgObj.title = title || "";
    msgObj.desc = message || '';
    msgObj.type = this._severities.info;
    this.showSingle(msgObj);
  }

  showWarningMessage(message, title?: string) {
    let msgObj: IGrowlMsgType = this.getMessageBody();
    msgObj.title = title || "";
    msgObj.desc = message || '';
    msgObj.type = this._severities.warn;
    this.showSingle(msgObj);
  }

  showApiErrorMessage(data, errorMsg?: string, title?: string) {
    let message: string;
    if (errorMsg) {
      message = errorMsg;
    }
    else if (data && data.error && data.error.message) {
      message = data.error.message;
    }
    else if (data && data.message) {
      message = data.message;
    }
    else {
      //message = AppLitteralsConfig.reqError;
    }
    let msgObj: IGrowlMsgType = this.getMessageBody();
    msgObj.title = title || "Error";
    msgObj.desc = message || '';;
    msgObj.type = this._severities.error;
    this.showSingle(msgObj);
    return message;
  }


}
