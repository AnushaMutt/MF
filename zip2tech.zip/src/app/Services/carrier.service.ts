
import { forkJoin as observableForkJoin,  Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';

import { ViewActionItem } from './../model/serviceModel/ViewActionItem';
import { ViewActionItemRequest } from './../model/serviceModel/ViewActionItemRequest';
import { InsertTransactionRequest } from './../model/serviceModel/InsertTransactionRequest';
import { ReworkTransactionRequest } from './../model/serviceModel/ReworkTransactionRequest';
import { ViewCarrierErrors } from './../model/serviceModel/ViewCarrierErrors';
import { ViewThErrors } from './../model/serviceModel/ViewThErrors';
import { AvgTimeTemplate } from './../model/serviceModel/AvgTimeTemplate';
import { AvgTimeStatus } from './../model/serviceModel/AvgTimeStatus';
import { CountTransactionIg } from './../model/serviceModel/CountTransactionIg';
import { CountTransactionTh } from './../model/serviceModel/CountTransactionTh';
import { ReportQueue } from './../model/serviceModel/ReportQueue';
import { ServiceResponse } from './../model/serviceModel/ServiceResponse';
import { ViewActionItemResponse } from './../model/serviceModel/ViewActionItemResponse';
import { TransactionBucket } from './../model/serviceModel/TransactionBucket';
import { BucketDetailRequest } from './../model/serviceModel/BucketDetailRequest';
import { ReportResponse } from './../model/reportModel/ReportResponse';
import { TransactionCarrierResponse } from './../model/serviceModel/TransactionCarrierResponse';

import { URLHandlerService } from './urlhandler.service';

@Injectable()
export class CarrierService {

    readonly REPORT_NAME_ALLFAILURES = "allfailures";
    readonly REPORT_NAME_MONITORQUEUE = "monitor";
    readonly REPORT_NAME_ADHOCMONITORQUEUE = "monitoradhoc";
    readonly REPORT_NAME_MONITORSTATUS = "monitorgraph";
  
    readonly HTTP_GETACTIONITEMID = "actionitemid";
    readonly HTTP_REQUEUETRANSACTIONS = "requeue";
    readonly HTTP_REWORK_TRANSACTION = "rework";
    readonly HTTP_INSERT_TRANSACTION = "transaction"; 
    readonly HTTP_RETREIVEBUCKETDETAILS = "buckets";
    readonly HTTP_GETFAILEDTRANSACTIONS = "failedtransaction";
    readonly HTTP_GETCARRIERRESPONSE = "transcarrierresponse";
	readonly HTTP_GETUSERHISTORY = "userhistory";
        readonly HTTP_GETUSERTASK = "usertask";
        readonly HTTP_GETUSERLIST = "userlist";
        readonly HTTP_ASSIGNUSERTASK = "assignusertask";
		readonly HTTP_UPDATEUSERTASK = "updateusertask";
	readonly HTTP_BULK_INSERT_TRANSACTION = "bulkinserts";
	readonly HTTP_BULK_INSERT_SUMMARY = "bulkinsertsummary";
	readonly HTTP_ERROR_DETAILS = "geterrorrecorddetails";
	readonly HTTP_GET_IG_IN_PROGRESS = "getIgInProgress";
	readonly HTTP_DELETE_IG_IN_PROGRESS = "deleteIgInProgress";
	readonly HTTP_GET_USER_HISTORY_DETAILS = "getuserhistorydetail";

        
    constructor(private http: HttpClient, private urlHandler: URLHandlerService) { }


	viewTransaction(data, uniqueIdentifier){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + 
			"/" + this.HTTP_GET_USER_HISTORY_DETAILS + "/" + uniqueIdentifier, data));
	}

    getTransactionBucketDetails(bucketDetailRequest: BucketDetailRequest){
          return observableForkJoin(this.http.post<BucketDetailRequest[]>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_RETREIVEBUCKETDETAILS, bucketDetailRequest));
    }

	getUserHistory(userId : string, transactionRequest: ViewActionItemRequest){
		return observableForkJoin(
				this.http.post<ViewActionItemResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETUSERHISTORY, {
					dbEnv : transactionRequest.dbenv,
					userId : transactionRequest.userId,
					fromCreationDate: transactionRequest.fromCreationDate,
                    toCreationDate: transactionRequest.toCreationDate
					})
		);
	}

	getUserTransactionHistory(userId : string, transactionRequest){
		return observableForkJoin(
				this.http.post(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETUSERTASK, transactionRequest)
		);
	}

	assignTransactiontoUser(assignRequest){
		return observableForkJoin(
				this.http.post(this.urlHandler.HTTP_URL_ACTION + this.HTTP_ASSIGNUSERTASK, assignRequest)
		);
	}

	updateTransaction(updateRequest){
		return observableForkJoin(
				this.http.post(this.urlHandler.HTTP_URL_ACTION + this.HTTP_UPDATEUSERTASK, updateRequest)
		);
	}

	getUserLists(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETUSERLIST)
		);
	}
    
	getActionItemIDJoined(transactionRequest: ViewActionItemRequest){
		return observableForkJoin(
				this.http.post<ViewActionItemResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETACTIONITEMID, {
					actionItemId: transactionRequest.actionItemId,
					transactionId: transactionRequest.transactionId,
					orderType: transactionRequest.orderType,
					esn: transactionRequest.esn,
					status: transactionRequest.status,
					statusMessage: transactionRequest.statusMessage,
					fromCreationDate: transactionRequest.fromCreationDate,
                    toCreationDate: transactionRequest.toCreationDate,
					fromUpdateDate: transactionRequest.fromUpdateDate,
                    toUpdateDate: transactionRequest.toUpdateDate,
					isExactMatch: transactionRequest.isExactMatch,
					isExactMatchActionItemId: transactionRequest.isExactMatchActionItemId,
                    notInStatus: transactionRequest.notInStatus,
                    notInOrderType:transactionRequest.notInOrderType,
                    notInStatusMessage:transactionRequest.notInStatusMessage,
                    notInActionItemId:transactionRequest.notInActionItemId,
                    dbenv: transactionRequest.dbenv,
					additionalSearchColumns: transactionRequest.additionalSearchColumns,
                    pagination:transactionRequest.pagination,
                    fromUserHistory:transactionRequest.fromUserHistory
					})
		); 
	}
	
	getActionItemID(aid: string, dbenv: string):Observable<ViewActionItem[]>{
		return this.http.post<ViewActionItem[]>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETACTIONITEMID, { actionItemId: aid, dbEnvironment: dbenv });
	}  
    
	requeueTransaction(requeueIds: string[]){
		return observableForkJoin(
			this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_REQUEUETRANSACTIONS, {
				transactionItemIds: requeueIds		
			})
		); 
	}
	
     requeueTransactions(requeueTransactionRequest: ReworkTransactionRequest){
          return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_REQUEUETRANSACTIONS, requeueTransactionRequest));
    }
    
    reworkTransactionRequest(reworkTransactionRequest: ReworkTransactionRequest){
          return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_REWORK_TRANSACTION, reworkTransactionRequest));
    }

    insertTransactionRequest(transactionRequest: InsertTransactionRequest){
          return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION, transactionRequest));
    }
    
	getAdhocReportMonitorQueue(reportFromDate:string, reportToDate:string, type:string){
	    return observableForkJoin(
	    		this.http.post<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_ADHOCMONITORQUEUE , {
			    	fromDate: reportFromDate,
			    	toDate: reportToDate, 
					transactionType:type
	    		})
	    );
	}
	
	getReportMonitorQueue(){
	    return observableForkJoin(this.http.get<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_MONITORQUEUE + '/ig'));
	}

	getReportTTMonitorQueue(){
	    return observableForkJoin(this.http.get<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_MONITORQUEUE + '/tt'));
	}

	getReportPCRFMonitorQueue(){
        return observableForkJoin(this.http.get<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_MONITORQUEUE + '/pcrf'));
    }
	 
	getReportMonitorStatus(transactionType){
	    return observableForkJoin(this.http.get<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_MONITORSTATUS + "/" + transactionType));
	}
    
	getAllFailures(){
	    return observableForkJoin(this.http.get<ReportResponse>(this.urlHandler.HTTP_URL_REPORT + this.REPORT_NAME_ALLFAILURES));
	}
	
	getFailedTransactions(transactionRequest: ViewActionItemRequest){
		return observableForkJoin(
				this.http.post<ViewActionItemResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETFAILEDTRANSACTIONS, {			
					orderType: transactionRequest.orderType,				
					fromCreationDate: transactionRequest.fromCreationDate,
                    dbenv: transactionRequest.dbenv,
					additionalSearchColumns: transactionRequest.additionalSearchColumns
				})
		); 
	}
	
	getCarrierResponse(tid: string, databaseEnv: string){
	    return observableForkJoin(	    		
	    		this.http.post<TransactionCarrierResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_GETCARRIERRESPONSE, { 
	    			transactionId: tid, 
	    			dbenv: databaseEnv 
	    		})
		);
	}

	bulkInsertTransactionRequest(transactionRequest: InsertTransactionRequest){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + "/" + this.HTTP_BULK_INSERT_TRANSACTION, transactionRequest));
  }

	bulkInsertSummary(data){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + "/" + this.HTTP_BULK_INSERT_SUMMARY, data));
	}

	bulkInsertErrorDetails(data){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + "/" + this.HTTP_ERROR_DETAILS, data));
	}

	getIgTransactionInProgress(data){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + "/" + this.HTTP_GET_IG_IN_PROGRESS, data));
  	}

  	deleteIgTransactionInProgress(data){
		return observableForkJoin(this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ACTION + this.HTTP_INSERT_TRANSACTION + "/" + this.HTTP_DELETE_IG_IN_PROGRESS, data));
	}
}