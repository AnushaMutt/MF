import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class CarrierZip2TechHelper {

  public 'dbEnv': String;
  public breadcrumbListUpdate = new Subject<number>();
  public breadcrumbList = [];

  constructor() { }

  public setDbEnv(dbEnv) {
    this.dbEnv = dbEnv;
  }

  public getDbEnv() {
    return this.dbEnv;
  }
  public checkRequestObject(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkRequestObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  public checkReqForObjectInsideObject(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkReqForObjectInsideObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          obj[key] = null;
        }
      }
      else if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  checkRequestObjectForArray(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObjectForArray(obj[key])
        if (innerArray === undefined) {
          delete obj[key];
          obj.pop();
        } else if (innerArray && innerArray.constructor === Array && innerArray.length === 0) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key]
    });
    return Object.keys(obj).length > 0 || obj instanceof Array ? obj : undefined;
  };

  public updateBreadcrumbList(breadcrumb: string, index: number) {
    this.breadcrumbList[index] = breadcrumb;
    this.breadcrumbListUpdate.next(Math.random());
  }

  public deleteBreadcrumbList(index: number) {
    this.breadcrumbList.splice(index, 1);
    this.breadcrumbListUpdate.next(Math.random());
  }

  public emptyBreadcrumbList() {
    this.breadcrumbList = [];
    this.breadcrumbListUpdate.next(Math.random());
  }

  public getBreadcrumbList() {
    return this.breadcrumbList;
  }

  public carrierMaintenanceComponentConstantObject = {
    //ZIP2TECH SEARCH
    "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
    "TRACFONE_RETRIEVE_STATE_ERROR_MESSAGE": "Unable to retrive State",
    "NO_STATES_FOUND": "No State found",
    "TRACFONE_RETRIEVE_COUNTRY_ERROR_MESSAGE": "Unable to retrive Country",
    "NO_COUNTRY_FOUND": "No Country found",
    "TRACFONE_RETRIEVE_SERVICE_ERROR_MESSAGE": "Unable to retrive Service",
    "NO_SERVICE_FOUND": "No Service found",
    "TRACFONE_RETRIEVE_TECHKEY_ERROR_MESSAGE": "Unable to retrive Techkey",
    "NO_TECHKEY_FOUND": "No Techkey found",
    "TRACFONE_RETRIEVE_ZIP2TECH_ERROR_MESSAGE": "Unable to saerch Zip2Tech",
    "TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE": "No Zip2Tech found",
    "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",
    "NO_PARENT_FOUND": "No Techkey found",
    "TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE": "Unable to retrive Parent",
    "TRACFONE_ZIP2TECH_UPDATE_SUCCESS_MESSAGE" : "Zip2Tech has been updated successfully",
    "TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE" : "Unable to delete Zip2Tech",
    "TRACFONE_DELETE_ZIP2TECH_SUCCESS_MESSAGE" : "Zip2Tech has been deleted successfully",
    "TRACFONE_ADD_ZIP_ERROR_MESSAGE" : "Unable to add Zip2Tech",
    "TRACFONE_ZIP2TECH_ADD_SUCCESS_MESSAGE" : "Zip2Tech has been added successfully",
    "TRACFONE_BULK_ADD_ZIP2TECH_ERROR_MESSAGE":"Unable to add Zip2Tech",
    "TRACFONE_BULK_DELETE_ZIP2TECH_ERROR_MESSAGE" : "Unable to delete Zip2Tech",
    "TRACFONE_RETRIEVE_SUMMARY_ERROR_MESSAGE" : "Unable to retrieve summary record",
    "TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE" : "No summary found",
    "TRACFONE_RETRIEVE_ERROR_DETAILS_ERROR_MESSAGE" :"Unable to retrieve error details",
    "TRACFONE_NO_ERROR_DETAILS_FOUND_ERROR_MESSAGE" : "No error details found",
    "TRACFONE_DUPLICATE_ZIP2TECH_FOUND":"Duplicate Zip2Tech found",

    //BPTECH SEARCH
    "TRACFONE_RETRIEVE_PRODUCT_KEY_ERROR_MESSAGE": "Unable to retrive Product Key",
    "NO_PRODUCT_KEY_FOUND": "No Product Key found",
    "TRACFONE_RETRIEVE_BPCODE_ERROR_MESSAGE": "Unable to retrive BPCode",
    "NO_BPCODE_FOUND": "No BPCode found",
    "TRACFONE_SEARCH_BPTECH_ERROR_MESSAGE": "Unable to search BPTech",
    "TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE" : "Unable to update BPTech",
    "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation error",
    "TRACFONE_BPTECH_UPDATE_SUCCESS_MESSAGE": "BPTech has been updated successfully",
    "TRACFONE_BULK_ADD_BPTECH_ERROR_MESSAGE": "Unable to add BPTech",
    "TRACFONE_BULK_DELETE_BPTECH_ERROR_MESSAGE" : "Unable to delete BPTech",
    "TRACFONE_ADD_BPTECH_ERROR_MESSAGE" : "Unable to add BPTech",
    "TRACFONE_DUPLICATE_BPTECH_FOUND" : "Duplicate BPTech found",
    "TRACFONE_BPTECH_ADD_SUCCESS_MESSAGE" : "BPTech has been added successfully",
    "TRACFONE_DELETE_BPTECH_ERROR_MESSAGE" : "Unable to delete BPTech",
    "TRACFONE_DELETE_BPTECH_SUCCESS_MESSAGE" : "BPTech has been deleted successfully",

  }

  public getTracfoneConstantMethod(msg) {
    return this.carrierMaintenanceComponentConstantObject[msg];
  }
}
