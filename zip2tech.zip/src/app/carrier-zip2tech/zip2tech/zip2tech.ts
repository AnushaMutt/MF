import { Component, OnInit, Input, SimpleChanges} from "@angular/core";

@Component({
    selector: 'zip2tech-wizard',
    templateUrl: './zip2tech.html',
})
export class Zip2TechComponent implements OnInit {
@Input("clearData") clearData: any;

constructor() { }

ngOnInit() { }

ngOnChanges(changes: SimpleChanges) {
    if (changes.clearData.currentValue) {
        this.clearData = this.clearData + Math.random();
    }
}

}