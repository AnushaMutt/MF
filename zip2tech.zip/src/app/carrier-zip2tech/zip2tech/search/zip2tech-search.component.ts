import { Component, OnInit, Input, SimpleChanges, ViewEncapsulation, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Observable, Subject, forkJoin, of,} from "rxjs";
import { takeUntil, startWith, map, catchError } from "rxjs/operators";
import { ToasterService } from "../../../Services/toaster.service";
import { CarrierZip2TechService } from "../../../Services/carrier-zip2tech.service";
import { CarrierZip2TechHelper } from "../../carrier-zip2tech-helper";
import { ConfirmationService } from "primeng/api";
import { routerTransition } from "../../../router.animations";
import { ViewChildren } from "@angular/core";
import { MatSelect } from "@angular/material/select";
import { Zip2TechMaintenanceLocalService } from "../service/zip2techmaintenance";
import { ExportToCsvService } from "../../../Services/export-to-csv.service";
@Component({
    selector: 'search-zip2tech',
    templateUrl: './zip2tech-search.component.html',
    styleUrls: ['./zip2tech-search.component.scss',
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService, ExportToCsvService],
    animations: [routerTransition()],
})
export class SearchZip2TechComponent implements OnInit {
    @Input("clearData") clearData: any;
    @ViewChildren(MatSelect) matSelect: any;
    public searchFrmGrp: FormGroup;
    public enteredZipCodes: any;
    public isEditable = {};
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public errorMessage = "";
    public alerts = [];
    private unsubscribe = new Subject<void>();
    public showLoadingScreen = false;
    public stateData = [];
    public stateMainData = [];
    public countyData = [];
    public countyMainData = [];
    public serviceData = [];
    public serviceMainData = [];
    public parentIdData = [];
    public parentIdMainData = [];
    public techkeyData = [];
    public techkeyMainData = [];
    // for  dropdown search
    filteredStateOptions: Observable<any[]>;
    filteredCountyOptions: Observable<any[]>;
    filteredServiceOptions: Observable<any[]>;
    filteredTechkeyOptions: Observable<any[]>;
    public selected = [];
    public selectedZip2TechData = [];
    public selectedZip2TechMainData = [];
    public zip2TechData = [];
    public zip2TechMainData = [];
    public searchResultTableColumns = [];
    public filteredValues: any = {};
    public editAlreadyEnabled = false;
    public selectedZip2Techs = [];
    public bulkEditBoolean: Boolean = false;

    // for result dropdown search
    public resultFilteredService = [];
    public resultFilteredTechkey = [];
    public resultFilteredParentId = [];

    //bulk
    public bulkEditColumns = [];
    public showBulkUpdateButton = false;
    public multiColumnEditSection = false;
    public otherColumn = false;
    public serviceColumnSelected = false;
    public techkeyColumnSelected = false;
    public ZipColumnSelected = false;
    public parentColumnSelected = false;
    public bulkServiceDropDownData = [];
    public bulktechkeyDropDownData = [];
    public bulkparentDropDownData = [];
    @ViewChild('multicolumnEditServiceValue') multicolumnEditServiceValue: any;
    @ViewChild('multicolumnEditTechkeyValue') multicolumnEditTechkeyValue: any;
    @ViewChild('multicolumnEditParentIdValue') multicolumnEditParentIdValue: any;
//pegination
    public paginationStart: number = 1;
    public paginationEnd: number = 5000;
    public paginationCount: number;
    public PAGINATION_AMOUNT = 5000;
    public pageindex: any = 1;
    public displayRowNumbers: any;

    //single add zip2tech
    public showAddButton: any = true;
    public showAddForm: any = false;
    public addStateData = [];
    public addLanguageData = [];
    public addActionData = [];
    public addMarketData = [];
    public addSahcidData = [];
    public addAidData = [];
    public addVidData = [];
    public addVcData = [];
    public addComData = [];
    public addLocaleData = [];
    public addSiteTypeData = [];
    public addGoToPhoneListData = [];
    public addTechData = [];
    public addTechkeyData = [];
    public addCountyData = [];
    public addParentData = [];
    public addServiceData = [];
    public addFormGroup: FormGroup;
    public zip2 = "";
    public techZip = "";
    public clickedAddNewLink: any = false;
    public addServiceColumnValue = [];
    public addTechkeyColumnValue = [];
    public addLanguageColumnValue = [];

    public filtertedAddLanguageData = [];
    public filtertedAddServiceData = [];
    public filtertedAddTechkeyData = [];
    public bulkUpdateZipInput = "";
    
    constructor(
        private toasterService: ToasterService,
        private _formBuilder: FormBuilder,
        private carrierZip2TechHelper: CarrierZip2TechHelper,
        private carrierZip2TechService: CarrierZip2TechService,
        private confirmationService: ConfirmationService,
        private zip2TechMaintenanceLocalService: Zip2TechMaintenanceLocalService,
        private exportToCsvService: ExportToCsvService
    ) { }

    ngOnInit() {
        this.clickedAddNewLink = true;
        this.searchFrmGrp = new FormGroup({});
        this.createSearchForm();

        this.searchResultTableColumns = [
            { name: "Zip", prop: "zips", width: 70 },
            { name: "State", prop: "state", width: 50 },
            { name: "County", prop: "county", width: 150 },
            { name: "Techkey", prop: "techkey", width: 200 },
            { name: "Parent Id", prop: "prefParent", width: 200 },
            { name: "Service", prop: "service", width: 200 },
            { name: "Language", prop: "language", width: 80 },
            { name: "Action", prop: "action", width: 100 },
            { name: "Market", prop: "market", width: 100 },
            { name: "Zip2", prop: "zip2", width: 100 },
            { name: "AID", prop: "aid", width: 100 },
            { name: "VID", prop: "vid", width: 100 },
            { name: "VC", prop: "vc", width: 100 },
            { name: "SAHCID", prop: "sahcid", width: 100 },
            { name: "Com", prop: "com", width: 100 },
            { name: "Locale", prop: "locale", width: 150 },
            { name: "Site Type", prop: "siteType", width: 150 },
            { name: "Goto Phone List", prop: "gotoPhoneList", width: 130 },
            { name: "Tech", prop: "tech", width: 100 },
            { name: "Tech Zip", prop: "techZip", width: 130 },
            { name: "Pref1", prop: "pref1", width: 80 },
            { name: "Pref2", prop: "pref2", width: 80 },
        ];

        this.bulkEditColumns = [
            { name: "Service", prop: "service", width: 200 },
            { name: "Techkey", prop: "techkey", width: 200 },
            { name: "Parent Id", prop: "prefParent", width: 200 },
            { name: "Zip", prop: "zips", width: 70 },
        ];
            this.getState();
    }

     //Form Group Used for add Form
     createAddForm() {
        this.addFormGroup = this._formBuilder.group({
            zips: ['', [Validators.required, Validators.maxLength(5), Validators.minLength(5),Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
            state:['',[Validators.required]],
            county:['',[Validators.required]],
            pref1:[''],
            pref2:[''],
            service:['', [Validators.required,Validators.maxLength(20)]],
            language:['', [Validators.required,Validators.maxLength(2)]],
            action:[''],
            market:[''],
            zip2:[''],
            aid:[''],
            vid:[''],
            vc:[''],
            sahcid:[''],
            com:[''],
            locale:[''],
            siteType:[''],
            gotoPhoneList:[''],
            tech:[''],
            techZip:[''],
            techkey:['', [Validators.required,Validators.maxLength(20)]],
            prefParent:['',[Validators.required]],

            addStateSearch: [''],
        });
    }

    /*
    * Show Add form
    */
    public addFrom() {
        this.zip2 = "";
        this.techZip = "";
        this.addFormGroup = new FormGroup({});
        this.createAddForm();
        this.showAddButton = false;
        this.showAddForm = true;
        this.reset();
        this.revertAddForm();
        this.alerts = [];
        if(this.clickedAddNewLink) {
        this.dropDownValuesForAdd();
        this.clickedAddNewLink = false;
        }
    }

    /*
    * Remove Add form
    */
    public removeAddForm() {
        this.showAddButton = true;
        this.showAddForm = false;
        this.searchFrmGrp.reset();
        this.revertAddForm();
        this.alerts = [];
    }

    // confirm box
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-zip2techs',
            message: "Are you sure you want to delete Zip2Tech ?",
            accept: () => {
                this.deleteZip2Techs(row);
            }
        });
    }
    
    public deleteZip2Techs(zip2techs) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        obj.zips = zip2techs.zips;
        obj.service = zip2techs.service;
        obj.language = zip2techs.language;
        obj.techkey = zip2techs.techkey;
        this.carrierZip2TechService.deleteZip2Techs(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DELETE_ZIP2TECH_SUCCESS_MESSAGE")
                    );
                    this.searchZip2Tech(this.searchFrmGrp.value);
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    public showBulkUpdateButtonFun() {
        this.bulkUpdateZipInput = "";
        this.showBulkUpdateButton = true;
    }

    public assignmultiColumnName(column) {
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
        if (column == 'service') {
            this.serviceColumnSelected = true;
            this.techkeyColumnSelected = false;
            this.parentColumnSelected = false;
            this.ZipColumnSelected = false;
        }
        else if (column == 'techkey') {
            this.techkeyColumnSelected = true;
            this.serviceColumnSelected = false;
            this.parentColumnSelected = false;
            this.ZipColumnSelected = false;
        }
        else if (column == 'prefParent') {
            this.parentColumnSelected = true;
            this.techkeyColumnSelected = false;
            this.serviceColumnSelected = false;
            this.ZipColumnSelected = false;
        }
        else if (column == 'zips') {
            this.parentColumnSelected = false;
            this.techkeyColumnSelected = false;
            this.serviceColumnSelected = false;
            this.ZipColumnSelected = true;
        }
    }

    public openedChange(rowData) {
        if (rowData == "serviceInput")
            this.resultFilteredService = [...this.serviceMainData];
        else if (rowData == "techkeyInput")
            this.resultFilteredTechkey = [...this.techkeyMainData];
        else if (rowData == "prefParentInput")
            this.resultFilteredParentId = [...this.parentIdMainData];
        else if (rowData == "addSearchStateInput")
            this.addStateData = [...this.stateMainData];
        else if (rowData == "addSearchPrefParentInput")
            this.addParentData = [...this.parentIdMainData];
        else if (rowData == "addSearchCountyInput")
            this.addCountyData = [...this.countyMainData];

        else if (rowData == "bulkEditServiceSearch")
            this.bulkServiceDropDownData = [...this.serviceMainData];
        else if (rowData == "bulkEditTechkeySearch")
            this.bulktechkeyDropDownData = [...this.techkeyMainData];
        else if (rowData == "bulkEditParentIdSearch")
            this.bulkparentDropDownData = [...this.parentIdMainData];
    }

    public inputValueChanged(event, column, row, oldValue) {
        this.defaultEditedRow[column] = oldValue;
        this.editedRow[column] = event.value;

    }

    public onKey(value, rowData) {
        this.addServiceColumnValue = [];
        this.addTechkeyColumnValue = [];
        this.addLanguageColumnValue = [];
        this.bulkUpdateZipInput = "";
        if (value == "" || value.split("").length != 5 || isNaN(value.split("."))) {
            this.showBulkUpdateButton = false;
        } else {
            this.showBulkUpdateButton = true;
        }
        if (rowData == "serviceInput") {
            this.resultFilteredService = [...this.serviceMainData];
            this.resultFilteredService = this.search(value, 'serviceInput');
        }
        else if (rowData == "bulkEditServiceSearch") {
            this.bulkServiceDropDownData = [...this.serviceMainData];
            this.bulkServiceDropDownData = this.search(value, 'bulkEditServiceSearch');
        }else if (rowData == "bulkEditTechkeySearch") {
            this.bulktechkeyDropDownData = [...this.techkeyMainData];
            this.bulktechkeyDropDownData = this.search(value, 'bulkEditTechkeySearch');
        }else if (rowData == "bulkEditParentIdSearch") {
            this.bulkparentDropDownData = [...this.parentIdMainData];
            this.bulkparentDropDownData = this.search(value, 'bulkEditParentIdSearch');
        }
        else if (rowData == "techkeyInput") {
            this.resultFilteredTechkey = [...this.techkeyMainData];
            this.resultFilteredTechkey = this.search(value, 'techkeyInput');
        }
        else if (rowData == "prefParentInput") {
            this.resultFilteredParentId = [...this.parentIdMainData];
            this.resultFilteredParentId = this.search(value, 'prefParentInput');
        }
        else if (rowData == "addLanguageInput") {
            this.filtertedAddLanguageData = [...this.addLanguageData];
            this.filtertedAddLanguageData = this.search(value, 'addLanguageInput');
        }
        else if (rowData == "addServcieInput") {
            this.filtertedAddServiceData = [...this.addServiceData];
            this.filtertedAddServiceData = this.search(value, 'addServcieInput');
        }
        else if (rowData == "addTechkeyInput") {
            this.filtertedAddTechkeyData = [...this.addTechkeyData];
            this.filtertedAddTechkeyData = this.search(value, 'addTechkeyInput');
        }
        else if (rowData == "addSearchStateInput") {
            this.addStateData = [...this.stateMainData]
            this.addStateData = this.search(value, 'addSearchStateInput');
        }
        else if (rowData == "addPrefParentInput") {
            this.addParentData = [...this.parentIdMainData];
            this.addParentData = this.search(value, 'addPrefParentInput');
        }
        else if (rowData == "addSearchCountyInput") {
            this.addCountyData = [...this.countyMainData];
            this.addCountyData = this.search(value, 'addSearchCountyInput');
        }
        else if (rowData == "bulkUpdateZipInput") {
            this.bulkUpdateZipInput = value;
        }
    }

    private search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "serviceInput" || choice == "bulkEditServiceSearch") {
            this.serviceMainData = this.serviceMainData.filter(e => e != null);
            return this.serviceMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "addSearchCountyInput") {
            this.countyMainData = this.countyMainData.filter(e => e != null);
            return this.countyMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "addSearchStateInput") {
            this.stateMainData = this.stateMainData.filter(e => e != null);
            return this.stateMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "techkeyInput" || choice == "bulkEditTechkeySearch") {
            this.techkeyMainData = this.techkeyMainData.filter(e => e != null);
            return this.techkeyMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "prefParentInput" || choice == 'addPrefParentInput' || choice == "bulkEditParentIdSearch") {
            this.parentIdMainData = this.parentIdMainData.filter(e => e != null);
            return this.parentIdMainData.filter(option => option.indexOf(filter) > -1);
        }
        else if (choice == "addLanguageInput") {
            this.addLanguageData = this.addLanguageData.filter(e => e != null);
            return this.addLanguageData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "addServcieInput") {
            this.addServiceData = this.addServiceData.filter(e => e != null);
            return this.addServiceData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "addTechkeyInput") {
            this.addTechkeyData = this.addTechkeyData.filter(e => e != null);
            return this.addTechkeyData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
    }

    public createAddZip2TechRequest(req) {
        req.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        if(this.addServiceColumnValue.length > 0) {
            req.service = this.addServiceColumnValue;
        }
        if(this.addTechkeyColumnValue.length > 0) {
            req.techkey = this.addTechkeyColumnValue;
        }
        if(this.addLanguageColumnValue.length > 0) {
            req.language = this.addLanguageColumnValue;
        }
       this.insertZip2Tech(req);
    }

    public autoCompChangeEvnt(event, selectedColumn) {
        if (selectedColumn == 'techkey') {
            this.addTechkeyColumnValue = event.option.value;
        }
        if (selectedColumn == 'service') {
            this.addServiceColumnValue = event.option.value;
        }
        if (selectedColumn == 'language') {
            this.addLanguageColumnValue = event.option.value;
        }
    }

    public insertZip2Tech(requestData) {
        this.showLoadingScreen = true;
        this.carrierZip2TechService
            .addZip2Tech(requestData)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_ADD_ZIP_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].message == "") {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_ZIP2TECH_FOUND")
                        );                        
                      return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_ZIP2TECH_ADD_SUCCESS_MESSAGE")
                    );
                    this.showAddButton = true;
                    this.showAddForm = false;
                    this.zip2TechMaintenanceLocalService.setTechkey(null);
                    this.zip2TechMaintenanceLocalService.setCounty(null);
                    this.zip2TechMaintenanceLocalService.setService(null);
                    this.zip2TechMaintenanceLocalService.setState(null);
                    this.filtertedAddLanguageData = [...this.addLanguageData];
                    this.getState();
                    // this.showLoadingScreen = false;
                    this.addFormGroup.reset();
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    inlineUpdateZip2Tech(row, rowIndex) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        obj.zips = row.zips;
        obj.oldZip = row.zips;
        obj.county = row.county;
        obj.state = row.state;
        if (this.editedRow.service) {
            obj.service = this.editedRow.service;
        } else {
            obj.service = row.service;
        }

        if (this.editedRow.techkey) {
            obj.techkey = this.editedRow.techkey;
        } else {
            obj.techkey = row.techkey;
        }

        if (this.editedRow.prefParent) {
            obj.prefParent = this.editedRow.prefParent;
        } else {
            obj.prefParent = row.prefParent;
        }

        obj.language = row.language;
        obj.oldService = row.service;
        obj.oldTechKey = row.techkey;
        obj.oldPrefParent = row.prefParent;
        this.updateZip2Tech([obj], rowIndex);
    }

    bulkUpdateZip2Tech() {
        this.showLoadingScreen = true;
        let requestObj = [];

        this.selectedZip2Techs.forEach(e => {
            let obj: any = {};
            if (this.bulkUpdateZipInput != "") {
                obj.zips = this.bulkUpdateZipInput;
            } else {
                obj.zips = e.zips;
            }
            obj.oldZip = e.zips;
            obj.county = e.county;
            obj.state = e.state;
            if (this.multicolumnEditServiceValue) {
                obj.service = this.multicolumnEditServiceValue._value;
            } else {
                obj.service = e.service;
            }

            if (this.multicolumnEditTechkeyValue) {
                obj.techkey = this.multicolumnEditTechkeyValue._value;
            } else {
                obj.techkey = e.techkey;
            }

            if (this.multicolumnEditParentIdValue) {
                obj.prefParent = this.multicolumnEditParentIdValue._value;
            } else {
                obj.prefParent = e.prefParent;
            }

            obj.language = e.language;
            obj.oldService = e.service;
            obj.oldTechKey = e.techkey;
            obj.oldPrefParent = e.prefParent;
            obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
            requestObj.push(obj);
        });

        this.updateZip2Tech(requestObj, "");
    }

    updateZip2Tech(row, rowIndex) {

        this.carrierZip2TechService.updateZip2Tech(row).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    if (rowIndex != "" && data[0].message == "") {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_ZIP2TECH_FOUND")
                        );                        
                      return;
                    }
                    this.zip2TechMainData = [];
                    this.zip2TechData = [];
                    this.selected = [];
                    this.selectedZip2TechData = [];
                    this.selectedZip2TechMainData = [];
                    this.showLoadingScreen = false;
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.selectedZip2Techs = [];
                    this.multiColumnEditSection = false;
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_ZIP2TECH_UPDATE_SUCCESS_MESSAGE")
                    );
                    this.searchZip2Tech(this.searchFrmGrp.value);
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.searchResultTableColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }

    // cancel inline editing
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.searchResultTableColumns.forEach(e => {
            if (document.getElementById(e.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e.prop + rowIndex)
                )).value = rowData[e.prop] || '';
            }
        });
        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('service' + rowIndex) == 0)
                matSelectData.value = rowData['service'] || '';
        });
        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('techkey' + rowIndex) == 0)
                matSelectData.value = rowData['techkey'] || '';
        });
        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('prefParent' + rowIndex) == 0)
                matSelectData.value = rowData['prefParent'] || '';
        });
        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    // Checkbox selection from search result table
    public onSelect(row) {
        this.multiColumnEditSection = true;
        this.selectedZip2Techs = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedZip2Techs.push(obj);
            }
        }
        this.selectedZip2Techs = [...this.selectedZip2Techs]
        if (this.selectedZip2Techs.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
            this.serviceColumnSelected = false;
                this.techkeyColumnSelected = false;
                this.parentColumnSelected = false;
        }
    }

    //Filter Table data based on all the columns values
    public filterZip2TechTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.zip2TechMainData.filter(function (d) {
            return (d.zips ? d.zips.indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.indexOf(val) !== -1 : !val) || !val
                || (d.country ? d.country.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.pref1 ? d.pref1.indexOf(val) !== -1 : !val) || !val
                || (d.pref2 ? d.pref2.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.service ? d.service.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.language ? d.language.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.action ? d.action.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.market ? d.market.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.zip2 ? d.zip2.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.aid ? d.aid.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.vid ? d.vid.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.vc ? d.vc.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.sahcid ? d.sahcid.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.com ? d.com.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.locale ? d.locale.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.siteType ? d.siteType.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.gotoPhoneList ? d.gotoPhoneList.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.tech ? d.tech.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.techZip ? d.techZip.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.techkey ? d.techkey.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.prefParent ? d.prefParent.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.zip2TechData = temp;
    }

    ngOnChanges(changes: SimpleChanges) {
    this.pageindex = 1;
    if(changes.insertData){
        if (changes.insertData.currentValue) {
            if (changes.insertData.currentValue.zipCode) {
                this.enteredZipCodes = changes.insertData.currentValue.zipCode;
            }
           
        }
    }
    }

     /**
     * Sends request to retrieve the previous batch of transactions from the search parameter criteria.
     */
      paginationPreviousBatch() {
        this.paginationStart = this.paginationStart - Number(this.PAGINATION_AMOUNT); 
        this.paginationEnd = this.paginationEnd - Number(this.PAGINATION_AMOUNT); 
        this.pageindex = this.pageindex - 1;
        this.searchZip2Tech(this.searchFrmGrp.value);
    }

    /**
     * Sends request to retrieve the next batch of transactions from the search parameter criteria.
     */
     paginationNextBatch() {
        if (this.paginationStart <= this.paginationCount) {
            this.paginationStart = this.paginationEnd + 1;
        }
        this.paginationEnd = this.paginationEnd + Number(this.PAGINATION_AMOUNT);   
        this.pageindex = this.pageindex + 1;
        this.searchZip2Tech(this.searchFrmGrp.value);
    }

    searchZip2Tech(req) {
        this.showLoadingScreen = true;
        let viewTransactionPagination: any = {};

        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        if(req.county) {
        obj.county = req.county.toString();
        }
        if(req.service){
        obj.service = req.service.toString();
        }
        if(req.state){
        obj.state = req.state.toString();
        }
        if(req.techkey){
        obj.techkey = req.techkey.toString();
        }
        obj.zips = this.enteredZipCodes;

        viewTransactionPagination.startIndex = this.paginationStart;
        viewTransactionPagination.endIndex = this.paginationEnd;
        this.pageindex = this.pageindex - 1;
        obj.paginationSearch = viewTransactionPagination;

        this.isEditable = {};
        this.filteredValues = {};
        this.zip2TechMainData = [];
        this.zip2TechData = [];
        this.selected = [];
        this.selectedZip2TechData = [];
        this.selectedZip2TechMainData = [];
        this.selectedZip2Techs = [];
        this.displayRowNumbers = [];
        this.otherColumn = false;
        this.showBulkUpdateButton = false;
        this.serviceColumnSelected = false;
            this.techkeyColumnSelected = false;
            this.parentColumnSelected = false;

        this.carrierZip2TechService.searchZip2Tech(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    this.zip2TechMainData = data[0];
                    this.zip2TechData = [...this.zip2TechMainData];
                    if (this.filteredValues.mainTableFilter) {
                        this.filterZip2TechTable(this.filteredValues.mainTableFilter);
                    }
                    this.editAlreadyEnabled = false;
                    if (this.zip2TechMainData && this.zip2TechMainData.length == 0) {
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    this.paginationCount = data[0][0].paginationSearch.total;
                    this.paginationEnd = data[0][0].paginationSearch.endIndex;
                    this.paginationStart = data[0][0].paginationSearch.startIndex;
                    this.displayRowNumbers = this.paginationStart + " - " + 
                    (this.paginationEnd < this.paginationCount ? this.paginationEnd : this.paginationCount);
                    if(this.zip2TechMaintenanceLocalService.getParentId() == null || 
                    this.zip2TechMaintenanceLocalService.getParentId().length == 0 ) {
                    this.getParentNames();
                    } else{
                        this.parentIdMainData = this.zip2TechMaintenanceLocalService.getParentId();
                        this.resultFilteredParentId = this.parentIdMainData;
                        this.addParentData = this.parentIdMainData;
                        this.bulkparentDropDownData = this.parentIdMainData;
                    }

                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public getParentNames() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.parentIdData = [];
        this.parentIdMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getParentId(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_PARENT_FOUND")
                        );

                    this.parentIdMainData = data[0];
                    this.zip2TechMaintenanceLocalService.setParentId(this.parentIdMainData);
                    this.parentIdData = [];
                    this.resultFilteredParentId = this.parentIdMainData;
                    this.bulkparentDropDownData = this.parentIdMainData;
                    this.addParentData = data[0];
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
    * Search Criteria form will get reset
    */
    public reset() {
        this.enteredZipCodes = "";
        this.searchFrmGrp.controls.county.patchValue('');
        this.countyData = [];
        this.searchFrmGrp.controls.service.patchValue('');
        this.serviceData = [];
        this.searchFrmGrp.controls.state.patchValue('');
        this.stateData = [];
        this.searchFrmGrp.controls.techkey.patchValue('');
        this.techkeyData = [];
        this.errorMessage = "";
        this.searchFrmGrp.controls.zipCode.patchValue('');
        this.filteredValues = {};
        this.editAlreadyEnabled = false;
        this.bulkEditBoolean = false;
        this.zip2TechMainData = [];
        this.zip2TechData = [];
        this.isEditable = {};
        this.pageindex = 1;
        this.paginationStart = 1;
        this.paginationEnd = 5000;
        this.PAGINATION_AMOUNT = 5000;
        this.displayRowNumbers = [];
    }

    //Form Group Used for Search Form
    createSearchForm() {
        this.searchFrmGrp = this._formBuilder.group({
            zipCode: [""],
            state: [""],
            county: [""],
            service: [""],
            techkey: [""],

            techkeySearch: ['', []],
            stateSearch: ['', []],
            countySearch: ['', []],
            serviceSearch: ['', []],
        });
    }

    // resetting text field to show all dropdown values
    openedMultiChange(e) {
        this.searchFrmGrp.controls.stateSearch.patchValue('');
        this.searchFrmGrp.controls.countySearch.patchValue('');
        this.searchFrmGrp.controls.serviceSearch.patchValue('');
        this.searchFrmGrp.controls.techkeySearch.patchValue('');
    }

    // selection change to clear selected values
    selectionMultipleChange(event, choice) {
        if (event.isUserInput && event.source.selected == false) {
            if (choice == "stateInput") {
                let index = this.stateData.indexOf(event.source.value);
                if (index > -1)
                    this.stateData.splice(index, 1)
            }
            if (choice == "countyInput") {
                let index = this.countyData.indexOf(event.source.value);
                if (index > -1)
                    this.countyData.splice(index, 1)
            }
            if (choice == "serviceInput") {
                let index = this.serviceData.indexOf(event.source.value);
                if (index > -1)
                    this.serviceData.splice(index, 1)
            }
            if (choice == "techkeyInput") {
                let index = this.techkeyData.indexOf(event.source.value);
                if (index > -1)
                    this.techkeyData.splice(index, 1)
            }
        }
    }

    public getTechKey() {
        if(this.zip2TechMaintenanceLocalService.getTechkey() != null && this.zip2TechMaintenanceLocalService.getTechkey().length > 0 ) {
            this.techkeyMainData = this.zip2TechMaintenanceLocalService.getTechkey();
            this.filteredTechkeyOptions = this.searchFrmGrp.controls.techkeySearch.valueChanges
            .pipe(
                startWith<string>(''),
                map((name: any) => this._filter(name, 'techkeyInput'))
            );
            this.filtertedAddTechkeyData = [...this.techkeyMainData];
            this.bulktechkeyDropDownData = [...this.techkeyMainData];
            this.resultFilteredTechkey = [...this.techkeyMainData];
        }
       else{
        this.showLoadingScreen = true;
        let obj: any = {};
        this.techkeyData = [];
        this.techkeyMainData = [];
        this.addTechkeyData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getTechKey(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_TECHKEY_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_TECHKEY_FOUND")
                        );
                    this.techkeyMainData = data[0];
                    this.techkeyData = [];
                    this.addTechkeyData = data[0];
                    this.filtertedAddTechkeyData = [...this.addTechkeyData];
                    this.bulktechkeyDropDownData = data[0];
                    this.resultFilteredTechkey = data[0];
                    this.filteredTechkeyOptions = this.searchFrmGrp.controls.techkeySearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'techkeyInput'))
                        );
                        this.zip2TechMaintenanceLocalService.setTechkey(this.techkeyMainData);
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
       }
    }

    public getServcies() {
        if(this.zip2TechMaintenanceLocalService.getService() != null && this.zip2TechMaintenanceLocalService.getService().length > 0 ) {
            this.serviceMainData = this.zip2TechMaintenanceLocalService.getService();
            this.filteredServiceOptions = this.searchFrmGrp.controls.serviceSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'serviceInput'))
                        );
            this.filtertedAddServiceData = [...this.serviceMainData];
            this.bulkServiceDropDownData = [...this.serviceMainData];
            this.resultFilteredService = [...this.serviceMainData];
            this.getTechKey();
        }
       else{
        this.showLoadingScreen = true;
        let obj: any = {};
        this.serviceData = [];
        this.serviceMainData = [];
        this.addServiceData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getServcies(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_SERVICE_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getTechKey();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getTechKey();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_SERVICE_FOUND")
                        );
                    this.serviceMainData = data[0];
                    this.serviceData = [];
                    this.addServiceData = data[0];
                    this.filtertedAddServiceData = [...this.addServiceData];
                    this.filteredServiceOptions = this.searchFrmGrp.controls.serviceSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'serviceInput'))
                        );

                    this.resultFilteredService = data[0];
                    this.bulkServiceDropDownData = data[0];
                    this.zip2TechMaintenanceLocalService.setService(this.serviceMainData);
                    this.showLoadingScreen = false;
                    this.getTechKey();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getTechKey();
                    return;
                }
            );
    }
}

    // to retrieve state
    public getCountry() {
        if(this.zip2TechMaintenanceLocalService.getCounty() != null && this.zip2TechMaintenanceLocalService.getCounty().length > 0 ) {
            this.countyMainData = this.zip2TechMaintenanceLocalService.getCounty();
            this.filteredCountyOptions = this.searchFrmGrp.controls.countySearch.valueChanges
            .pipe(
                startWith<string>(''),
                map((name: any) => this._filter(name, 'countyInput'))
            );
            this.addCountyData = [...this.countyMainData];
            this.getServcies();
        }
       else{
        this.showLoadingScreen = true;
        let obj: any = {};
        this.countyData = [];
        this.addCountyData = [];
        this.countyMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getCountry(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_COUNTRY_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getServcies();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getServcies();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_COUNTRY_FOUND")
                        );
                    this.countyMainData = data[0];
                    this.countyData = [];
                    this.addCountyData = data[0];

                    // for state search
                    this.filteredCountyOptions = this.searchFrmGrp.controls.countySearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'countyInput'))
                        );

                    this.zip2TechMaintenanceLocalService.setCounty(this.countyMainData);
                    this.showLoadingScreen = false;
                    this.getServcies();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getServcies();
                    return;
                }
            );
       }
    }

    private warningAlert(warningMsg: string) {
        this.alerts = [];
        this.alerts.push({
            id: 3,
            type: 'warning',
            message: warningMsg
        });
    }

    failedHttpRequest(err: any) {
        this.warningAlert(`Service error: Request Failed`);
    }

    dropDownValuesForAdd(){
        this.showLoadingScreen = true;
        let obj : any= {};
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;

        const languageRes = this.carrierZip2TechService.getLanguage(obj)
        const actionRes = this.carrierZip2TechService.getAction(obj)
        const marketRes = this.carrierZip2TechService.getMarket(obj)

        const sahcidRes = this.carrierZip2TechService.getSahcid(obj)
        const aidRes = this.carrierZip2TechService.getAid(obj)
        const vidRes = this.carrierZip2TechService.getVid(obj)
        const vcRes = this.carrierZip2TechService.getVc(obj)
        const comRes = this.carrierZip2TechService.getCom(obj)
        const localeRes = this.carrierZip2TechService.getLocale(obj)

        const siteTypRes = this.carrierZip2TechService.getSiteType(obj)
        const goToPhoneListRes = this.carrierZip2TechService.getGotoPhoneList(obj)
        const techRes = this.carrierZip2TechService.getTech(obj)

    forkJoin([languageRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        actionRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        marketRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        sahcidRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        aidRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        vidRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        vcRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        comRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        localeRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        siteTypRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        goToPhoneListRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),
        techRes.pipe(catchError(e => of(this.failedHttpRequest(e)))),]
        ).subscribe((res : any) => {
            if(res && res[0]){
                this.addLanguageData = res[0][0];
                this.filtertedAddLanguageData = [...this.addLanguageData];
            }
            if(res && res[1]){
                this.addActionData = res[1][0];
                if (this.addActionData.length == 1) {
                    this.addFormGroup
                        .get("action")
                        .setValue(this.addActionData[0]);
                }
            }
            if(res && res[2]){
                this.addMarketData = res[2][0];
                if (this.addMarketData.length == 1) {
                    this.addFormGroup
                        .get("market")
                        .setValue(this.addMarketData[0]);
                }
            }
            if(res && res[3]){
                this.addSahcidData = res[3][0];
                if (this.addSahcidData.length == 1) {
                    this.addFormGroup
                        .get("sahcid")
                        .setValue(this.addSahcidData[0]);
                }
            }
            if(res && res[4]){
                this.addAidData = res[4][0];
                if (this.addAidData.length == 1) {
                    this.addFormGroup
                        .get("aid")
                        .setValue(this.addAidData[0]);
                }
            }
            if(res && res[5]){
                this.addVidData = res[5][0];
                if (this.addVidData.length == 1) {
                    this.addFormGroup
                        .get("vid")
                        .setValue(this.addVidData[0]);
                }
            }
            if(res && res[6]){
                this.addVcData = res[6][0];
                if (this.addVcData.length == 1) {
                    this.addFormGroup
                        .get("vc")
                        .setValue(this.addVcData[0]);
                }
            }
            if(res && res[7]){
                this.addComData = res[7][0];
                if (this.addComData.length == 1) {
                    this.addFormGroup
                        .get("com")
                        .setValue(this.addComData[0]);
                }
            }
            if(res && res[8]){
                this.addLocaleData = res[8][0];
            }
            if(res && res[9]){
                this.addSiteTypeData = res[9][0];
            }
            if(res && res[10]){
                this.addGoToPhoneListData = res[10][0];
                if (this.addGoToPhoneListData.length == 1) {
                    this.addFormGroup
                        .get("gotoPhoneList")
                        .setValue(this.addGoToPhoneListData[0]);
                }
            }
            if(res && res[11]){
                this.addTechData = res[11][0];
                if (this.addTechData.length == 1) {
                    this.addFormGroup
                        .get("tech")
                        .setValue(this.addTechData[0]);
                }
            }
            this.showLoadingScreen = false
            if(this.zip2TechMaintenanceLocalService.getParentId() == null || 
            this.zip2TechMaintenanceLocalService.getParentId().length == 0 ) {
            this.getParentNames();
            } else {
                this.parentIdMainData = this.zip2TechMaintenanceLocalService.getParentId();
                this.resultFilteredParentId = this.parentIdMainData;
                this.addParentData = this.parentIdMainData;
                this.bulkparentDropDownData = this.parentIdMainData;
            }
        },
        err => this.failedHttpRequest(err));
    }

    revertAddForm() {
        this.addFormGroup.reset();
    }       

    // to retrieve state
    public getState() {
        if(this.zip2TechMaintenanceLocalService.getState() != null && this.zip2TechMaintenanceLocalService.getState().length > 0 ) {
            this.stateMainData = this.zip2TechMaintenanceLocalService.getState();
            this.filteredStateOptions = this.searchFrmGrp.controls.stateSearch.valueChanges
            .pipe(
                startWith<string>(''),
                map((name: any) => this._filter(name, 'stateInput'))
            );
            this.addStateData = [...this.stateMainData]
            this.getCountry();
        }
        
       else{ 
        this.showLoadingScreen = true;
        let obj: any = {};
        this.stateData = [];
        this.stateMainData = [];
        this.addStateData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getStates(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_STATE_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getCountry();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getCountry();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_STATES_FOUND")
                        );
                    this.stateMainData = data[0];
                    this.stateData = [];
                    this.addStateData = data[0];

                    // for state search
                    this.filteredStateOptions = this.searchFrmGrp.controls.stateSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'stateInput'))
                        );

                    this.showLoadingScreen = false;
                    this.zip2TechMaintenanceLocalService.setState(this.stateMainData);
                    this.getCountry();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getCountry();
                    return;
                }
            );
       }
    }

    // filter for multiple dropdown search
    private _filter(arg: string, choice) {
        let name = arg;
        if (name)
            name = name.toLowerCase();
        const filterValue = name;
        // Set selected values to retain the selected checkbox state
        this.setSelectedValues(choice);
        let filteredList;
        if (choice == "stateInput") {
            this.searchFrmGrp.controls.state.patchValue(this.stateData);
            filteredList = this.stateMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "countyInput") {
            this.searchFrmGrp.controls.county.patchValue(this.countyData);
            filteredList = this.countyMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "serviceInput") {
            this.searchFrmGrp.controls.service.patchValue(this.serviceData);
            filteredList = this.serviceMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "techkeyInput") {
            this.searchFrmGrp.controls.techkey.patchValue(this.techkeyData);
            filteredList = this.techkeyMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        return filteredList;
    }

    // setting selected values
    setSelectedValues(choice) {
        if (choice == "stateInput") {
            if (this.searchFrmGrp.controls.state.value && this.searchFrmGrp.controls.state.value.length > 0) {
                this.searchFrmGrp.controls.state.value.forEach((e) => {
                    if (this.stateData.indexOf(e) == -1) {
                        this.stateData.push(e);
                    }
                });
            }
        }
        if (choice == "countyInput") {
            if (this.searchFrmGrp.controls.county.value && this.searchFrmGrp.controls.county.value.length > 0) {
                this.searchFrmGrp.controls.county.value.forEach((e) => {
                    if (this.countyData.indexOf(e) == -1) {
                        this.countyData.push(e);
                    }
                });
            }
        }
        if (choice == "serviceInput") {
            if (this.searchFrmGrp.controls.service.value && this.searchFrmGrp.controls.service.value.length > 0) {
                this.searchFrmGrp.controls.service.value.forEach((e) => {
                    if (this.serviceData.indexOf(e) == -1) {
                        this.serviceData.push(e);
                    }
                });
            }
        }
        if (choice == "techkeyInput") {
            if (this.searchFrmGrp.controls.techkey.value && this.searchFrmGrp.controls.techkey.value.length > 0) {
                this.searchFrmGrp.controls.techkey.value.forEach((e) => {
                    if (this.techkeyData.indexOf(e) == -1) {
                        this.techkeyData.push(e);
                    }
                });
            }
        }
    }

    /*
  * Show error if any service call fails to complete
  */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }
    
public setZip2AndTechzipValue(event) {
    this.techZip = "&techzip=".concat(event);
    this.zip2 = "&zip=".concat(event);
}
    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    public zipCodeValidation(event) {
        this.errorMessage = "";
        let lengthError = "A Zip Code must have exactly 5 digits.";
        let limitError = "Zip Codes cannot exceed 40,000 limit";
        let stringError = "Zip Code must be number";
        let zipcodes: any = [];
        if (/\d/.test(event)) {
            //Splitting string based on the new line
            let zip = event.split("\n")
            zip = zip.filter(el => el !== '')
            for (let i = 0; i < zip.length; i++) {
                //removing spaces
                zip[i] = zip[i].replace(/\s/g, "");
                //checking if any value with comma exists
                if (zip[i].indexOf(',') > -1) {
                    //Sliting String based on the comma
                    let commaSeperatedArr = zip[i].split(",");
                    /*
                     * Validate Zip Code based on the length
                     * if Zip Codes are valid then pushing into 'zipcodes' array
                    */
                    for (let j = 0; j < commaSeperatedArr.length; j++) {
                        //validate Zip code if it is number or not
                        if (/^[0-9]*$/.test(commaSeperatedArr[j])) {
                            if (commaSeperatedArr[j].length != 0) {
                                if (commaSeperatedArr[j].length < 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else if (commaSeperatedArr[j].length > 5) {
                                    this.errorMessage = lengthError;
                                    break;
                                } else {
                                    zipcodes.push(commaSeperatedArr[j]);
                                    //check if zip codes exceeds 40,000
                                    if (zipcodes.length > 40000) {
                                        this.errorMessage = limitError;
                                        break;
                                    }
                                }
                            }
                        } else {
                            this.errorMessage = stringError;
                            break;
                        }
                    }
                }//validate Zip code if it is number or not
                else if (!/^[0-9]*$/.test(zip[i])) {
                    this.errorMessage = stringError;
                    break;
                }//Validate Zip Code based on the length  
                else if (zip[i].length < 5) {
                    if (zip[i].length != 0) {
                        this.errorMessage = lengthError;
                        break;
                    }
                }//Validate Zip Code based on the length 
                else if (zip[i].length > 5) {
                    this.errorMessage = lengthError;
                    break;
                }//if Zip Codes are valid then pushing into 'zipcodes' array
                else {
                    zipcodes.push(zip[i]);
                    //check if zip codes exceeds 40,000
                    if (zipcodes.length > 40000) {
                        this.errorMessage = limitError;
                        break;
                    }
                }
            }
        } else {
            event = event.toUpperCase();
            if (event == "ALL")
                zipcodes.push(event);
            else if (event.length > 0)
                this.errorMessage = stringError;
        }

        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            //filter duplicate zipcodes
            returnedZip = zipcodes.filter((val, index) => zipcodes.indexOf(val) == index);
            //removing empty elements
            returnedZip = returnedZip.filter(item => item);
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    /*
  * Show error when service returns error
  */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    //Used to Download Template
    exportToCSV() {
        let columns =["zips","state","county","techkey","prefParent","service","language","action","market"
            ,"zip2","aid","vid","vc","sahcid","com","locale","siteType","gotoPhoneList","tech",
            "techZip","pref1","pref2"];
        this.exportToCsvService.downloadFile(this.selectedZip2Techs, "Zip2Techexport", columns);
    }

}