import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class Zip2TechMaintenanceLocalService {
    private _state: any = [];
    private _county: any = [];
    private _techkey: any = [];
    private _service: any = [];
    private _parentId: any = [];
    constructor() { }

    public resetAllMultiRatePlanESN() {
        this._state = [];
        this._county = [];
        this._techkey = [];
        this._service = [];
        this._parentId = [];
    }
    public getParentId(): any {
        return this._parentId;
    }
    public setParentId(value: any) {
        this._parentId = value;
    }
    public getService(): any {
        return this._service;
    }
    public setService(value: any) {
        this._service = value;
    }
    public getTechkey(): any {
        return this._techkey;
    }
    public setTechkey(value: any) {
        this._techkey = value;
    }
    public getState(): any {
        return this._state;
    }
    public setState(value: any) {
        this._state = value;
    }
    public getCounty(): any {
        return this._county;
    }
    public setCounty(value: any) {
        this._county = value;
    }
}