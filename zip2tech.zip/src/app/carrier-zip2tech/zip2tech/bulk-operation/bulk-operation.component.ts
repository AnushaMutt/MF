import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../Services/toaster.service";
import { CarrierZip2TechService } from "../../../Services/carrier-zip2tech.service";
import { ExportToCsvService } from "../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../Services/import-from-csv.service";
import { CarrierZip2TechHelper } from "../../carrier-zip2tech-helper";
import { Zip2TechMaintenanceLocalService } from "../service/zip2techmaintenance";

@Component({
    selector: 'bulk-operation-zip2tech',
    templateUrl: './bulk-operation.component.html',
    styleUrls: ['./bulk-operation.component.scss',
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService],
})
export class BulkOperationZip2TechComponent implements OnInit {
    private unsubscribe = new Subject<void>();
    public flagColumn = false;
    public textColumns = false;
    public fileContent: Boolean;
    public fileContentDelete: Boolean;
    public filename: string = null;
    public filenameDelete: string = null;
    public uploadedData: any = [];
    public uploadedDataDelete: any = [];
    public uploadedMainData: any = [];
    public uploadedMainDataDelete: any = [];
    public alerts: any = [];
    public exportColumns = [];
    public exportColumnsDelete = [];
    public tableColmns = [];
    public tableColmnsDelete = [];
    readonly EXPORT_FILE_NAME = "Insert_Zip2Tech_template";
    readonly EXPORT_FILE_NAME_DELETE = "Delete_Zip2Tech_template";
    public showLoadingScreen: Boolean = false;
    public showMssg = false;
    public showAdd = false;
    public showDelete = true;
    label = "Click here to bulk insert";

    constructor(
        private toasterService: ToasterService,
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        private carrierZip2TechService: CarrierZip2TechService,
        private carrierZip2TechHelper: CarrierZip2TechHelper,
        private zip2TechMaintenanceLocalService: Zip2TechMaintenanceLocalService,
    ) { }

    ngOnInit() {
        this.showAdd = false;
        this.showDelete = true;
        this.label = "Click here to bulk insert";
        this.fileContent = false;
        this.fileContentDelete = false;
        this.filename = "";
        this.filenameDelete = "";

        this.uploadedData = [];
        this.uploadedMainData = [];
        this.alerts = [];
        this.exportColumns = ["Zip", "State", "County", "Techkey", "Parent Id", "Service",
            "Language"];
        this.exportColumnsDelete = ["Zip", "Techkey", "Service", "Language"];
        this.tableColmns = [
            { name: "Zip", prop: "zips", width: 180 },
            { name: "State", prop: "state", width: 190 },
            { name: "County", prop: "county", width: 190 },
            { name: "Techkey", prop: "techkey", width: 200 },
            { name: "Parent Id", prop: "prefParent", width: 200 },
            { name: "Service", prop: "service", width: 200 },
            { name: "Language", prop: "language", width: 195 },
        ];
        this.tableColmnsDelete = [
            { name: "Zip", prop: "zips", width: 180 },
            { name: "Techkey", prop: "techkey", width: 200 },
            { name: "Service", prop: "service", width: 200 },
            { name: "Language", prop: "language", width: 195 },
        ];
        this.showMssg = false;
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    exportToCSVDelete() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME_DELETE, this.exportColumnsDelete);
    }

    bulkInsertZip2Tech() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            this.uploadedMainData[i].dbEnv = this.carrierZip2TechHelper.dbEnv;
            delete this.uploadedMainData[i]['S.NO'];
            delete this.uploadedMainData[i].Zip;
            delete this.uploadedMainData[i].State;
            delete this.uploadedMainData[i].County;
            delete this.uploadedMainData[i].Techkey;
            delete this.uploadedMainData[i]['Parent Id'];
            delete this.uploadedMainData[i].Service;
            delete this.uploadedMainData[i].Language;
            delete this.uploadedMainData[i][''];

        }
        let uploadData = [];

        uploadData = this.uploadedMainData.filter((v, i, a) => a.findIndex(t => (t.zips === v.zips && t.state === v.state && t.county === v.county
            && t.service === v.service && t.language === v.language && t.techkey === v.techkey && t.prefParent === v.prefParent)) === i);


        let callTimes: number = Math.ceil(uploadData.length / 500);
        for (let i = 0; i < callTimes; i++) {
            let obj = [];
            for (let j = 500 * i; j < uploadData.length; j++) {
                if (j < (i + 1) * 500)
                    obj.push(uploadData[j]);
                else
                    break;
            }
            this.bulkInsert(obj);
        }
        this.zip2TechMaintenanceLocalService.setTechkey(null);
        this.zip2TechMaintenanceLocalService.setCounty(null);
        this.zip2TechMaintenanceLocalService.setService(null);
        this.zip2TechMaintenanceLocalService.setState(null);
        this.zip2TechMaintenanceLocalService.setParentId(null);
    }

    private bulkInsert(obj) {
        this.showLoadingScreen = true;
        this.carrierZip2TechService.bulkInsertZip2Tech(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_BULK_ADD_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.showMssg = true;
                    this.removeFile();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }


    bulkDeleteZip2Tech() {
        if (document.getElementsByClassName("tableError") && document.getElementsByClassName("tableError").length > 0) {
            this.toasterService.showErrorMessage("Please fix validation errors.");
            return;
        }
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            this.uploadedMainDataDelete[i].dbEnv = this.carrierZip2TechHelper.dbEnv;
            delete this.uploadedMainDataDelete[i]['S.NO'];
            delete this.uploadedMainDataDelete[i].Zip;
            delete this.uploadedMainDataDelete[i].Techkey;
            delete this.uploadedMainDataDelete[i].Service;
            delete this.uploadedMainDataDelete[i].Language;
            delete this.uploadedMainDataDelete[i][''];
        }
        let uploadData = [];

        uploadData = this.uploadedMainDataDelete.filter((v, i, a) => a.findIndex(t => (t.zips === v.zips
            && t.service === v.service && t.language === v.language && t.techkey === v.techkey)) === i);

        let callTimes: number = Math.ceil(uploadData.length / 500);
        for (let i = 0; i < callTimes; i++) {
            let obj = [];
            for (let j = 500 * i; j < uploadData.length; j++) {
                if (j < (i + 1) * 500)
                    obj.push(uploadData[j]);
                else
                    break;
            }
            this.bulkDelete(obj);
        }
    }

    private bulkDelete(obj) {
        this.showLoadingScreen = true;
        this.carrierZip2TechService.bulkDeleteZip2Tech(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_BULK_DELETE_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.showMssg = true;
                    this.removeFile();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Read File and show data on the table
    public changeListenerDelete(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        this.alerts = [];
        if (files && files.length > 0) {
            this.fileContentDelete = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filenameDelete = name.substr(0, name.lastIndexOf("."));
                if (this.filenameDelete.split(" ")[0] != this.EXPORT_FILE_NAME_DELETE) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                }else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumnsDelete.length; i++, j++) {
                        if (keys[i] != this.exportColumnsDelete[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.zips = _e1.Zip;
                        _e1.state = _e1.State;
                        _e1.county = _e1.County;
                        _e1.techkey = _e1.Techkey;
                        _e1.prefParent = _e1["Parent Id"];
                        _e1.service = _e1.Service;
                        _e1.language = _e1.Language;
                        _e1.action = _e1.Action;
                        _e1.market = _e1.Market;
                        _e1.zip2 = _e1.Zip2;
                        _e1.aid = _e1.AID;
                        _e1.vid = _e1.VID;
                        _e1.vc = _e1.VC;
                        _e1.sahcid = _e1.SAHCID;
                        _e1.com = _e1.Com;
                        _e1.locale = _e1.Locale;
                        _e1.siteType = _e1["Site Type"];
                        _e1.gotoPhoneList = _e1["Goto Phone List"];
                        _e1.tech = _e1.Tech;
                        _e1.techZip = _e1["Tech Zip"];
                        _e1.pref1 = _e1.Pref1;
                        _e1.pref2 = _e1.Pref2;
                    });
                    this.uploadedDataDelete = [...this.checkUploadedDataDelete(uploadData)];
                }
            }
        }
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        let invalidFile = "Please select a valid file to upload.";
        let noDataInFile = "There is no data to upload in this file.";
        this.alerts = [];
        if (files && files.length > 0) {
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name;
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != this.EXPORT_FILE_NAME) {
                    this.toasterService.showErrorMessage(invalidFile);
                    return;
                }
            } else {
                this.toasterService.showErrorMessage(invalidFile);
                return;
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let uploadData = this.importFromCsvService.csvToArray(reader.result);
                if (uploadData.length == 0) {
                    this.toasterService.showErrorMessage(noDataInFile);
                }else {
                    let keys = Object.keys(uploadData[0]);
                    for (let i = 1, j = 0; j < this.exportColumns.length; i++, j++) {
                        if (keys[i] != this.exportColumns[j]) {
                            this.toasterService.showErrorMessage(invalidFile);
                            return;
                        }
                    }
                    uploadData.forEach(_e1 => {
                        _e1.zips = _e1.Zip;
                        _e1.state = _e1.State;
                        _e1.county = _e1.County;
                        _e1.techkey = _e1.Techkey;
                        _e1.prefParent = _e1["Parent Id"];
                        _e1.service = _e1.Service;
                        _e1.language = _e1.Language;
                    });
                    this.uploadedData = [...this.checkUploadedData(uploadData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.fileContentDelete = false;
        this.filename = null;
        this.filenameDelete = null;

        this.uploadedData = [];
        this.uploadedMainData = [];
        this.uploadedDataDelete = [];
        this.uploadedMainDataDelete = [];
        this.alerts = [];
    }

    public checkUploadedDataDelete(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {

            if (element.rowNum.length == 0 || element.Zip.length == 0 || element.Techkey.length == 0 || element.Service.length == 0 || element.Language.length == 0
                || element.Zip.length > 5 || element.Techkey.length > 20 || element.Service.length > 20 || element.Language.length > 2) {
                errorData.push(element);
            } else
                successData.push(element);
        });
        this.uploadedMainDataDelete = [...errorData, ...successData];
        return this.uploadedMainDataDelete;
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {

            if (element.rowNum.length == 0 || element["Parent Id"].length == 0 || element.Zip.length == 0 || element.State.length == 0 || element.County.length == 0 || element.Techkey.length == 0 || element.Service.length == 0 || element.Language.length == 0
                ||element["Parent Id"].length > 30 || element.Zip.length > 5 || element.State.length > 2 || element.County.length > 50 || element.Techkey.length > 20 || element.Service.length > 20 || element.Language.length > 2 ) {
                errorData.push(element);
            } else
                successData.push(element);
        });
        this.uploadedMainData = [...errorData, ...successData];
        return this.uploadedMainData;
    }

    //Removes Row from the table
    deleteRow(row) {
        this.uploadedMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainData.splice(key, 1);
            }
        });
        this.uploadedData = [...this.uploadedMainData];
    }

    deleteRowDelete(row) {
        this.uploadedMainDataDelete.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.uploadedMainDataDelete.splice(key, 1);
            }
        });
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainData.length; i++) {
            if (this.uploadedMainData[i].rowNum == row.rowNum) {
                this.uploadedMainData[i][column] = event.target.value;
            }
        }
        this.uploadedData = [...this.uploadedMainData];
    }

    public editValueChangedDelete(event, column, row, oldValue) {
        for (let i = 0; i < this.uploadedMainDataDelete.length; i++) {
            if (this.uploadedMainDataDelete[i].rowNum == row.rowNum) {
                this.uploadedMainDataDelete[i][column] = event.target.value;
            }
        }
        this.uploadedDataDelete = [...this.uploadedMainDataDelete];
    }

    //Filter for result table
    public filterTableData(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainData.filter(function (d) {
            return (d.zips ? d.zips.indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.indexOf(val) !== -1 : !val) || !val
                || (d.county ? d.county.indexOf(val) !== -1 : !val) || !val
                || (d.techkey ? d.techkey.indexOf(val) !== -1 : !val) || !val
                || (d.prefParent ? d.prefParent.indexOf(val) !== -1 : !val) || !val
                || (d.service ? d.service.indexOf(val) !== -1 : !val) || !val
                || (d.language ? d.language.indexOf(val) !== -1 : !val) || !val
                ;
        });
        // update the rows
        this.uploadedData = temp;
    }

    //Filter for result table
    public filterTableDataDelete(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.uploadedMainDataDelete.filter(function (d) {
            return (d.zips ? d.zips.indexOf(val) !== -1 : !val) || !val
                || (d.techkey ? d.techkey.indexOf(val) !== -1 : !val) || !val
                || (d.service ? d.service.indexOf(val) !== -1 : !val) || !val
                || (d.language ? d.language.indexOf(val) !== -1 : !val) || !val
                ;
        });
        // update the rows
        this.uploadedDataDelete = temp;
    }

    setLikeButton(event) {
        this.filename = "";
        this.filenameDelete = "";
        this.uploadedData = [];
        this.uploadedDataDelete = [];
        this.uploadedMainData = [];
        this.uploadedMainDataDelete = [];
        this.fileContent = false;
        this.fileContentDelete = false;
        if (event.checked) {
            this.showAdd = true
            this.showDelete = false
            this.label = "Click here to bulk delete";
        } else {
            this.showDelete = true
            this.showAdd = false
            this.label = "Click here to bulk insert";
        }
    }
}