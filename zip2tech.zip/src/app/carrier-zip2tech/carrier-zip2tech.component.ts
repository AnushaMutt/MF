import { Component, OnInit, ViewEncapsulation, ViewChild, ChangeDetectorRef } from "@angular/core";
import { ConfirmationService, MenuItem } from "primeng/api";
import { routerTransition } from "./../router.animations";
import { MatTab, MatTabHeader, MatTabGroup } from "@angular/material/tabs";
import { Subject } from "rxjs";
import { DatabaseEnvService } from "./../Services/dbenv.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "./../Services/toaster.service";
import { CarrierZip2TechHelper } from "./carrier-zip2tech-helper";
import { Zip2TechMaintenanceLocalService } from "./zip2tech/service/zip2techmaintenance";

@Component({
    selector: "carrier-zip2tech",
    templateUrl: "./carrier-zip2tech.component.html",
    styleUrls: ["./carrier-zip2tech.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService],
    animations: [routerTransition()],
})

export class CarrierZip2TechComponent implements OnInit {
    // @ViewChild('tabs') tabs: MatTabGroup;
    public showLoadingScreen = false;
    private unsubscribe = new Subject<void>();
    public dbEnvironments = [];
    public dbEnvironmentsMainData = [];
    public frmGroupMain: FormGroup;
    public breadCrumbIndex = 0;
    public index = 0
    items: MenuItem[];
    home: MenuItem;
    public showTabs: boolean = false;
    public operationStarted = false;
    public clearData:any = 0;
    constructor(
        public cdRef: ChangeDetectorRef,
        private confirmationService: ConfirmationService,
        private dbenvService: DatabaseEnvService,
        private toasterService: ToasterService,
        private _formBuilder: FormBuilder,
        private carrierZip2TechHelper: CarrierZip2TechHelper,
        private zip2TechMaintenanceLocalService: Zip2TechMaintenanceLocalService
    ) { }

    ngOnInit() {
        this.showTabs = false;
        this.frmGroupMain = new FormGroup({});
        this.createForm();
        this.retrieveDBEnv();
        this.carrierZip2TechHelper.breadcrumbListUpdate.subscribe(menus => {
            this.items = [];
            this.carrierZip2TechHelper.breadcrumbList.forEach(bc => {
                bc && this.items.push({ "label": bc });
            });
        });
        this.home = {
            icon: "pi pi-home",
            command: _e => {
                this.index = -1;
                this.showTabs = false;
                // this.tabs.selectedIndex = 0;
                this.operationStarted = false;
            }
        };
        // this.tabs._handleClick = this.interceptTabChange.bind(this);
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            dbEnv: ["", Validators.required],
        });
        this.frmGroupMain.get("dbEnv").valueChanges.subscribe(val => {
            const dbEnvironemnt = this.dbEnvironments.find(
                db => db.name === val
            );
            if (dbEnvironemnt) {
                this.carrierZip2TechHelper.updateBreadcrumbList(
                    dbEnvironemnt.description,
                    1
                );
            }
        });
    }

    interceptTabChange(tab: MatTab, tabHeader: MatTabHeader, idx: number) {
        let result = false;
        this.confirmationService.confirm({
            key: "confirm-parentTab-changed",
            message: 'Are you sure you want to navigate from current tab ?',
            accept: () => {
                result = true;
                // return result && MatTabGroup.prototype._handleClick.apply(this.tabs, [tab, tabHeader, idx]);
            }
        });
    }

    ngAfterViewInit() {
        this.cdRef.detectChanges();
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        } else if (event.index == 3) {
            this.index = 3;
        }  
    }

    public retrieveDBEnv() {
        this.showLoadingScreen = true;
        this.carrierZip2TechHelper.emptyBreadcrumbList();
        // If envs were previously retrieved, get it from internal storage.
        if (this.dbenvService.isDBEnvsInStorage()) {
            this.dbEnvironments = this.dbenvService.getDbEnvsFromStorage();
            this.dbEnvironmentsMainData = this.dbEnvironments;
            // making database as default selected if one database is available
            if (this.dbEnvironments.length == 1) {
                this.frmGroupMain
                    .get("dbEnv")
                    .setValue(this.dbEnvironments[0].name);
                this.dbSelect(this.dbEnvironments[0].name);
            }
            this.showLoadingScreen = false;
        } else {
            // Get envs from service request.
            this.dbenvService
                .getDbEnvsFromService()
                .pipe(takeUntil(this.unsubscribe))
                .subscribe(
                    data => {
                        if (data[0] === null || data[0] === undefined) {
                            this.toasterService.showErrorMessage(
                                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE")
                            );
                            this.showLoadingScreen = false;
                            return;
                        }

                        this.dbEnvironments = data[0];
                        this.dbEnvironmentsMainData = this.dbEnvironments;
                        this.dbenvService.storeDbEnvs(this.dbEnvironments);
                        // making database as default selected if one database is available
                        if (this.dbEnvironments.length == 1) {
                            this.frmGroupMain
                                .get("dbEnv")
                                .setValue(this.dbEnvironments[0].name);
                            this.dbSelect(this.dbEnvironments[0].name);
                        }
                        this.showLoadingScreen = false;
                    },
                    (err: any) => {
                        this.showLoadingScreen = false;
                        if (err.error === undefined || err.error === null) {
                            this.toasterService.showErrorMessage(
                                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                            );
                        }
                        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                            return;
                        else this.toasterService.showErrorMessage(err.error);
                    }
                );
        }
    }

    public getDbEnvironments() {
        return this.dbEnvironments;
    }

    openedChange(option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
        }
    }

    onKey(value, option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
            this.dbEnvironments = this.search(value, this.dbEnvironments);
        }
    }

    search(value: string, searchArray: any) {
        let filter = value.toLowerCase();
        return searchArray.filter(
            option =>
                (option.description &&
                    option.description.toLowerCase().indexOf(filter) > -1)
        );
    }

    public dbSelect(dbEnv) {
        this.zip2TechMaintenanceLocalService.resetAllMultiRatePlanESN();
        this.index = 0;
        this.carrierZip2TechHelper.setDbEnv(dbEnv);
        this.showTabs = true;
        this.operationStarted = true;
        this.clearData = this.clearData + Math.random();
    }
}
