import { Component, OnInit, Input} from "@angular/core";

@Component({
    selector: 'bptech-wizard',
    templateUrl: './bptech.html',
})
export class BPTechComponent implements OnInit {
// @Input("clearData") clearData: any;

constructor() { }

ngOnInit() { }

}