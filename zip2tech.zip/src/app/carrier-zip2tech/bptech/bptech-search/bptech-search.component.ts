import { Component, OnInit, Input, SimpleChanges, ViewEncapsulation, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Observable, Subject } from "rxjs";
import { takeUntil, startWith, map } from "rxjs/operators";
import { ToasterService } from "../../../Services/toaster.service";
import { CarrierZip2TechService } from "../../../Services/carrier-zip2tech.service";
import { CarrierZip2TechHelper } from "../../carrier-zip2tech-helper";
import { ConfirmationService } from "primeng/api";
import { routerTransition } from "../../../router.animations";
import { ViewChildren } from "@angular/core";
import { MatSelect } from "@angular/material/select";
import { Zip2TechMaintenanceLocalService } from "../../zip2tech/service/zip2techmaintenance";
import { ExportToCsvService } from "../../../Services/export-to-csv.service";

@Component({
    selector: 'search-bptech',
    templateUrl: './bptech-search.component.html',
    styleUrls: ['./bptech-search.component.scss',
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService,ExportToCsvService],
    animations: [routerTransition()],
})
export class SearchBPTechComponent implements OnInit {
    public showLoadingScreen = false;
    public errorMessage = "";
    public alerts = [];
    private unsubscribe = new Subject<void>();
    public searchFrmGrp: FormGroup;
    public filteredValues: any = {};
    public selected = [];
    public bpTechData = [];
    public bpTechMainData = [];
    // public selectedBpTechData = [];
    // public selectedBpTechMainData = [];
    public techkeyMainData = [];
    public techkeyData = [];
    public serviceMainData = [];
    public serviceData = [];
    public bpCodeMainData = [];
    public bpCodeData = [];
    public productKeyMainData = [];
    public isEditable = {};
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public productKeyData = []; // selected data from search drop down
    //for search drop down
    filteredBpCodeOptions: Observable<any[]>;
    filteredProductKeyOptions: Observable<any[]>;
    filteredServiceOptions: Observable<any[]>;
    filteredTechkeyOptions: Observable<any[]>;
    public selectedBpTechs = [];
    public bulkEditBoolean: Boolean = false;
    public searchResultTableColumns = [];
    // for result dropdown search
    public resultFilteredService = [];
    public resultFilteredTechkey = [];
    public resultFilteredBpCode = [];
    public resultFilteredProductKey = [];
    public editAlreadyEnabled = false;
    public selectedBPTechs = [];
    // bulk BPTECH update
    public bulkEditColumns = [];
    public showBulkUpdateButton = false;
    public multiColumnEditSection = false;
    public otherColumn = false;
    public serviceColumnSelected = false;
    public techkeyColumnSelected = false;
    public bpCodeColumnSelected = false;
    public productKeyColumnSelected = false;
    public bulkServiceDropDownData = [];
    public bulktechkeyDropDownData = [];
    public bulkBpCodeDropDownData = [];
    public bulkProductKeyDropDownData = [];
    public multicolumnEditServiceValue = [];
    public multicolumnEditTechkeyValue = [];
    public multicolumnEditBpCodeValue = [];
    public multicolumnEditProductKeyValue = [];
    public inlinecolumnEditServiceValue = [];
    public inlinecolumnEditTechkeyValue = [];
    public inlinecolumnEditBpCodeValue = [];
    public inlinecolumnEditProductKeyValue = [];

//Add single
    public showAddButton: any = true;
    public addFormGroup: FormGroup;
    public showAddForm: any = false;
    public filtertedAddTechkeyData = [];
    public filtertedAddProductKeyData = [];
    public filtertedAddBpCodeData = [];
    public filtertedAddServiceData = [];

    public addServiceColumnValue = [];
    public addTechkeyColumnValue = [];
    public addBpCodeColumnValue = [];
    public addProductKeyColumnValue = [];


    constructor(
        private toasterService: ToasterService,
        private _formBuilder: FormBuilder,
        private carrierZip2TechHelper: CarrierZip2TechHelper,
        private carrierZip2TechService: CarrierZip2TechService,
        private confirmationService: ConfirmationService,
        private zip2TechMaintenanceLocalService: Zip2TechMaintenanceLocalService,
        private exportToCsvService :ExportToCsvService
    ) { }

    ngOnInit() {
        this.searchFrmGrp = new FormGroup({});
        this.createSearchForm();
        this.getTechkey();
        this.searchResultTableColumns = [
            { name: "Techkey", prop: "techkey", width: 80 },
            { name: "Service", prop: "service", width: 80 },
            { name: "BPCode", prop: "bpCode", width: 80 },
            { name: "Product Key", prop: "productKey", width: 80 },
        ]

        this.bulkEditColumns = [
            { name: "Techkey", prop: "techkey", width: 80 },
            { name: "Service", prop: "service", width: 80 },
            { name: "BPCode", prop: "bpCode", width: 80 },
            { name: "Product Key", prop: "productKey", width: 80 },
        ];

    }

    public autoCompChangeEvnt(event, selectedColumn) {
        if (selectedColumn == 'techkey') {
            this.addTechkeyColumnValue = event.option.value;
        }
        if (selectedColumn == 'service') {
            this.addServiceColumnValue = event.option.value;
        }
        if (selectedColumn == 'productKey') {
            this.addProductKeyColumnValue = event.option.value;
        }
        if (selectedColumn == 'bpCode') {
            this.addBpCodeColumnValue = event.option.value;
        }
    }

    //Form Group Used for add Form
    createAddForm() {
        this.addFormGroup = this._formBuilder.group({
            productKey: ['', [Validators.maxLength(150)]],
            techkey:['', [Validators.required,Validators.maxLength(20)]],
            bpCode:['',[Validators.required,Validators.maxLength(20)]],
            service:['',[Validators.required,Validators.maxLength(20)]],
        });
    }

     /*
    * Show Add form
    */
     public addFrom() {
        this.addFormGroup = new FormGroup({});
        this.createAddForm();
        this.showAddButton = false;
        this.showAddForm = true;
        this.reset();
        this.revertAddForm();
        this.alerts = [];
        // this.dropDownValuesForAdd();
    }


    /*
    * Remove Add form
    */
    public removeAddForm() {
        this.showAddButton = true;
        this.showAddForm = false;
        this.searchFrmGrp.reset();
        this.revertAddForm();
        this.alerts = [];

    }
    
    revertAddForm() {
        this.addFormGroup.controls.techkey.patchValue('');
        this.addFormGroup.controls.service.patchValue('');
        this.addFormGroup.controls.bpCode.patchValue('');
        this.addFormGroup.controls.productKey.patchValue('');

        this.filtertedAddBpCodeData = [...this.bpCodeMainData];
        this.filtertedAddServiceData = [...this.serviceMainData];
        this.filtertedAddTechkeyData = [...this.techkeyMainData];
        this.filtertedAddProductKeyData = [...this.productKeyMainData];
    } 

    public createAddBPTechRequest(req) {
        req.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        if(this.addServiceColumnValue.length > 0) {
            req.service = this.addServiceColumnValue;
        }
        if(this.addTechkeyColumnValue.length > 0) {
            req.techkey = this.addTechkeyColumnValue;
        }
        if(this.addBpCodeColumnValue.length > 0) {
            req.bpCode = this.addBpCodeColumnValue;
        }
        if(this.addProductKeyColumnValue.length > 0) {
            req.productKey = this.addProductKeyColumnValue;
        }
       this.insertBpTech(req);
    }

    public insertBpTech(requestData) {
        this.showLoadingScreen = true;
        this.carrierZip2TechService
            .addBPTech(requestData)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_ADD_BPTECH_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].message == "") {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DUPLICATE_BPTECH_FOUND")
                        );                        
                      return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_BPTECH_ADD_SUCCESS_MESSAGE")
                    );
                    this.showAddButton = true;
                    this.showAddForm = false;
                    this.showLoadingScreen = false;
                    this.addFormGroup.reset();
                    this.removeAddForm();
                    this.getTechkey();
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // confirm box
    public showConfirm(row) {
        this.confirmationService.confirm({
            key: 'confirm-delete-bptech',
            message: "Are you sure you want to delete BPTech ?",
            accept: () => {
                this.deleteBpTech(row);
            }
        });
    }

    public deleteBpTech(zip2techs) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        obj.zips = zip2techs.zips;
        obj.service = zip2techs.service;
        obj.bpCode = zip2techs.bpCode;
        obj.techkey = zip2techs.techkey;
        this.carrierZip2TechService.deleteBpTech(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DELETE_BPTECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DELETE_BPTECH_SUCCESS_MESSAGE")
                    );
                    this.searchBpTech(this.searchFrmGrp.value);
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Form Group Used for Search Form
    createSearchForm() {
        this.searchFrmGrp = this._formBuilder.group({
            techkey: [""],
            service: [""],
            bpCode: [""],
            productKey: [""],

            techkeySearch: ['', []],
            bpCodeSearch: ['', []],
            productKeySearch: ['', []],
            serviceSearch: ['', []],
        });
    }

    bulkUpdateBpTech() {
        this.showLoadingScreen = true;
        let requestObj = [];

        this.selectedBPTechs.forEach(e => {
            let obj: any = {};

            obj.oldBpCode = e.bpCode;
            obj.oldService = e.service;
            obj.oldTechkey = e.techkey;

            if (this.multicolumnEditServiceValue.length > 0) {
                obj.service = this.multicolumnEditServiceValue;
            } else {
                obj.service = e.service;
            }

            if (this.multicolumnEditTechkeyValue.length > 0) {
                obj.techkey = this.multicolumnEditTechkeyValue;
            } else {
                obj.techkey = e.techkey;
            }
            if (this.multicolumnEditProductKeyValue.length > 0) {
                obj.productKey = this.multicolumnEditProductKeyValue;
            } else {
                obj.productKey = e.productKey;
            }
            if (this.multicolumnEditBpCodeValue.length > 0) {
                obj.bpCode = this.multicolumnEditBpCodeValue;
            } else {
                obj.bpCode = e.bpCode;
            }

            obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
            requestObj.push(obj);
        });

        this.updateBPTech(requestObj, "");
    }

    updateBPTech(row, rowIndex) {
        if (document.getElementsByClassName("tableErr") && document.getElementsByClassName("tableErr").length > 0) {
            this.toasterService.showErrorMessage(
                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            this.showLoadingScreen = false;
            return;
        }
        this.showLoadingScreen = true;
        this.carrierZip2TechService.updateBPTech(row).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.bpTechMainData = [];
                    this.bpTechData = [];
                    this.selected = [];
                    this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                    this.selectedBPTechs = [];
                    this.multiColumnEditSection = false;
                    this.multicolumnEditBpCodeValue = [];
                    this.multicolumnEditProductKeyValue = [];
                    this.multicolumnEditServiceValue = [];
                    this.multicolumnEditTechkeyValue = [];
                    this.toasterService.showSuccessMessage(
                        this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_BPTECH_UPDATE_SUCCESS_MESSAGE")
                    );
                    this.searchBpTech(this.searchFrmGrp.value)
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public assignmultiColumnName(column) {
        // this.multicolumnEditColumnName = column;
        this.showBulkUpdateButton = false;
        this.otherColumn = true;
        if (column == 'service') {
            this.serviceColumnSelected = true;
            this.techkeyColumnSelected = false;
            this.productKeyColumnSelected = false;
            this.bpCodeColumnSelected = false;

        }
        else if (column == 'techkey') {
            this.serviceColumnSelected = false;
            this.techkeyColumnSelected = true;
            this.productKeyColumnSelected = false;
            this.bpCodeColumnSelected = false;
        }
        else if (column == 'bpCode') {
            this.serviceColumnSelected = false;
            this.techkeyColumnSelected = false;
            this.productKeyColumnSelected = false;
            this.bpCodeColumnSelected = true;
        }
        else if (column == 'productKey') {
            this.serviceColumnSelected = false;
            this.techkeyColumnSelected = false;
            this.productKeyColumnSelected = true;
            this.bpCodeColumnSelected = false;
        }
    }

    public showBulkUpdateButtonFun(event, selectedColumn) {
        // this.multicolumnEditColumnName = column;
        this.showBulkUpdateButton = true;
        if (selectedColumn == 'bpCode') {
            this.multicolumnEditBpCodeValue = event.option.value;
        }
        if (selectedColumn == 'productKey') {
            this.multicolumnEditProductKeyValue = event.option.value;
        }
        if (selectedColumn == 'service') {
            this.multicolumnEditServiceValue = event.option.value;
        }
        if (selectedColumn == 'techkey') {
            this.multicolumnEditTechkeyValue = event.option.value;
        }
    }

    public inlineUpdateWithAutoComp(event, selectedColumn) {
        // this.multicolumnEditColumnName = column;
        this.showBulkUpdateButton = true;
        if (selectedColumn == 'bpCode') {
            this.inlinecolumnEditBpCodeValue = event.option.value;
        }
        if (selectedColumn == 'productKey') {
            this.inlinecolumnEditProductKeyValue = event.option.value;
        }
        if (selectedColumn == 'service') {
            this.inlinecolumnEditServiceValue = event.option.value;
        }
        if (selectedColumn == 'techkey') {
            this.inlinecolumnEditTechkeyValue = event.option.value;
        }
    }

    inlineUpdateBPTech(row, rowIndex) {
        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        obj.oldTechkey = row.techkey;
        obj.oldService = row.service;
        obj.oldBpCode = row.bpCode;

        if (this.editedRow.productKey || this.inlinecolumnEditProductKeyValue.length > 0) {
            obj.productKey = this.editedRow.productKey;
            if(this.inlinecolumnEditProductKeyValue.length > 0) {
            obj.productKey = this.inlinecolumnEditProductKeyValue;
            }
        } else {
            obj.productKey = row.productKey;
        }

        if (this.editedRow.techkey || this.inlinecolumnEditTechkeyValue.length > 0) {
            obj.techkey = this.editedRow.techkey;
            if(this.inlinecolumnEditTechkeyValue.length > 0) {
            obj.techkey = this.inlinecolumnEditTechkeyValue;
            }
        } else {
            obj.techkey = row.techkey;
        }

        if (this.editedRow.service || this.inlinecolumnEditServiceValue.length > 0) {
            obj.service = this.editedRow.service;
            if(this.inlinecolumnEditServiceValue.length > 0) {
            obj.service = this.inlinecolumnEditServiceValue;
            }
        } else {
            obj.service = row.service;
        }

        if (this.editedRow.bpCode || this.inlinecolumnEditBpCodeValue.length > 0) {
            obj.bpCode = this.editedRow.bpCode;
            if(this.inlinecolumnEditBpCodeValue.length > 0) {
            obj.bpCode = this.inlinecolumnEditBpCodeValue;
            }
        } else {
            obj.bpCode = row.bpCode;
        }
        this.updateBPTech([obj], rowIndex);
    }


    // Checkbox selection from search result table
    public onSelect(row) {
        this.multiColumnEditSection = true;
        
        this.selectedBPTechs = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedBPTechs.push(obj);
            }
        }
        this.selectedBPTechs = [...this.selectedBPTechs]
        if (this.selectedBPTechs.length == 0) {
            this.bulkEditBoolean = false;
            this.otherColumn = false;
            this.showBulkUpdateButton = false;
            this.serviceColumnSelected = false;
            this.techkeyColumnSelected = false;
            this.productKeyColumnSelected = false;
            this.bpCodeColumnSelected = false;
        }
    }

    //Filter Table data based on all the columns values
    public filterBPTechTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.bpTechMainData.filter(function (d) {
            return (d.techkey ? d.techkey.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.service ? d.service.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.bpCode ? d.bpCode.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.productKey ? d.productKey.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.bpTechData = temp;
    }



    // cancel inline editing
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.searchResultTableColumns.forEach(e => {
            if (document.getElementById(e.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(e.prop + rowIndex)
                )).value = rowData[e.prop] || '';
            }
        });
        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    //Enable inline editing
    public editButtonClicked(rowData, rowIndex) {
        this.editAlreadyEnabled = true;
        this.defaultEditedRow = { ...rowData }
        let alreadyEnabled = false;
        for (let i = 0; i < this.searchResultTableColumns.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }

    public inputValueChanged(event, column, row, oldValue) {
        this.defaultEditedRow[column] = oldValue;
        this.editedRow[column] = event.value;

    }

    public onKey(value, rowData, column, row, isInlineEdit) {
        this.addServiceColumnValue = [];
        this.addTechkeyColumnValue = [];
        this.addBpCodeColumnValue = [];
        this.addProductKeyColumnValue = [];

        this.inlinecolumnEditBpCodeValue = [];
        this.inlinecolumnEditProductKeyValue = [];
        this.inlinecolumnEditTechkeyValue = [];
        this.inlinecolumnEditServiceValue = [];
        if (rowData == "tableServiceInput") {
            this.resultFilteredService = [...this.serviceMainData];
            this.resultFilteredService = this.search(value, 'tableServiceInput');
        }
        else if (rowData == "tableTechkeyInput") {
            this.resultFilteredTechkey = [...this.techkeyMainData];
            this.resultFilteredTechkey = this.search(value, 'tableTechkeyInput');
        }
        else if (rowData == "tableBpCodeInput") {
            this.resultFilteredBpCode = [...this.bpCodeMainData];
            this.resultFilteredBpCode = this.search(value, 'tableBpCodeInput');
        }
        else if (rowData == "tableProductKeyInput") {
            this.resultFilteredProductKey = [...this.productKeyMainData];
            this.resultFilteredProductKey = this.search(value, 'tableProductKeyInput');
        }

        else if (rowData == "bulkServiceInput") {
            this.multicolumnEditServiceValue = value;
            this.bulkServiceDropDownData = [...this.serviceMainData];
            this.bulkServiceDropDownData = this.search(value, 'bulkServiceInput');
        }
        else if (rowData == "bulkTechkeyInput") {
            this.multicolumnEditTechkeyValue = value;
            this.bulktechkeyDropDownData = [...this.techkeyMainData];
            this.bulktechkeyDropDownData = this.search(value, 'bulkTechkeyInput');
        }

        else if (rowData == "bulkBpCodeInput") {
            this.multicolumnEditBpCodeValue = value;
            this.bulkBpCodeDropDownData = [...this.bpCodeMainData];
            this.bulkBpCodeDropDownData = this.search(value, 'bulkBpCodeInput');
        }
        else if (rowData == "bulkProductKeyInput") {
            this.multicolumnEditProductKeyValue = value;
            this.bulkProductKeyDropDownData = [...this.productKeyMainData];
            this.bulkProductKeyDropDownData = this.search(value, 'bulkProductKeyInput');
        }
        else if (rowData == "addBpCodeInput") {
            this.filtertedAddBpCodeData = [...this.bpCodeMainData];
            this.filtertedAddBpCodeData = this.search(value, 'addBpCodeInput');
        }
        else if (rowData == "addServiceInput") {
            this.filtertedAddServiceData = [...this.serviceMainData];
            this.filtertedAddServiceData = this.search(value, 'addServiceInput');
        }
        else if (rowData == "addTechkeyInput") {
            this.filtertedAddTechkeyData = [...this.techkeyMainData];
            this.filtertedAddTechkeyData = this.search(value, 'addTechkeyInput');
        }
        else if (rowData == "addProductKeyInput") {
            this.filtertedAddProductKeyData = [...this.productKeyMainData];
            this.filtertedAddProductKeyData = this.search(value, 'addProductKeyInput');
        }

        if (isInlineEdit == 'islineEdit') {
            this.defaultEditedRow[column] = row[column];
            this.editedRow[column] = value;
        }

        if (value.length > 0) {
            this.showBulkUpdateButton = true;
        } else {
            this.showBulkUpdateButton = false;
        }
    }

    private search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "tableServiceInput" || choice == "bulkServiceInput" || choice == "addServiceInput") {
            this.serviceMainData = this.serviceMainData.filter(e => e != null);
            return this.serviceMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "tableTechkeyInput" || choice == "bulkTechkeyInput" || choice == "addTechkeyInput") {
            this.techkeyMainData = this.techkeyMainData.filter(e => e != null);
            return this.techkeyMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "tableBpCodeInput" || choice == "bulkBpCodeInput" || choice == "addBpCodeInput") {
            this.bpCodeMainData = this.bpCodeMainData.filter(e => e != null);
            return this.bpCodeMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
        else if (choice == "tableProductKeyInput" || choice == "bulkProductKeyInput" || choice == "addProductKeyInput") {
            this.productKeyMainData = this.productKeyMainData.filter(e => e != null);
            return this.productKeyMainData.filter(option => option.toLowerCase().indexOf(filter) > -1);
        }
    }

    searchBpTech(req) {
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.dbEnv = this.carrierZip2TechHelper.getDbEnv();
        obj.bpCode = req.bpCode.toString();
        obj.service = req.service.toString();
        obj.productKey = req.productKey.toString();
        obj.techkey = req.techkey.toString();
        this.inlinecolumnEditBpCodeValue = [];
        this.inlinecolumnEditProductKeyValue = [];
        this.inlinecolumnEditServiceValue = [];
        this.inlinecolumnEditTechkeyValue = [];

        this.multicolumnEditBpCodeValue = [];
        this.multicolumnEditProductKeyValue = [];
        this.multicolumnEditServiceValue = [];
        this.multicolumnEditTechkeyValue = [];

        this.bpTechMainData = [];
        this.bpTechData = [];
        this.selected = [];
        this.selectedBPTechs = [];
        this.isEditable = {};
        this.filteredValues = {};

        this.carrierZip2TechService.searchBpTech(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_ZIP2TECH_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;

                    this.bpTechMainData = data[0];
                    this.bpTechData = [...this.bpTechMainData];
                    if (this.filteredValues.mainTableFilter) {
                        this.filterBPTechTable(this.filteredValues.mainTableFilter);
                    }
                    this.editAlreadyEnabled = false;
                    if (this.bpTechMainData && this.bpTechMainData.length == 0) {
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_BPCODE_FOUND")
                        );
                        }
                        this.bulkEditBoolean = false;
                        this.otherColumn = false;
                        this.showBulkUpdateButton = false;
                        this.serviceColumnSelected = false;
                        this.techkeyColumnSelected = false;
                        this.productKeyColumnSelected = false;
                        this.bpCodeColumnSelected = false;
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    /*
    * Search Criteria form will get reset
    */
    public reset() {
        this.searchFrmGrp.controls.productKey.patchValue('');
        this.techkeyData = [];
        this.searchFrmGrp.controls.bpCode.patchValue('');
        this.serviceData = [];
        this.searchFrmGrp.controls.service.patchValue('');
        this.bpCodeData = [];
        this.searchFrmGrp.controls.techkey.patchValue('');
        this.productKeyData = [];
        this.errorMessage = "";
        this.filteredValues = {};
        this.editAlreadyEnabled = false;
        this.bulkEditBoolean = false;
        this.bpTechMainData = [];
        this.bpTechData = [];
this.isEditable = {};
    }


    // selection change to clear selected values
    selectionMultipleChange(event, choice) {
        if (event.isUserInput && event.source.selected == false) {
            if (choice == "productKeyInput") {
                let index = this.productKeyData.indexOf(event.source.value);
                if (index > -1)
                    this.productKeyData.splice(index, 1)
            }
            if (choice == "bpCodeInput") {
                let index = this.bpCodeData.indexOf(event.source.value);
                if (index > -1)
                    this.bpCodeData.splice(index, 1)
            }
            if (choice == "serviceInput") {
                let index = this.serviceData.indexOf(event.source.value);
                if (index > -1)
                    this.serviceData.splice(index, 1)
            }
            if (choice == "techkeyInput") {
                let index = this.techkeyData.indexOf(event.source.value);
                if (index > -1)
                    this.techkeyData.splice(index, 1)
            }
        }
    }


    // setting selected values
    setSelectedValues(choice) {
        if (choice == "productKeyInput") {
            if (this.searchFrmGrp.controls.productKey.value && this.searchFrmGrp.controls.productKey.value.length > 0) {
                this.searchFrmGrp.controls.productKey.value.forEach((e) => {
                    if (this.productKeyData.indexOf(e) == -1) {
                        this.productKeyData.push(e);
                    }
                });
            }
        }
        if (choice == "bpCodeInput") {
            if (this.searchFrmGrp.controls.bpCode.value && this.searchFrmGrp.controls.bpCode.value.length > 0) {
                this.searchFrmGrp.controls.bpCode.value.forEach((e) => {
                    if (this.bpCodeData.indexOf(e) == -1) {
                        this.bpCodeData.push(e);
                    }
                });
            }
        }
        if (choice == "serviceInput") {
            if (this.searchFrmGrp.controls.service.value && this.searchFrmGrp.controls.service.value.length > 0) {
                this.searchFrmGrp.controls.service.value.forEach((e) => {
                    if (this.serviceData.indexOf(e) == -1) {
                        this.serviceData.push(e);
                    }
                });
            }
        }
        if (choice == "techkeyInput") {
            if (this.searchFrmGrp.controls.techkey.value && this.searchFrmGrp.controls.techkey.value.length > 0) {
                this.searchFrmGrp.controls.techkey.value.forEach((e) => {
                    if (this.techkeyData.indexOf(e) == -1) {
                        this.techkeyData.push(e);
                    }
                });
            }
        }
    }

    // filter for multiple dropdown search
    private _filter(arg: string, choice) {
        let name = arg;
        if (name)
            name = name.toLowerCase();
        const filterValue = name;
        // Set selected values to retain the selected checkbox state
        this.setSelectedValues(choice);
        let filteredList;
        if (choice == "bpCodeInput") {
            this.searchFrmGrp.controls.bpCode.patchValue(this.bpCodeData);
            filteredList = this.bpCodeMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "productKeyInput") {
            this.searchFrmGrp.controls.productKey.patchValue(this.productKeyData);
            filteredList = this.productKeyMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "serviceInput") {
            this.searchFrmGrp.controls.service.patchValue(this.serviceData);
            filteredList = this.serviceMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        if (choice == "techkeyInput") {
            this.searchFrmGrp.controls.techkey.patchValue(this.techkeyData);
            filteredList = this.techkeyMainData.filter((option: any) => {
                if (typeof option == 'string' && option != null) {
                    return option.toLowerCase().indexOf(filterValue) > -1;
                }
            });
        }
        return filteredList;
    }

    public getTechkey() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.techkeyData = [];
        this.techkeyMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getTechKey(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_TECHKEY_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getService();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getService();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_TECHKEY_FOUND")
                        );
                    this.techkeyMainData = data[0];
                    this.zip2TechMaintenanceLocalService.setTechkey(this.techkeyMainData );
                    this.filtertedAddTechkeyData = [... this.techkeyMainData];
                    this.filteredTechkeyOptions = this.searchFrmGrp.controls.techkeySearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'techkeyInput'))
                        );
                    this.bulktechkeyDropDownData = data[0];
                    this.showLoadingScreen = false;
                    this.getService();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getService();
                    return;
                }
            );
    }


    public getService() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.serviceData = [];
        this.serviceMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getService(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_SERVICE_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getProductKey();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getProductKey();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_SERVICE_FOUND")
                        );
                    this.serviceMainData = data[0];
                    this.filtertedAddServiceData = [... this.serviceMainData];

                    this.filteredServiceOptions = this.searchFrmGrp.controls.serviceSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'serviceInput'))
                        );
                    this.bulkServiceDropDownData = data[0];
                    this.showLoadingScreen = false;
                    this.getProductKey();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getProductKey();
                    return;
                }
            );
    }

    public getProductKey() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.productKeyData = [];
        this.productKeyMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getProductKey(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PRODUCT_KEY_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        this.getBpCode();
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        this.getBpCode();
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_PRODUCT_KEY_FOUND")
                        );
                    this.productKeyMainData = data[0];
                    this.filtertedAddProductKeyData = [... this.productKeyMainData];
                    this.filteredProductKeyOptions = this.searchFrmGrp.controls.productKeySearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'productKeyInput'))
                        );
                    this.bulkProductKeyDropDownData = data[0];
                    this.showLoadingScreen = false;
                    this.getBpCode();
                },
                (err: any) => {
                    this.showErr(err);
                    this.getBpCode();
                    return;
                }
            );
    }


    public getBpCode() {
        this.showLoadingScreen = true;
        let obj: any = {};
        this.bpCodeData = [];
        this.bpCodeMainData = [];
        obj.dbEnv = this.carrierZip2TechHelper.dbEnv;
        this.carrierZip2TechService
            .getBpCode(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {

                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_BPCODE_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    if (data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.carrierZip2TechHelper.getTracfoneConstantMethod("NO_BPCODE_FOUND")
                        );
                    this.bpCodeMainData = data[0];
                    this.filtertedAddBpCodeData = [... this.bpCodeMainData]; 
                    this.filteredBpCodeOptions = this.searchFrmGrp.controls.bpCodeSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'bpCodeInput'))
                        );
                    this.bulkBpCodeDropDownData = data[0];
                    this.showLoadingScreen = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // resetting text field to show all dropdown values
    openedMultiChange(e) {
        this.searchFrmGrp.controls.bpCodeSearch.patchValue('');
        this.searchFrmGrp.controls.productKeySearch.patchValue('');
        this.searchFrmGrp.controls.serviceSearch.patchValue('');
        this.searchFrmGrp.controls.techkeySearch.patchValue('');
    }

    /*
 * Show error if any service call fails to complete
 */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.carrierZip2TechHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    /*
  * Show error when service returns error
  */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    //Used to Download Template
    exportToCSV() {
        let columns = [];
        this.searchResultTableColumns.forEach(x=>{
            columns.push(x.prop)
        })
        this.exportToCsvService.downloadFile(this.selectedBPTechs, "BPTechexport", columns);
    }
}