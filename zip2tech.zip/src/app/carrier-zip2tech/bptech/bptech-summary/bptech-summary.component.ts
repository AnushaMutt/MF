import { Component, OnInit, ViewEncapsulation, ViewChild} from "@angular/core";
import { takeUntil } from 'rxjs/operators';
import { Subject } from "rxjs";
import { CarrierZip2TechService } from "../../../Services/carrier-zip2tech.service";
import { CarrierZip2TechHelper } from "../../carrier-zip2tech-helper";
import { ToasterService } from "../../../Services/toaster.service";

@Component({
    selector: 'bulk-summary-bptech',
    templateUrl: './bptech-summary.component.html',
    styleUrls: ['./bptech-summary.component.scss',
    "../../../components/ngxtable/material.scss",
        "../../../components/ngxtable/datatable.component.scss",
        "../../../components/ngxtable/icons.css",
        "../../../components/ngxtable/app.css"],
    animations: [],
    encapsulation: ViewEncapsulation.None,
})
export class SummaryBPTechComponent implements OnInit {
    @ViewChild('table') table: any;
    public parentTableColumns = [];
    public childTableColumns = [];
    public parentTableMainData: any = [];
    public parentTableData = [];
    public childTableData = [];
    public childTableMainData = [];
    public unsubscribe = new Subject<void>();
    public showLoadingScreen: Boolean = false;
    public rowAlreadyExpanded: Boolean = false
    public alerts = [];

    constructor(
        private toasterService: ToasterService,
        private wizardService: CarrierZip2TechService,
        private helper: CarrierZip2TechHelper
    ) { }

    ngOnInit() {
        this.showLoadingScreen = false;
        this.parentTableColumns = [
            { name: "Create Date", prop: "createDate", width: "200" },
            { name: "Status", prop: "status", width: "200" },
            { name: "Total Records", prop: "totalRecord", width: "200" },
            { name: "Success Count", prop: "successCount", width: "200" },
            { name: "Error Count", prop: "errorCount", width: "200" },
        ];
        this.childTableColumns = [
            { name: "Details", prop: "details", width: "400" }
        ];
        this.getBulkInsertSummary();
    }
    // to retrieve Rate Plan ESN summary
    public getBulkInsertSummary() {
        this.showLoadingScreen = true;
        this.parentTableMainData = [];
        this.parentTableData = [];
        let obj: any = {};
        obj.dbEnv = "jndi/cop";
        this.wizardService
            .bulkInsertBPTechSummary(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_SUMMARY_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.parentTableData = [];
                    this.parentTableMainData = [];
                    this.parentTableMainData = data[0];
                    this.parentTableMainData.forEach(_e1 => {
                        let date: any;
                        _e1.expanded = false;
                        if (_e1.createDate)
                            _e1.createDate = _e1.createDate.split(" ")[0];
                        date = _e1.createDate.split(":");
                        _e1.createDate = date[1] + "/" + date[2] + "/" + date[0];
                    });
                    this.parentTableData = [...this.parentTableMainData];
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.failedAlert(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_SUMMARY_FOUND_ERROR_MESSAGE")
                        );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Toggle Search result table row details
    toggleExpandRow(row) {
        //If row detail already open then close it and vice-versa
        if (row.expanded) {
            this.rowAlreadyExpanded = false;
            this.parentTableData.forEach(e1 => { e1.expanded = false });
            this.table.rowDetail.toggleExpandRow(row);
            return;
        }
        // Else Open new row detail and close the existing one 
        else {
            this.rowAlreadyExpanded = true;
            this.parentTableData.forEach(e1 => { e1.expanded = false });
            row.expanded = !row.expanded;
            this.table.rowDetail.collapseAllRows();
        }
        this.showLoadingScreen = true;
        let obj: any = {};
        obj.dbEnv = "jndi/cop";
        obj.id = row.id;
        this.wizardService
            .getBulkInsertBpTechErrorRecordDetails(obj)
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_ERROR_DETAILS_ERROR_MESSAGE")
                        );
                        this.showLoadingScreen = false;
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.childTableData = [];
                    this.childTableMainData = [];
                    this.childTableMainData = data[0];
                    this.childTableData = [...this.childTableMainData];
                    this.table.rowDetail.toggleExpandRow(row);
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.helper.getTracfoneConstantMethod("TRACFONE_NO_ERROR_DETAILS_FOUND_ERROR_MESSAGE")
                        );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Filter parent Table data based on all the columns values
    public filterParentTable(event) {
        let val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.parentTableMainData.filter(function (d) {
            return (d.createDate ? d.createDate.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.parentTableData = temp;
    }

    //Filter Child Table data based on all the columns values
    public filterChildTable(event) {
        let val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.childTableMainData.filter(function (d) {
            return (d.details ? d.details.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.childTableData = temp;
    }
    /*
    * Show error if any service call fails to complete
    */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.helper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    /*
    * Show error when service returns error
    */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    private failedAlert(errorMsg: string) {
        window.scrollTo(0, 0);
        this.alerts.push({
            id: 4,
            type: 'danger',
            message: errorMsg
        });
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
}