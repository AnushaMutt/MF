import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCheckboxModule } from "@angular/material/checkbox";
import { SelectCheckAllComponent } from './select-check-all.component';

@NgModule({
    imports: [CommonModule, RouterModule, MatCheckboxModule],
    declarations: [SelectCheckAllComponent],
    exports: [SelectCheckAllComponent]
})
export class SelectCheckAllModule {}
