export class ApiFullToken{

	token_type: string;
	access_token: string; 
	expires_in: number;
	scope: string;
    brandName: string;
	sourceSystem: string;
	refresh_token: string;
	email: string;
}