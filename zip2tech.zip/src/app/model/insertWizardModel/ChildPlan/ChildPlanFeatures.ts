import { ChildPlan } from './ChildPlan';

export class ChildPlanFeatures {
	carrierName: string;
	childPlans: ChildPlan[];
}
