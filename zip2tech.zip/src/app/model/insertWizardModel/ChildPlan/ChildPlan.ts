import { RatePlanProfile } from '../RatePlanFeatures/RatePlanProfile'

export class ChildPlan {
    childPlanId: string;
    childPlanName: string;
    ratePlanProfile: RatePlanProfile[];
}
