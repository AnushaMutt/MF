import { Features } from './Features';

export class RatePlanProfile{
	profileId:string;
	profileDescription: string;
	features: Features[];
}