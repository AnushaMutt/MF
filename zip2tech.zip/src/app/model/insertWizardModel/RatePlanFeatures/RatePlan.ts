import { RatePlanProfile } from './RatePlanProfile';

export class RatePlan{
	ratePlanName: string;
	ratePlanProfile: RatePlanProfile[];
};