
export class Features{
	id: number;
	profileId: number;
	featureName: string;
	featureValue: string;
	featureRequirement: string;
	toggleFlag: string;
	displaySUIFlag: string;
	restrictSUIFlag: string;
}