export class CarrierOrderType{
	tfOnecarrier: string;
	orderTypes: string[];
}