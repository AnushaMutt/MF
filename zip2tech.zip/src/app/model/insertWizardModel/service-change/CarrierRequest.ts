export class CarrierRequest{
    min:string;
    sim:string;
    carrier:string;
    carrierUrl:string;
}