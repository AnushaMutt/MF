import { RatePlan } from '../RatePlanFeatures/RatePlan';
import { TransactionBucket } from './../../serviceModel/TransactionBucket';

export class CarrierDetails{
    min:string;
    esn:string;
    sim:string;
    make:string;
    model:string;
    lineStatus:string;
    lineFoundBy:string;
    linePlatform:string;
	rateplanProfile: RatePlan;
	buckets:TransactionBucket[];
}