import { RatePlanProfile } from '../RatePlanFeatures/RatePlanProfile'

export class ServicePlan {
    servicePlanId: string;
    servicePlanName: string;
    customerPrice: string;
    ratePlanProfile: RatePlanProfile[];
}
