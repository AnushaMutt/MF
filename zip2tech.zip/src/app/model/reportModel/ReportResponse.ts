
export class ReportResponse{

	jsonResponse: string;
	reportSQL: string;
    createDate: string;
}