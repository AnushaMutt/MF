
export class ServiceResponse{
	status: string;
	message: string;
}