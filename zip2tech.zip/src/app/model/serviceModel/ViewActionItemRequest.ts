import { AdditionalSearchField } from './AdditionalSearchField';
import { ViewActionItemPagination } from './ViewActionItemPagination';

export class ViewActionItemRequest{
	
	pagination: ViewActionItemPagination;
	additionalSearchColumns: AdditionalSearchField[] = [];
	actionItemId: string[] = [];
	transactionId: string[] = [];
	orderType: string[] = [];
	esn: string[] = [];
	status: string[] = [];
	statusMessage:string;
	fromCreationDate: string;
    toCreationDate: string;
	fromUpdateDate: string;
    toUpdateDate: string;
	isExactMatch:boolean;
	isExactMatchActionItemId:boolean;
    notInStatus:boolean;
    notInOrderType:boolean;
    notInStatusMessage:boolean;
    notInActionItemId:boolean;
    dbenv:string;
	userId:string;
	fromUserHistory:boolean;
}