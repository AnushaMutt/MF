export class AuditDetail{

	userid: number;
	action: string; 
	createdDate: string;
	details: string;
    carrierid: string;
}