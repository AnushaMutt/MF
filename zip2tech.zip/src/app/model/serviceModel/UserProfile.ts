import { UserGroup } from './UserGroup';
import { UserRole } from './UserRole';
import { UserInfo } from './UserInfo';

export class UserProfile{

	tfUser: UserInfo;
	tfGroups: UserGroup[] = [];
	tfRole: UserRole;

	constructor(user, groups, role) {
		this.tfUser = user;
		this.tfGroups = groups;
		this.tfRole = role;		
	}
}