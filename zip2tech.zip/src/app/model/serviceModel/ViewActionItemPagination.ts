
export class ViewActionItemPagination{
	startIndex: number;
	endIndex: number;
	total: number;
}