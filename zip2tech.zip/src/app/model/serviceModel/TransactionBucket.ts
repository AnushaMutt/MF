import { BucketTier } from "./BucketTier";

export class TransactionBucket{
    orgBucketId: string;
	orgBucketDirection: string;
	bucketId: string;
	bucketBalance: string;
	rechargeDate: string;
	bucketValue: string;
	expirationDate: string;
	direction: string;
	benefitType: string;
	bucketType: string;
	bucketUsage: string;
    bucketAction: string;
	bucketGroup: string;
	bucketRequirement: string;
	unitOfMeasurement: string;
	autoRenewFlag: string;
	autoRenewFrequency: string;
	autoRenewValue: string;
	autoRenewDay: string;
    dataExpirationDate: string;
    bucketTiers: BucketTier[];
}
