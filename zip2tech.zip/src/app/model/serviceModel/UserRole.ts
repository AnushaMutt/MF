
export class UserRole{
	roleId: number;
	roleName: string;
	rolePriority: number;

	constructor(roleId, roleName, rolePriority) {
		this.roleId = roleId;
		this.roleName = roleName;
		this.rolePriority = rolePriority;
	}
}