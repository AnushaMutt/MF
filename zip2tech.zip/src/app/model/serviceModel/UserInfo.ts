/**
 * Class used to represent the simple view from the Manage users action.
 */
export class UserInfo{
	userId: number;
	userName: string;
	email: string;
	token: string;
	description: string;
}