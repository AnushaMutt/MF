

export class DatabaseEnv{
	name: string;
	description: string;
}