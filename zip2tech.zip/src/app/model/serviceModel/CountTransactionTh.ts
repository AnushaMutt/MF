export class CountTransactionTh{

	carrier:           string;
	time:              string;
    transactionType:   string;
	sumQ:              string;
	sumL:              string;
	sumS:              string;
	sumNT:             string;
	sumE:              string;
	sumC:              string;
	sumOther:          string;
	totalTransactions: string;
}