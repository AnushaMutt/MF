
import { ViewActionItem } from './ViewActionItem';
import { ViewActionItemRequest } from './ViewActionItemRequest';
/**
 * Used for Requeue/Rework request
 */
export class ReworkTransactionRequest{
    searchCriteria : ViewActionItemRequest;
    reworkCriteria: ViewActionItem;
    reworkAll: boolean;
}