import {UserAction} from './UserAction';

export class UserGroup{
	groupId: string;
	groupName: string;
	groupDescription: string;
	tfActions: UserAction[] = [];
}