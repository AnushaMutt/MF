export class NgpToolDetail{
	zip: string;
	zip2: string;
	distance: string; 
	popcy: string;
	pop05: string;
}