export class ReportQueue{

	xDate :    string;
	template:  string;
	orderType: string;
	sumQ:      string;
	sumAllQ:   string;
	sumL:      string;
	sumAllL:   string;
	sumCp:     string;
	sumAllCp:  string;
	sumWp:     string;
	sumAllWp:  string;
	sumW:      string;
	sumAllW:   string;
	sumS:      string;
	sumAllS:   string;
	sumE:      string;
	sumAllE:   string;
	sumF:      string;
	sumAllF:   string;
	sumOther:  string;
	transType: string;
}