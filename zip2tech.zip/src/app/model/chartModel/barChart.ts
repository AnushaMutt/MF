
export class BarChart{
	data: string[];
	label: string;
}