import { registerApplication, start } from "single-spa";
import {
  constructApplications,
  constructRoutes,
  constructLayoutEngine,
} from "single-spa-layout";

const routes = constructRoutes(
  document.querySelector("#single-spa-layout") as HTMLTemplateElement
);
const applications = constructApplications({
  routes,
  loadApp({ name }) {
    if (
      window &&
      window.location &&
      window.location.href &&
      window.location.href.split("/")[2] &&
      window.location.href.split("/")[2].indexOf("sit") > -1
    ) {
      return System.import("sit-" + name);
    } else if (
      window &&
      window.location &&
      window.location.href &&
      window.location.href.split("/")[2] &&
      window.location.href.split("/")[2].indexOf("testcop") > -1
    ) {
      return System.import("tst-" + name);
    } else if (
      window &&
      window.location &&
      window.location.href &&
      window.location.href.split("/")[2] &&
      window.location.href.split("/")[2].indexOf("local") > -1
    ) {
      return System.import("local-" + name);
    } else {
      return System.import(name);
    }
  },
});
const layoutEngine = constructLayoutEngine({ routes, applications });

applications.forEach(registerApplication);
layoutEngine.activate();
start();
