import { ViewActionItem } from '../serviceModel/ViewActionItem';

export class TransactionArchive{   
   actionItem: ViewActionItem;
   id: string;
   userId: string;
   actionItemId: string;
   status: string;
   createdDate: string;
   modifiedDate: string;
   deactivationDate: string;
   hoursSinceLastModify: number;
   daysToExtend: number;
}