import { ServicePlan } from './ServicePlan';

export class ServicePlanFeatures {
	carrierName: string;
	servicePlans: ServicePlan[];
}
