import { RatePlan } from './RatePlan';

export class RatePlanFeatures{
	carrierName: string;	
	ratePlans: RatePlan[];
}