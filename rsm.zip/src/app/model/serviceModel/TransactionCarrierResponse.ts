
export class TransactionCarrierResponse{
	transactionId: string;
	xmlResponse: string;
	updateDate: string;
	creationDate: string;
}