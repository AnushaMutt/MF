import { BucketTier } from "./BucketTier";

export class BucketDetailRequest {
    bucketId: string;
    bucketBalance: string;
    rechargeDate: string;
    bucketValue: string;
    expirationDate: string;
    direction: string;
    benefitType: string;
    bucketType: string;
    bucketUsage: string;
    bucketAction: string;
	bucketDescription: string;
	env: string;
    transactionId: string;
    orgBucketDirection: string;
    orgBucketId: string;
    bucketGroup: string;
	bucketRequirement: string;
	unitOfMeasurement: string;
	autoRenewFlag: string;
	autoRenewFrequency: string;
	autoRenewValue: string;
	autoRenewDay: string;
    dataExpirationDate: string;
    bucketTiers: BucketTier[];
}