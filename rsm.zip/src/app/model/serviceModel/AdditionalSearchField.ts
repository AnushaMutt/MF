export class AdditionalSearchField{
    searchColumnName: string;
    searchColumnType: string;
    searchValues: string[] = [];
    searchIsColumnLike: boolean;
    searchIsColumnNotIn: boolean;
}
