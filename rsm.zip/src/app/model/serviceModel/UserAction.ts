export class UserAction{
	actionId: number;
	actionName: string;
	route: string;
  	description: string;  
}