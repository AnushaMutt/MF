export class ViewThErrors{

    xDate: string;
    parentName: string;
    transactType: string; 
    newApiMessage: string;
    transactionNum: string;
    cnt: string;
    rnk2: string; 
}