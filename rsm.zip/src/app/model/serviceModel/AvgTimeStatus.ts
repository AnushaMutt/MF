export class AvgTimeStatus{

	carrier: string;
	xDate: string;
	orderType: string; 
	timeWaiting: string;
	count: string;
}