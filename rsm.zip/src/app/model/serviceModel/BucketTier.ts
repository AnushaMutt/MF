export class BucketTier {
    usageTierId: string;
    tierValue: string;
    tierBehavior: string;
}
