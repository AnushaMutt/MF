export class AvgTimeTemplate{

	carrier: string;
	orderType: string;
	timeSegment: string; 
	avgTimeCarrier: string;
	avgTimeDB: string;
	totalTransactions: string;
}