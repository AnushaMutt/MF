export class ViewCarrierErrors{

	createddate: string;
    carrier: string;
    errorDescription: string;
    errorCount: number;
}