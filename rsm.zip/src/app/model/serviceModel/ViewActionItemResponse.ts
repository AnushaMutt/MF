import { ViewActionItem } from './ViewActionItem';
import { ViewActionItemPagination } from './ViewActionItemPagination';

export class ViewActionItemResponse{
	
	actionItems: ViewActionItem[];
	paginationSearch: ViewActionItemPagination;
}