
import { forkJoin as observableForkJoin, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { UserGroup } from './../model/serviceModel/UserGroup';
import { UserAction } from './../model/serviceModel/UserAction';
import { UserProfile } from './../model/serviceModel/UserProfile';
import { UserInfo } from './../model/serviceModel/UserInfo';
import { UserRole } from './../model/serviceModel/UserRole';
import { ServiceResponse } from './../model/serviceModel/ServiceResponse';
import { URLHandlerService } from './urlhandler.service';

@Injectable()
export class AdminService {
        
    readonly  HTTP_URL_PROFILE = "profile";
    readonly  HTTP_URL_USERS = "users";
    readonly  HTTP_URL_ACTIONS = "actions";
    readonly  HTTP_URL_GROUPS = "groups";
    readonly  HTTP_URL_GROUP = "group";
    readonly  HTTP_URL_ROLES = "roles";

    constructor(private http: HttpClient, private urlHandler: URLHandlerService) { }
    
    /**
     * Retrieves a users profile with Groups/Actions and Role.
     */
    getProfile():Observable<UserProfile>{        
        return this.http.get<UserProfile>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_PROFILE);
    }
    
    getuserProfile(userId: number):Observable<UserProfile>{         
        return this.http.get<UserProfile>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_PROFILE+ "/" + userId);
    }
    
    getAllUsers():Observable<UserInfo[]>{
         return this.http.get<UserInfo[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_USERS);
    }
    
    getAllUsersWithAction(actionId: string):Observable<UserInfo[]>{
        return this.http.get<UserInfo[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_USERS + "/" + actionId);
    }
    
    getAllActions(userId: string):Observable<UserAction[]>{
         return this.http.get<UserAction[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_ACTIONS + "/" + userId);
    }
    
    getAllGroups(userId:number):Observable<UserGroup[]>{
         return this.http.get<UserGroup[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_GROUPS + "/" + userId);
    }
    
    getGroup(groupId: string):Observable<UserGroup>{
         return this.http.get<UserGroup>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_GROUP + "/" + groupId);
    }
    
    getRoles():Observable<UserRole[]>{
         return this.http.get<UserRole[]>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_ROLES);
    }    
    
    createGroup(group: UserGroup){
        return this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_GROUP, group);
    }
    
    updateGroup(group: UserGroup){
        return this.http.put<ServiceResponse>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_GROUP, group);
    }
       
    createUser(userProfile: UserProfile){    
        return this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_USERS, userProfile);
    }
    
    updateUser(userProfile: UserProfile){    
        return this.http.put<ServiceResponse>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_USERS, userProfile);
    }
    
    deleteUser(userId:string):Observable<ServiceResponse>{
        return this.http.post<ServiceResponse>(this.urlHandler.HTTP_URL_ADMIN + this.HTTP_URL_PROFILE + "/" + userId, '');
   }
    
   getProfileRolesAndGroups(adminUserId: number, userId: number){
		return observableForkJoin(
				this.getuserProfile(userId),
				this.getRoles(),
				this.getAllGroups(adminUserId)
		);
	}
	
	getRolesAndGroups(userId: number){
		return observableForkJoin(
				this.getRoles(),
				this.getAllGroups(userId)
		); 
	}
    
    getGroupAndAvilableActions(groupId: string, userId: string){
        return observableForkJoin(
                this.getGroup(groupId),
                this.getAllActions(userId)
        ); 
    }
}
