
import { throwError as observableThrowError, Subject, Observable, of } from 'rxjs';
import { Injectable, Injector } from '@angular/core';
import {
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';

const urls = [

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/getparents',
        json: [{
            "objId": "539",
            "status": "A",
            "retailer": "7-11 Non Corporate",
            "secUserId": "4",
            "insertDate": "2013:02:25 12:02:00",
            "updateDate": "2021:11:26 12:11:00",
            "lastTraitRunDate": "2021-11-26 01:57:34"
        }, {
            "objId": "1",
            "status": "A",
            "retailer": "AAFES_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2020:08:13 12:08:00",
            "lastTraitRunDate": "2021-05-24 11:34:01"
        }, {
            "objId": "590",
            "status": "A",
            "retailer": "ABC_WAREHOUSE_MASTER",
            "secUserId": "14",
            "insertDate": "2014:01:24 12:01:00",
            "updateDate": "2021:02:08 12:02:00",
            "lastTraitRunDate": "2021-05-24 12:01:35"
        }, {
            "objId": "583",
            "status": "A",
            "retailer": "ACE_CASH_EXPRESS",
            "secUserId": "4",
            "insertDate": "2013:07:02 12:07:00",
            "updateDate": "2021:11:26 12:11:00",
            "lastTraitRunDate": "2021-03-22 10:50:35"
        }, {
            "objId": "3",
            "status": "C",
            "retailer": "ALBERTSONS_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2020:08:13 12:08:00",
            "lastTraitRunDate": "2021-06-11 08:20:35"
        }, {
            "objId": "4",
            "status": "A",
            "retailer": "ALDI_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": "2021-05-24 12:01:44"
        }, {
            "objId": "165",
            "status": "A",
            "retailer": "ALLIED_CASH_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": "2021-05-21 09:34:41"
        }, {
            "objId": "5",
            "status": "A",
            "retailer": "ALLSUP_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": "2021-05-17 05:43:59"
        }, {
            "objId": "6",
            "status": "A",
            "retailer": "AMMARS_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": "2021-05-19 06:15:53"
        }, {
            "objId": "7",
            "status": "A",
            "retailer": "AUTO_PARTS_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": null
        }, {
            "objId": "519",
            "status": "C",
            "retailer": "B\u0026R",
            "secUserId": "4",
            "insertDate": "2012:10:03 12:10:00",
            "updateDate": null,
            "lastTraitRunDate": "2021-05-19 03:51:38"
        }, {
            "objId": "207",
            "status": "C",
            "retailer": "BARNES_NOBLES_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 12:08:00",
            "updateDate": "2012:08:08 12:08:00",
            "lastTraitRunDate": "2021-05-17 05:43:38"
        }, {
            "objId": "588",
            "status": "A",
            "retailer": "BARTELL",
            "secUserId": "4",
            "insertDate": "2013:11:20 12:11:00",
            "updateDate": null,
            "lastTraitRunDate": null
        }, {
            "objId": "610",
            "status": "A",
            "retailer": "BCP_STORES",
            "secUserId": "14",
            "insertDate": "2016:05:10 12:05:00",
            "updateDate": null,
            "lastTraitRunDate": "2021-05-19 09:24:35"
        }, {
            "objId": "9",
            "status": "A",
            "retailer": "BEST_BUY_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": null
        }, {
            "objId": "162",
            "status": "A",
            "retailer": "BIGLOTS_TRAITS",
            "secUserId": "1",
            "insertDate": "2012:08:08 05:08:22",
            "updateDate": "2012:08:08 05:08:22",
            "lastTraitRunDate": null
        }]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/getcarriers',
        json: [{"objId":"101","secUserId":"1","status":"C","carrier":"ATNI","carrierLong":"ATNI","insertDate":"2012:08:08 00:00:00","updateDate":"2021:11:30 00:00:00"},{"objId":"72","secUserId":"4","status":"C","carrier":"ATT 3G WIRELESS","carrierLong":"ATT 3G WIRELESS","insertDate":"2013:10:23 00:00:00","updateDate":"2021:11:30 00:00:00"},{"objId":"2","secUserId":"1","status":"A","carrier":"ATT 4G WIRELESS","carrierLong":"ATT 4G WIRELESS","insertDate":"2014:07:31 00:00:00","updateDate":"2014:07:31 00:00:00"},{"objId":"76","secUserId":"1","status":"A","carrier":"ATT PREPAY PLATFORM","carrierLong":"AT\u0026T PREPAY PLATFORM","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"71","secUserId":"1","status":"A","carrier":"ATT SAFELINK","carrierLong":"AT\u0026T SAFELINK","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"68","secUserId":"2","status":"A","carrier":"CLARO","carrierLong":"CLARO","insertDate":"2012:08:08 00:00:00","updateDate":"2016:01:28 00:00:00"},{"objId":"22","secUserId":"1","status":"C","carrier":"FIVE STAR CELLULAR","carrierLong":"FIVE STAR CELLULAR","insertDate":"2012:08:08 00:00:00","updateDate":"2021:01:08 00:00:00"},{"objId":"25","secUserId":"1","status":"A","carrier":"INLAND CELLULAR","carrierLong":"INLAND CELLULAR","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"32","secUserId":"1","status":"A","carrier":"PIONEER ENED CELLULAR","carrierLong":"PIONEER ENED CELLULAR","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"102","secUserId":"2","status":"C","carrier":"REMOVED","carrierLong":null,"insertDate":"2015:03:16 00:00:00","updateDate":"2016:12:05 00:00:00"},{"objId":"99","secUserId":"1","status":"A","carrier":"SPRINT","carrierLong":"SPRINT","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"97","secUserId":"14","status":"C","carrier":"Sprint LTE","carrierLong":"SPRINT WIRELESS LTE","insertDate":"2013:10:29 00:00:00","updateDate":"2016:02:17 00:00:00"},{"objId":"98","secUserId":"1","status":"A","carrier":"SPRINT_NET10","carrierLong":"SPRINT_NET10","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"55","secUserId":"1","status":"A","carrier":"T-MOBILE","carrierLong":"T-MOBILE","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"77","secUserId":"1","status":"A","carrier":"T-MOBILE PREPAY PLATFORM","carrierLong":"T-MOBILE PREPAY PLATFORM","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"},{"objId":"73","secUserId":"1","status":"A","carrier":"T-MOBILE SAFELINK","carrierLong":"T-MOBILE SAFELINK","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00"}]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/getbrands',
        json: [{"objId":"14","oneSecUserId":"4","status":"A","brand":"BYOP","brandLong":"Bring Your Own Phone","insertDate":"2013:05:14 00:00:00","updateDate":"2021:11:29 00:00:00","cRtlTraitLogicRuleId":null},{"objId":"23","oneSecUserId":"4","status":"A","brand":"BYOP_3G","brandLong":"Bring Your Phone 3G","insertDate":"2013:07:02 00:00:00","updateDate":"2021:02:04 00:00:00","cRtlTraitLogicRuleId":null},{"objId":"24","oneSecUserId":"14","status":"C","brand":"BYOP_LTE","brandLong":"Bring your own Phone LTE 123","insertDate":"2013:10:16 00:00:00","updateDate":"2021:11:29 00:00:00","cRtlTraitLogicRuleId":"3"},{"objId":"13","oneSecUserId":"2","status":"A","brand":"HF","brandLong":"Home Phone Service","insertDate":"2013:03:12 00:00:00","updateDate":null,"cRtlTraitLogicRuleId":"3"},{"objId":"2","oneSecUserId":"1","status":"A","brand":"NT","brandLong":"Net10","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00","cRtlTraitLogicRuleId":"1"},{"objId":"16","oneSecUserId":"14","status":"A","brand":"NT_3G","brandLong":"Net10 3G","insertDate":"2013:07:02 00:00:00","updateDate":"2016:02:17 00:00:00","cRtlTraitLogicRuleId":"1"},{"objId":"5","oneSecUserId":"1","status":"A","brand":"NT_AN","brandLong":"Net10 Android","insertDate":"2012:08:08 00:00:00","updateDate":"2012:08:08 00:00:00","cRtlTraitLogicRuleId":"3"},{"objId":"18","oneSecUserId":"14","status":"A","brand":"NT_AN_3G","brandLong":"Net10 Android 3G","insertDate":"2013:07:02 00:00:00","updateDate":"2016:02:17 00:00:00","cRtlTraitLogicRuleId":"3"},{"objId":"7","oneSecUserId":"4","status":"A","brand":"SIM","brandLong":"Simple","insertDate":"2012:08:17 00:00:00","updateDate":"2013:02:20 00:00:00","cRtlTraitLogicRuleId":"3"},{"objId":"11","oneSecUserId":"2","status":"A","brand":"SIM_AN","brandLong":"Simple Android","insertDate":"2013:01:31 00:00:00","updateDate":"2013:09:17 00:00:00","cRtlTraitLogicRuleId":"3"},{"objId":"32","oneSecUserId":"2","status":"C","brand":"SIM_BAND12","brandLong":"Simple","insertDate":"2018:09:12 00:00:00","updateDate":"2018:09:13 00:00:00","cRtlTraitLogicRuleId":"1"},{"objId":"28","oneSecUserId":"2","status":"C","brand":"SIM_BAND2","brandLong":"Simple","insertDate":"2018:09:11 00:00:00","updateDate":"2018:09:13 00:00:00","cRtlTraitLogicRuleId":"1"}]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/1/getmasters',
        json: [ { "objId":"3817", "status":"A", "storeName":"1", "master2Parent":"1", "secUserId":"1", "insertDate":"2020:08:05 05:37:26", "updateDate":"2021:02:17 00:00:00" }, { "objId":"1", "status":"A", "storeName":"AAFES", "master2Parent":"1", "secUserId":"1", "insertDate":"2012:08:08 17:08:43", "updateDate":"2012:08:08 17:08:43" }, { "objId":"3262", "status":"A", "storeName":"TEST_STORE", "master2Parent":"1", "secUserId":"1", "insertDate":"2012:08:08 00:00:00", "updateDate":"2012:11:30 00:00:00" } ]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/getradius',
        json: [ 1, 3, 5, 6, 7, 10, 12, 15, 20, 25, 30, 35, 55, 56, 57, 60 ]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/searchlocations',
        json: [ { "objId":"402079", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"09862", "zip":"12345", "brand":null, "radius":"5", "state":"NY", "lastUpdateDate":"2021-12-09 03:53:35.0" }, { "objId":"402081", "masterId":"3848", "parentId":"161", "storeName":"WALMART", "storeNum":"1254", "zip":"12345", "brand":null, "radius":"57", "state":"NY", "lastUpdateDate":"2021-11-18 07:48:30.0" }, { "objId":"402082", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"1254", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-18 07:49:25.0" }, { "objId":"402141", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"1290", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-24 07:53:31.0" }, { "objId":"402142", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"1291", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-24 07:53:44.0" }, { "objId":"402080", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"3456", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-18 07:25:54.0" }, { "objId":"402147", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"5566", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 09:11:50.0" }, { "objId":"402160", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"5643", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-12-09 04:04:03.0" }, { "objId":"402145", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"56788", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 08:49:05.0" }, { "objId":"402143", "masterId":"3589", "parentId":"161", "storeName":"DOLLAR GENERAL TRAITS", "storeNum":"56789", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 08:35:28.0" }, { "objId":"402144", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"56789", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 08:38:51.0" }, { "objId":"402086", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"6789", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-22 09:35:36.0" }, { "objId":"402084", "masterId":"3589", "parentId":"161", "storeName":"DOLLAR GENERAL TRAITS", "storeNum":"6789", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-22 09:22:00.0" }, { "objId":"402087", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"6799", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-22 09:35:36.0" }, { "objId":"402085", "masterId":"3589", "parentId":"161", "storeName":"DOLLAR GENERAL TRAITS", "storeNum":"6799", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-22 09:22:03.0" }, { "objId":"402159", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"70012", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-12-02 09:32:37.0" }, { "objId":"402149", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"76789", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 09:28:56.0" }, { "objId":"402148", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"7766", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 09:23:38.0" }, { "objId":"402150", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"86781", "zip":"12345", "brand":null, "radius":"15", "state":"NY", "lastUpdateDate":"2021-11-29 08:10:39.0" }, { "objId":"402161", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"8790", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-12-09 04:04:04.0" }, { "objId":"402146", "masterId":"2051", "parentId":"161", "storeName":"DOLLAR GENERAL STORE", "storeNum":"9876", "zip":"12345", "brand":null, "radius":"10", "state":"NY", "lastUpdateDate":"2021-11-26 08:54:58.0" } ]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/analysetraits',
        json: { "402079":"" }
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/1/getlasttraitrundate',
        json: { "status":"Success", "message":"2020-12-08 08:39:09.0" }
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/gettraitdetails/402079',
        json: [ { "radius":"20", "traits":"1", "brand":"BYOP", "carrier":"ATT WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"NT", "carrier":"ATT WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"NT_AN", "carrier":"ATT WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"TF", "carrier":"ATT WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"BLUEGRASS CELLULAR", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"CELL COM", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"CELLULAR ONE OF NE PA", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"INLAND CELLULAR", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"PIONEER ENED CELLULAR", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"BYOP", "carrier":"SPRINT", "tech":"CDMA", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"103", "percZipDplyd":"92", "popDplyd":"1725442", "percPopDplyd":"97", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"0", "brand":"BYOP", "carrier":"T-MOBILE_3G", "tech":"3G", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"77", "percZipDplyd":"69", "popDplyd":"1086952", "percPopDplyd":"61", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"0", "brand":"TEL_TF", "carrier":"T-MOBILE_3G", "tech":"3G", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"77", "percZipDplyd":"69", "popDplyd":"1086952", "percPopDplyd":"61", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"0", "brand":"BYOP", "carrier":"TMO LTE WIRELESS", "tech":"LTE", "dplyd":"0", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"6", "percZipDplyd":"5", "popDplyd":"51488", "percPopDplyd":"3", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"NT", "carrier":"TMO LTE WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"NT_AN", "carrier":"TMO LTE WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"109", "percZipDplyd":"97", "popDplyd":"1780404", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"SIM", "carrier":"TMO LTE WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"111", "percZipDplyd":"99", "popDplyd":"1782782", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"TF", "carrier":"TMO LTE WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"NT", "carrier":"US CELLULAR", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"US CELLULAR", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"BYOP", "carrier":"VERIZON WIRELESS", "tech":"3G", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"BYOP", "carrier":"VERIZON WIRELESS", "tech":"CDMA", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"HF", "carrier":"VERIZON WIRELESS", "tech":"CDMA", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"HF", "carrier":"VERIZON WIRELESS", "tech":"LTE", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"NT", "carrier":"VERIZON WIRELESS", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"10", "percZipDplyd":"91", "popDplyd":"289005", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"NT_AN", "carrier":"VERIZON WIRELESS", "tech":"3G", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"0", "brand":"NT_AN", "carrier":"VERIZON WIRELESS", "tech":"CDMA", "dplyd":"0", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"111", "percZipDplyd":"99", "popDplyd":"1783272", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"20", "traits":"1", "brand":"NT_AN", "carrier":"VERIZON WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"112", "pop":"1783573", "zipsDplyd":"112", "percZipDplyd":"100", "popDplyd":"1783573", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"TF", "carrier":"VERIZON WIRELESS", "tech":"3G", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TF", "carrier":"VERIZON WIRELESS", "tech":"CDMA", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"10", "percZipDplyd":"91", "popDplyd":"289005", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"1", "brand":"TF", "carrier":"VERIZON WIRELESS", "tech":"LTE", "dplyd":"1", "bufferZips":"11", "pop":"289306", "zipsDplyd":"11", "percZipDplyd":"100", "popDplyd":"289306", "percPopDplyd":"100", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null }, { "radius":"5", "traits":"0", "brand":"TW", "carrier":"VERIZON WIRELESS", "tech":"LTE", "dplyd":"0", "bufferZips":"11", "pop":"289306", "zipsDplyd":"0", "percZipDplyd":"0", "popDplyd":"0", "percPopDplyd":"0", "extZipDplyd":null, "extPercDplyd":null, "extPopDplyd":null, "extPercPopDplyd":null } ]
    },

    {
        url: 'http://localhost:8080/tracfone/traitanalysis/retailmanagementview/updatestoreradius',
        json: { "status":"Success", "message":"Radius updated for Retail Locations successfully." }
    }


];

@Injectable()
export class MockTokenInterceptor implements HttpInterceptor {

    public readonly HTTP_BADREQUEST = 400;
    public readonly HTTP_UNAUTHORIZED = 401;
    public readonly HTTP_INTERNALERROR = 500;
    public readonly HTTP_SERVICEDOWN = 0;


    constructor(private inj: Injector, private router: Router) { }

    /**
     * Intercepts request for all services to add the auth token. 
     * On response, check 
     */
    public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        for (const element of urls) {
            if (request.url === element.url) {
                return of(new HttpResponse({ status: 200, body: (element.json) }));
            }
        }
    }

    /**
     * Handles event for HTTP 401 Unauthorized Status.
     * Clear local storage for user fields and routes to login page.
     */
    private handleHTTPUnauthorized(err?: HttpErrorResponse) {
        this.router.navigateByUrl('/login');

        if (err != null)
            return observableThrowError(err);
        else
            return observableThrowError("Unauthorized session. Please login.");
    }

    /**
     * Handles event for HTTP 500 Internal Error Status.
     */
    private handleHTTPInternalError(err: HttpErrorResponse) {
        this.router.navigateByUrl('/error');
        return observableThrowError(err);
    }
}