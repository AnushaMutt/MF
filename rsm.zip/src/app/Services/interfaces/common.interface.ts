export interface IGrowlMsgType{
    type: string,
    title: string,
    desc: string
}


export interface ILoader {
    show();
    hide();
}