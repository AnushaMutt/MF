import { Injectable } from '@angular/core';

@Injectable()
export class ImportFromCsvService {

  constructor() { }

  csvToArray(csvString) {
    var lines = csvString.split('\n');
	// popping last element as its always empty
	if(lines.length > 1)
		lines.pop();
    var headerValues = lines[0].split(',');
    var dataValues = lines.splice(1).map(function (dataLine) { return dataLine.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/); });
    return dataValues.map(function (rowValues) {
        var row = {};
        headerValues.forEach(function (headerValue, index) {
            row[headerValue.trim()] = (index < rowValues.length) ? rowValues[index].trim().replace(/\"/g, "") : null;
        });
        return row;
    });
  }

}
