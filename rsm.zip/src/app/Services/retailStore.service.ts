import { forkJoin as observableForkJoin, Observable } from "rxjs";
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { URLHandlerService } from "./urlhandler.service";

@Injectable()
export class RetailStoreService {
    readonly HTTP_GET_CARRIERS = "getcarriers";
    readonly HTTP_ADD_CARRIER = "addcarrier";
    readonly HTTP_GET_BRANDS = "getbrands";
    readonly HTTP_ADD_BRAND = "addbrand";
    readonly HTTP_GET_TRAITLOGICRULE = "gettraitlogicrules";
    readonly HTTP_GET_TECHS = "gettechs";
    readonly HTTP_ADD_TECH = "addtech";
    readonly HTTP_GET_CARRIERDETAIL = "getcarrierdetails";
    readonly HTTP_ADD_CARRIERDETAIL = "addcarrierdetail";
    readonly HTTP_UPDATE_CARRIER = "updatecarrier";
    readonly HTTP_UPDATE_BRAND = "updatebrand";
    readonly HTTP_UPDATE_TECH = "updatetech";
    readonly HTTP_UPDATE_DETAIL = "updatecarrierdetail";
    readonly HTTP_GET_TRAIT_LOGIC_RULES = "gettraitlogicrules"
    readonly HTTP_GET_PARENT = "getparents";
    readonly HTT_GET_MASTER = "getmasters"
    readonly HTTP_ADD_PARENT = "addparent";
    readonly HTTP_UPDATE_PARENT = "updateparent";
    readonly HTTP_ADD_MASTER = "addmaster";
    readonly HTTP_UPDATE_MASTER = "updatemaster";
    readonly HTTP_GET_PARENT_RULES = "getparentrules";
    readonly HTTP_ADD_PARENT_RULE = "addparentrule";
    readonly HTTP_UPDATE_PARENT_RULE = "updateparentrule";
    readonly HTTP_GET_CARRIER_PREF_GROUP = "getcarrierprefgroups";
    readonly HTTP_ADD_CARRIER_PREF_GROUP = "addcarrierprefgroup";
    readonly HTTP_UPDATE_CARRIER_PREF_GROUP = "updatecarrierprefgroup";
    readonly HTTP_GET_PREF_DETAIL = "getcarrierprefdetails";
    readonly HTTP_ADD_PREF_DETAIL = "addcarrierprefdetail";
    readonly HTTP_DELETE_PREF_DETAIL = "deletecarrierprefdetail";
    readonly HTTP_ADD_TRAIT_LOGIC_RULES = "addtraitlogicrule";
    readonly HTTP_UPDATE_LOGIC_RULE = "updatetraitlogicrule";
    readonly HTTP_RUN_TRAIT = "runtraits";
    readonly HTTP_SEARCH_TP_NORM = "searchtpnorm";
    readonly HTTP_GET_STATES = "getstates";
    readonly HTTP_UPDATE_TP_NORMS = "updatetpnorms";
    readonly HTTP_GET_ALL_CARRIER_DETAILS = "getallcarrierdetails";
    readonly HTTP_ADD_TP_NORM = "addtpnorms";
    readonly HTTP_GET_TP_NORM_STATS = "gettpnormstats";
    readonly HTTP_UPDATE_RANK = "updaterank";
    readonly HTTP_RUN_TP_NORM_TRAITS = "runtpnormtraits";
    readonly HTTP_RUN_TRAITS_SUMMARY = "runtraitssummary";
    readonly HTTP_UPDATE_NEW_RANK = "updatenewrank"

    constructor(
        private http: HttpClient,
        private urlHandler: URLHandlerService
    ) { }

    getDbEnv(){
		return this.urlHandler.RETAILSTOREWIZARD_DATABASE;
    }

    public updateRank(objId, rank) {
        return observableForkJoin(
            this.http.get(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD +  objId +"/"  + rank + "/"+ this.HTTP_UPDATE_RANK       
                     )
        );
    }

    runTraitsSummary(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_RUN_TRAITS_SUMMARY)
		);
	}

    getCarriers(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_CARRIERS)
		);
	}

    public addCarrier(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_CARRIER,
                data
            )
        );
    }

    public updateCarrier(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_CARRIER,
                data
            )
        );
    }

    getBrands(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_BRANDS)
		);
	}

    public addBrand(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_BRAND,
                data
            )
        );
    }

    public updateBrand(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_BRAND,
                data
            )
        );
    }

    retrieveTraitLogicRule(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_TRAITLOGICRULE)
		);
	}

    getTechs(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_TECHS)
		);
	}

    public addTech(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_TECH,
                data
            )
        );
    }

    public updateTech(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_TECH,
                data
            )
        );
    }

    getCarrierDetail(data){
		if(data){
			return observableForkJoin(
					this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + data + "/" + this.HTTP_GET_CARRIERDETAIL)
			);
		} else {
			return observableForkJoin(
					this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_CARRIERDETAIL)
			);
		}
	}

    public addCarrierDetail(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_CARRIERDETAIL,
                data
            )
        );
    }

    public updateCarrierDetail(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_DETAIL,
                data
            )
        );
    }

    public getTraitLogicRules() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_TRAIT_LOGIC_RULES)
        );
    }

    public getParents() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_PARENT)
        );
    }

    public getMaster(parentId) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + parentId + "/" + this.HTT_GET_MASTER)
        )
    }

    public addParent(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_PARENT,
                data
            )
        );
    }

    public updateParent(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_PARENT,
                data
            )
        );
    }

    public addMaster(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_MASTER,
                data
            )
        );
    }

    public updatMaster(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_MASTER,
                data
            )
        );
    }

    public getParentRule(parentId) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + parentId + "/" + this.HTTP_GET_PARENT_RULES)
        )
    }

    public addParentRule(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_PARENT_RULE,
                data
            )
        );
    }

    public updateParentRule(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_PARENT_RULE,
                data
            )
        );
    }

    public getPrefGroup() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_CARRIER_PREF_GROUP)
        )
    }

    public addPrefGroup(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_CARRIER_PREF_GROUP,
                data
            )
        );
    }

    public updatePrefGroup(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_CARRIER_PREF_GROUP,
                data
            )
        );
    }
    public getPrefGroupDetail(data) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + data + "/" + this.HTTP_GET_PREF_DETAIL)
        )
    }

    public addPrefGroupDetail(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_PREF_DETAIL,
                data
            )
        );
    }

    public deletePrefGroupDetail(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_DELETE_PREF_DETAIL + "/" + data, ''
            )
        );
    }

    public addTraitLogicRule(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_TRAIT_LOGIC_RULES,
                data
            )
        );
    }

    public udpateTraitLogicRule(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_LOGIC_RULE, data
            )
        );
    }

    public runTrait(data) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + data + "/" + this.HTTP_RUN_TRAIT)
        );
    }

    public searchTPNorm(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_SEARCH_TP_NORM, data
            )
        );
    }

    public getStates() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_STATES)
        );
    }

    public getCarrDetails() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_ALL_CARRIER_DETAILS)
        );
    }

    public udpateTPNorms(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_UPDATE_TP_NORMS, data
            )
        );
    }

    public addTPNorms(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_ADD_TP_NORM, data
            )
        );
    }

    public getTpNormStats() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_GET_TP_NORM_STATS)
        );
    }

    public runTpNormTraits() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILSTOREWIZARD + this.HTTP_RUN_TP_NORM_TRAITS)
        );
    }

    public updateNewRank(data) {
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILSTOREWIZARD +  this.HTTP_UPDATE_NEW_RANK, data)
        );
    }
}
