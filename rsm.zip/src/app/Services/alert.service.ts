import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable,  Subject } from 'rxjs';

@Injectable()
export class AlertService {
    private subject = new Subject<any>();

    constructor() {
                    
    }

    success(message: string) {
        this.subject.next({text: message });
    }

    error(message: string) {
        this.subject.next({text: message }); 
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }
}