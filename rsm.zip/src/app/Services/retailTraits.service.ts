import { forkJoin as observableForkJoin } from "rxjs";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { URLHandlerService } from "./urlhandler.service";

@Injectable()
export class RetailTraitsService {
    readonly HTTP_OPEN_STORES = "openstores";
    readonly HTTP_UPDATE_STORE_RADIUS = "updatestoreradius";
    readonly HTTP_GET_PARENT = "getparents";
    readonly HTT_GET_MASTER = "getmasters";
    readonly HTTP_VIEW_AVAILABILITY = "viewavailability";
    readonly HTTP_SEARCH_LOCATIONS = "searchlocations";
    readonly HTTP_GET_TRAIT_DETAILS = "gettraitdetails";
    readonly HTTP_GET_CARRIERS = "getcarriers";
    readonly HTTP_GET_BRANDS = "getbrands";
    readonly HTTP_APPROVE_REJECT_TRAITS = "approverejecttrait";
    readonly HTTP_CLOSE_STORES = "closestores";
    readonly HTTP_REOPEN_STORES = "reopenstores";
    readonly HTTP_DELETE_STORES = "deletestores";
    readonly HTTP_GET_RADIUS = "getradius";
    readonly HTTP_ANALYSE_TRAITS = "analysetraits";
    readonly HTTP_SEARCH_CLOSED_STORES = "searchclosedstores";
    readonly HTTP_GET_LAST_RUN_TRAITS_DATE = "getlasttraitrundate";
    readonly HTTP_RUN_STORE_TRAITS = "runstoretraits";
    readonly HTTP_COUNT_STORES = "countstores";


    constructor(
        private http: HttpClient,
        private urlHandler: URLHandlerService
    ) { }

    getDbEnv(){
		return this.urlHandler.RETAILSTOREWIZARD_DATABASE;
    }

    public countStores(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_COUNT_STORES, data)
        );
    }

    public runTrait(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_RUN_STORE_TRAITS,
                data
            )
        );
    }

    public openStores(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_OPEN_STORES,
                data
            )
        );
    }

    public updateRadius(data){
        return observableForkJoin(
            this.http.post(
                this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_UPDATE_STORE_RADIUS,
                data
            )
        );
    }
    public getParents() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_GET_PARENT)
        );
    }

    public getMaster(parentId) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + parentId + "/" + this.HTT_GET_MASTER)
        )
    }

    public viewAvailAbility(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_VIEW_AVAILABILITY, data)
        )
    }

    public searchLocations(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_SEARCH_LOCATIONS, data)
        )
    }

    public getTraitsDetails(locationId) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_GET_TRAIT_DETAILS + "/" + locationId)
        )
    }

    public getBrands() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_GET_BRANDS)
        );
    }

    public getCarriers() {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_GET_CARRIERS)
        );
    }

    public approveRejectTraits(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_APPROVE_REJECT_TRAITS, data)
        );
    }

    public closeStores(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_CLOSE_STORES, data)
        );
    }

    public reOpenStores(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_REOPEN_STORES, data)
        );
    }

    public deleteStores(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_DELETE_STORES, data)
        );
    }

    getRadius(){
		return observableForkJoin(
				this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_GET_RADIUS)
		);
    }

    public analyseTraits(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_ANALYSE_TRAITS, data)
        )
    }

    public searchClosedStores(data) {
        return observableForkJoin(
            this.http.post(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + this.HTTP_SEARCH_CLOSED_STORES, data)
        )
    }

    public getLastRunTraitDate(data) {
        return observableForkJoin(
            this.http.get(this.urlHandler.HTTP_URL_RETAILTRAITANALYSIS + data  + "/" + this.HTTP_GET_LAST_RUN_TRAITS_DATE)
        )
    }

}
