import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { BreadcrumbModule } from 'primeng/breadcrumb';

import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule} from '@angular/material/paginator';
import { MatCardModule} from '@angular/material/card';
import { MatDialogModule } from "@angular/material/dialog";
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button'; 
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatIconModule } from "@angular/material/icon";
import { MatListModule } from "@angular/material/list";
import { MatMenuModule } from "@angular/material/menu";
import { MatProgressBarModule } from "@angular/material/progress-bar";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatRadioModule } from "@angular/material/radio";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { ToastModule } from 'primeng/toast';
import {MatTabsModule} from '@angular/material/tabs';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from "@angular/material/slide-toggle";

import { AppComponent } from './app.component';
import { TokenInterceptor } from './Services/Interceptors/auth.interceptor';
import { URLHandlerService } from './Services/urlhandler.service';
import { AuthService } from './Services/auth.service';
import { AdminService } from './Services/admin.service';
import { CarrierService } from './Services/carrier.service'
import { ToasterService } from "./Services/toaster.service";
import { DatabaseEnvService } from "./Services/dbenv.service";

import { MessageService } from 'primeng/api';
import { environment } from 'src/environments/environment';
import { MockTokenInterceptor } from './Services/Interceptors/auth.interceptor.mock';


import { RetailTraitsHelper } from './layout/research/retail-traits/retail-traits-helper';
import { RetailTraitsComponent } from './layout/research/retail-traits/retail-traits.component';
import { ViewRetailTraitsComponent } from './layout/research/retail-traits/view-traits/view-traits.component';
import { AddNewStoresComponent } from './layout/research/retail-traits/add-stores/add-stores.component';
import { RetailAnalysisComponent } from './layout/research/retail-traits/retail-analysis/retail-analysis.component';
import { SelectCheckAllModule } from './shared/modules/select-check-all/select-check-all.module';
import { PageHeaderModule } from './shared/modules/page-header/page-header.module';
import { RetailStoreService } from './Services/retailStore.service';
import { RetailTraitsService } from './Services/retailTraits.service';



export const isMock = environment.mock;

@NgModule({
  declarations: [
        AppComponent,
        RetailTraitsComponent,
        ViewRetailTraitsComponent,
        AddNewStoresComponent,
        RetailAnalysisComponent

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    NgbModule,
    HttpClientModule,
    AppRoutingModule,
    NgxDatatableModule,
    PageHeaderModule,
    MatDialogModule,
    MatSelectModule,
    MatPaginatorModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    ConfirmDialogModule,
    MatAutocompleteModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatToolbarModule,
    MatTooltipModule,
    ToastModule,
    MatDatepickerModule,
    MatExpansionModule,
    MatTabsModule,
    MatNativeDateModule,
    BreadcrumbModule,
    MatSlideToggleModule,
    SelectCheckAllModule
  ],
  providers: [URLHandlerService,
    AuthService,
    AdminService,
    CarrierService,
    ToasterService,
    MessageService,
    DatabaseEnvService,{
    provide: HTTP_INTERCEPTORS,
    useClass: isMock ? MockTokenInterceptor : TokenInterceptor,
    multi: true,
    },RetailTraitsHelper, RetailStoreService, RetailTraitsService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
