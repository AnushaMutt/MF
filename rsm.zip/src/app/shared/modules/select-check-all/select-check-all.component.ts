import { Component, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';

@Component({
  selector: 'app-select-check-all',
  template: `
<mat-checkbox class="mat-option" [indeterminate]="isIndeterminate()" [checked]="isChecked()" (click)="$event.stopPropagation()"
    (change)="toggleSelection($event)">
    {{text.value}}
</mat-checkbox>
  `,
  styles: [''],
  encapsulation: ViewEncapsulation.None
})
export class SelectCheckAllComponent{
  @Input() model: FormControl;
  @Input() values = [];
  @Input() key;
  @Input() text; 
  @Output("returnedData") returnedData: any = new EventEmitter();

  isChecked(): boolean {
    return this.model.value && this.values.length
      && this.model.value.length === this.values.length;
  }

  isIndeterminate(): boolean {
    return this.model.value && this.values.length && this.model.value.length
      && this.model.value.length < this.values.length;
  }

  toggleSelection(change: MatCheckboxChange): void {
    if (change.checked) {
	  if(this.key && this.key.value){
		  let newArr = [];
		  this.values.forEach(e=>newArr.push(e[this.key.value]));
		  this.model.setValue(newArr);
		  this.returnedData.emit({ status: "selected", data: newArr});
	  }else{
		  this.model.setValue(this.values);
		  this.returnedData.emit({ status: "selected", data: this.values});
	  }
    } else {
      this.model.setValue([]);
	  this.returnedData.emit({ status: "selected", data: [] });
    }
  }
}
