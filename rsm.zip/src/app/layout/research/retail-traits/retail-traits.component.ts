import { Component, ViewEncapsulation, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";
import { ConfirmationService } from "primeng/api";
import { routerTransition } from "../../../../app/router.animations";
import { MatTabGroup, MatTab, MatTabHeader } from "@angular/material/tabs";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { RetailTraitsHelper } from "./retail-traits-helper";
import { RetailStoreService } from "../../../Services/retailStore.service";
import { RetailTraitsComponentService } from "./retail-traits.service";
import { ToasterService } from "../../../Services/toaster.service";

@Component({
    selector: "retail-traits",
    templateUrl: "./retail-traits.component.html",
    styleUrls: ["./retail-traits.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [ConfirmationService],
    animations: [routerTransition()],

})

export class RetailTraitsComponent implements OnInit {

    @ViewChild('retailTraitsTabs') retailTraitsTabs: MatTabGroup;
    public index = 0;
    public frmGroupMain: FormGroup;
    public showLoadingScreen = false;
    public dbEnvironments = [];
    public dbEnvironmentsMainData = [];
    public operationStarted = false;

    constructor(
        public cdRef: ChangeDetectorRef,
        private confirmationService: ConfirmationService,
        private retailStoreComponentService: RetailTraitsComponentService,
        private toasterService: ToasterService,
        private _formBuilder: FormBuilder,
        private retailTraitsHelper: RetailTraitsHelper,
        private retailStoreService: RetailStoreService
    ) { }

    ngOnInit() {
        this.frmGroupMain = new FormGroup({});
        this.createForm();
        this.retrieveDBEnv();
        if(this.retailTraitsTabs){
        this.retailTraitsTabs._handleClick = this.interceptTabChange.bind(this);
        }
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            dbEnv: ["", Validators.required],
        });
        this.frmGroupMain.get("dbEnv").valueChanges.subscribe(val => {
            const dbEnvironemnt = this.dbEnvironments.find(
                db => db.name === val
            );
        });
    }

    interceptTabChange(tab: MatTab, tabHeader: MatTabHeader, idx: number) {
        let result = false;
        this.confirmationService.confirm({
            key: "confirm-retailTraitsTabs-changed",
            message: 'Are you sure you want to navigate from current tab ?',
            accept: () => {
                result = true;
                return result && MatTabGroup.prototype._handleClick.apply(this.retailTraitsTabs, [tab, tabHeader, idx]);
            }
        });
    }

    ngAfterViewInit() {
        this.cdRef.detectChanges();
    }

    onChange(event) {
        if (event.index == 0) {
            this.index = 0;
        } else if (event.index == 1) {
            this.index = 1;
        } else if (event.index == 2) {
            this.index = 2;
        }
    }

    public retrieveDBEnv() {
        this.dbEnvironments = this.retailStoreService.getDbEnv();
        // making database as default selected if one database is available
        if (this.dbEnvironments.length == 1) {
            this.frmGroupMain
                .get("dbEnv")
                .setValue(this.dbEnvironments[0].name);
            this.dbSelect(this.dbEnvironments[0].name);
        }
        /* this.showLoadingScreen = true;
         // If envs were previously retrieved, get it from internal storage.
         if (this.dbenvService.isDBEnvsInStorage()) {
             this.dbEnvironments = this.dbenvService.getDbEnvsFromStorage();
             this.dbEnvironmentsMainData = this.dbEnvironments;
             // making database as default selected if one database is available
             if (this.dbEnvironments.length == 1) {
                 this.frmGroupMain
                     .get("dbEnv")
                     .setValue(this.dbEnvironments[0].name);
                 this.dbSelect(this.dbEnvironments[0].name);
             }
             this.showLoadingScreen = false;
         } else {
             // Get envs from service request.
             this.dbenvService
                 .getDbEnvsFromService()
                 .pipe(takeUntil(this.unsubscribe))
                 .subscribe(
                     data => {
                         if (data[0] === null || data[0] === undefined) {
                             this.toasterService.showErrorMessage(
                                 this.retailStoreHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_DATABASE_ERROR_MESSAGE")
                             );
                             this.showLoadingScreen = false;
                             return;
                         }
 
                         this.dbEnvironments = data[0];
                         this.dbEnvironmentsMainData = this.dbEnvironments;
                         this.dbenvService.storeDbEnvs(this.dbEnvironments);
                         // making database as default selected if one database is available
                         if (this.dbEnvironments.length == 1) {
                             this.frmGroupMain
                                 .get("dbEnv")
                                 .setValue(this.dbEnvironments[0].name);
                             this.dbSelect(this.dbEnvironments[0].name);
                         }
                         this.showLoadingScreen = false;
                     },
                     (err: any) => {
                         this.showLoadingScreen = false;
                         if (err.error === undefined || err.error === null) {
                             this.toasterService.showErrorMessage(
                                 this.retailStoreHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                             );
                         }
                         else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                             return;
                         else this.toasterService.showErrorMessage(err.error);
                     }
                 );
         }*/
    }

    public getDbEnvironments() {
        return this.dbEnvironments;
    }

    openedChange(option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
        }
    }

    onKey(value, option) {
        if (option == "database") {
            this.dbEnvironments = [...this.dbEnvironmentsMainData];
            this.dbEnvironments = this.search(value, this.dbEnvironments);
        }
    }

    search(value: string, searchArray: any) {
        let filter = value.toLowerCase();
        return searchArray.filter(
            option =>
                (option.description &&
                    option.description.toLowerCase().indexOf(filter) > -1)
        );
    }

    public dbSelect(dbEnv) {
        this.retailTraitsHelper.setDbEnv(dbEnv);
        //  this.showTabs = true;
        this.operationStarted = true;
    }

}