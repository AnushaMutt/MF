import { Component, ViewEncapsulation, OnInit, ChangeDetectorRef, ViewChild, ViewChildren } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { map, startWith, takeUntil } from "rxjs/operators";
import { RetailTraitsHelper } from "../retail-traits-helper";
import { ToasterService } from "../../../../Services/toaster.service";
import { ConfirmationService } from "primeng/api";
import { RetailTraitsService } from "../../../../Services/retailTraits.service";
import { RetailTraitsComponentService } from "../retail-traits.service";
import { ExportToCsvService } from "../../../../Services/export-to-csv.service";
import { MatSelect } from "@angular/material/select";
import { Subject, Observable } from "rxjs";

@Component({
    selector: "view-traits",
    templateUrl: "./view-traits.component.html",
    styleUrls: ["./view-traits.component.scss",
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService]
})

export class ViewRetailTraitsComponent implements OnInit {
    @ViewChildren(MatSelect) matSelect: any;
    @ViewChild('table') table: any;
    @ViewChild('carrierTechInput') carrierTechInput: any;
    public frmGroupMain: FormGroup;
    public tableFormGroup: FormGroup;
    public parentData: any = [];
    public parentMainData: any = [];
    public carriersData = [];
    public carriersMainData = [];
    public brandsData = [];
    public brandsMainData: any = [];
    public showLoadingScreen: boolean;
    public unsubscribe = new Subject<void>();
    public limit: any;
    public filteredRows: any;
    public isEditable: any = {};
    public editedRow: any = {};
    public defaultEditedRow: any = {};
    public selected = [];
    public editAlreadyEnabled = false;
    public errorMessage = "";
    public retailTraitData = [];
    public retailTraitMainData = [];
    public retailTraitsColumns = [];
    public panelOpenState = false;
    customCollapsedHeight: string = '40px';
    customExpandedHeight: string = '40px';
    public selectedAvailableColumns = [];
    public availableColumnsMainData = [];
    public availableColumns = [];
    public defaultColumns = [];
    public defaultColumnsMainData = [];
    public selectedFields = [];
    public selectedRetailTraits = [];
    public bulkEditBoolean: Boolean = false;
    public enteredZipCodes: any;
    public viewAvailabilityData = [];
    public viewAvailabilityMainData = [];
    public viewAvailabilityBoolean: boolean = false;
    public lastSearchRequest: any;
    public viewAvailabilityColumns = ["RETAILER", "STORENAME", "STORENUM", "ZIP", "STATE", "BRAND", "RADIUS"];
    public salesViewColumns = ["STORENUM" , "STATE","ZIP", "ATT", "TMO", "VZW", "TF/NET10 FEATURE (GSM or CDMA)",
      "ANDROID TRACFONE $29", "ANDROID TRACFONE $49", "ANDROID NET10", "ANDROID TOTAL WIRELESS", "TMO with BAND 12"];
    public viewAvailabilityMainColumns = []
    public salesViewData = [];
    public salesViewMainData = [];
    readonly EXPORT_FILE_NAME = "View Availability Results - Traits Tool";
    readonly EXPORT_FILE_NAME_SALES_VIEW = "Sales View";
    public reOpenBoolean: Boolean = false;
    public lastClosedStoresList: any;
    public traitsDetailsMainData = [];
    public traitDetailsData = [];
    public rowAlreadyExpanded: Boolean = false
    public childTableFormGroup: FormGroup;
    public childFilteredRows = [];
    public filteredValues: any = {};
    public closeBoolean;
    public fromDate;
    public toDate;
    public alerts: Array<any> = [];
    public maxDate:Date;
    public lastTraitRunDate = "";
    public callTimesViewAvailability: number = 0;
    public calledTimeViewAvailability: number = 0;
    public callTimesDeleteStores: number = 0;
    public calledTimeDeleteStores: number = 0;
    public callTimesCloseStores: number = 0;
    public calledTimeCloseStores: number = 0;
    filteredCarrierOptions: Observable<any[]>;
    public carrierValue: any = [];
    public totalStores: number = 0;
    public showTechDropDown = false;
    public carrierTechData: any = [];
    public exportConsolidatedList: any = [];
    public exportConsolidatedListCount: number = 0;
    public exportConsolidatedListCountCalled: number = 0;
    public exportConsolidatedBoolean: boolean = false;
    public auto:any;
    
    constructor(
        private retailTraitsHelper: RetailTraitsHelper,
        private _formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private retailTraitService: RetailTraitsService,
        public cdRef: ChangeDetectorRef,
        private confirmationService: ConfirmationService,
        private localService: RetailTraitsComponentService,
        private exportToCsvService: ExportToCsvService
    ) { this.frmGroupMain = new FormGroup({}); }

    ngOnInit() {
        this.exportConsolidatedBoolean = false;
        this.carrierTechData = ['2G', '3G', '5G', 'CDMA', 'LTE'];
        this.callTimesViewAvailability = 0;
        this.calledTimeViewAvailability = 0;
        this.callTimesDeleteStores = 0;
        this.calledTimeDeleteStores = 0;
        this.callTimesCloseStores = 0;
        this.calledTimeCloseStores = 0;
        this.limit = this.retailTraitsHelper.tableLimit;
        this.panelOpenState = false;
        this.closeBoolean = false;
        //available columns
        this.availableColumns = [
            { name: 'Brand', prop: 'brand', width: 120 },
            { name: 'Buffer Zips', prop: 'bufferZips', width: 120 },
            { name: 'Carrier', prop: 'carrier', width: 250 },
            { name: 'Dplyd', prop: 'dplyd', width: 80 },
            { name: 'Ext Zip Dplyd', prop: 'extZipDplyd', width: 120 },
            { name: 'Ext Perc Dplyd', prop: 'extPercDplyd', width: 120 },
            { name: 'Ext Pop Dplyd', prop: 'extPopDplyd', width: 120 },
            { name: 'Ext Perc Pop Dplyd', prop: 'extPercPopDplyd', width: 130 },
            { name: 'Perc Pop Dplyd', prop: 'percPopDplyd', width: 120 },
            { name: 'Perc Zip Dplyd', prop: 'percZipDplyd', width: 120 },
            { name: 'Pop', prop: 'pop', width: 120 },
            { name: 'Pop Dplyd', prop: 'popDplyd', width: 120 },
            { name: 'Radius', prop: 'radius', width: 80 },
            { name: 'Traits', prop: 'traits', width: 80 },
            { name: 'Tech', prop: 'tech', width: 80 },
            { name: 'Zips Dplyd', prop: 'zipsDplyd', width: 120 },
        ];
        this.availableColumnsMainData = [...this.availableColumns];

        this.defaultColumns = [
            { name: 'Brand', prop: 'brand', width: 120 },
            { name: 'Carrier', prop: 'carrier', width: 250 },
            { name: 'Radius', prop: 'radius', width: 80 },
            { name: 'Tech', prop: 'tech', width: 80 },
            { name: 'Traits', prop: 'traits', width: 80 },
        ];
        //Setting Default columns to show Row details
        this.selectedAvailableColumns = [...this.defaultColumns];
        this.defaultColumnsMainData = [...this.defaultColumns];
        this.selectedFields = [...this.defaultColumns];
        this.retailTraitsColumns = [
            { name: "Store Name", prop: "storeName", width: 135 },
            { name: "Store Num", prop: "storeNum", width: 30 },
            { name: "Zip", prop: "zip", width: 25 },
            { name: "State", prop: "state", width: 15 },
            { name: "Radius", prop: "radius", width: 30 },
        ];
        this.createSearchForm();
        this.createTableForm();
        this.retrieveParent();
        this.createChildTableForm();
        this.viewAvailabilityMainColumns = [...this.viewAvailabilityColumns];
        this.maxDate = new Date();
        this.lastTraitRunDate = "";
    }


    // selection change to clear selected values
    selectionMultipleChange(event, choice) {
        if (event.isUserInput && event.source.selected == false) {
            if (choice == "carrierInput") {
                let index = this.carriersData.indexOf(event.source.value);
                if(index > -1) {
                this.carriersData.splice(index, 1)
            }}
        }
    }

    // resetting text field to show all dropdown values
    openedMultiChange(e) {
        this.frmGroupMain.controls.carrierSearch.patchValue('');
    }

    ngAfterViewInit() {
        this.cdRef.detectChanges();
    }

    rowIdentity = (row: any) => {
        return row.name;
    }

    //Toggle Search result table row details
    toggleExpandRow(row) {
        //If row detail already open then close it and vice-versa
        if (row.expanded) {
            this.rowAlreadyExpanded = false;
            this.retailTraitData.forEach(e1 => { e1.expanded = false });
            //row.expanded = !row.expanded;
            this.table.rowDetail.toggleExpandRow(row);
            this.resetChildTableFormGroup();
            return;
        }
        // Else Open new row detail and close the existing one 
        else {
            this.rowAlreadyExpanded = true;
            this.retailTraitData.forEach(e1 => { e1.expanded = false });
            row.expanded = !row.expanded;
            this.table.rowDetail.collapseAllRows();
        }
        this.showLoadingScreen = true;
        this.retailTraitService.getTraitsDetails(row.objId).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.resetChildTableFormGroup();
                    this.showLoadingScreen = false;

                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_PARENT_ERROR_MESSAGE")
                        );
                    this.traitDetailsData = [];
                    this.traitsDetailsMainData = [];
                    this.traitsDetailsMainData = data[0];
                    this.traitDetailsData = [...this.traitsDetailsMainData];
                    this.table.rowDetail.toggleExpandRow(row);
                    this.childFilterReportResults();
                    this.childGenerateFilters();
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
    *Form Used for table column level filters
    */
    createTableForm() {
        this.tableFormGroup = this._formBuilder.group({
            storeName: [''],
            storeNum: [''],
            radius: [''],
            zip: [''],
            lastUpdateDate: [''],
            state: [''],
        });
    }

    /*
    *Form Used for child table column level filters
    */
    createChildTableForm() {
        this.childTableFormGroup = this._formBuilder.group({
            brand: [''],
            bufferZips: [''],
            carrier: [''],
            dplyd: [''],
            extZipDplyd: [''],
            extPercDplyd: [''],
            extPopDplyd: [''],
            extPercPopdplyd: [''],
            percPopDplyd: [''],
            percZipDplyd: [''],
            pop: [''],
            popDplyd: [''],
            radius: [''],
            traits: [''],
            tech: [''],
            zipsDplyd: [''],
        });
    }

    /*
    *Form Used for search criteria
    */
    createSearchForm() {
        this.frmGroupMain = this._formBuilder.group({
            parentId: ['', [Validators.required]],
            brand: [''],
            carrier: [''],
            zips: ['', [Validators.pattern("^[0-9\n ,]*$")]],
            carrierSearch: ['', []]
        })
    }

    //get selected Available columns
    public saveOptionalFields() {
        this.panelOpenState = !this.panelOpenState
    }

    //Checkbox selection from available columns accrodian
    onSelectOptionalFields(row) {
        this.selectedAvailableColumns = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedAvailableColumns.push(obj);
            }
        }
        this.selectedAvailableColumns.sort((_e1, _e2) => {
            return _e1.name.localeCompare(_e2.name) || _e2.prop - _e1.prop;
        });
        this.selectedAvailableColumns = [...this.selectedAvailableColumns]
    }

    onExpand() {
        this.panelOpenState = true;
    }

    //Available columns filter
    public updateOptionalColumns(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.availableColumnsMainData.filter(function (d) {
            return d.name.toLowerCase().indexOf(val) !== -1 || !val;
        });
        // update the rows
        this.availableColumns = temp;
    }

    // Checkbox selection from search result table
    public onSelect(row) {
        this.showTechDropDown = false;
        this.selectedRetailTraits = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedRetailTraits.push(obj);
            }
        }
        this.selectedRetailTraits = [...this.selectedRetailTraits]
        if (this.selectedRetailTraits.length == 0) {
            this.bulkEditBoolean = false;
        }
    }

    // to retrieve parents
    public retrieveParent() {
        this.showLoadingScreen = true;
        this.retailTraitService.getParents().pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_PARENT_ERROR_MESSAGE")
                        );
                    data[0].forEach(element => {
                        if (element.status == "A")
                            this.parentMainData.push(element);
                    });
                    this.parentData = [...this.parentMainData];
                    this.localService.setParentData(this.parentData);
                    this.retrieveCarriers();
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // to retrieve carriers
    public retrieveCarriers() {
        this.showLoadingScreen = true;
        this.carriersData = [];
        this.carriersMainData = [];
        this.retailTraitService.getCarriers().pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CARRIERS_ERROR_MESSAGE")
                        );
                    data[0].forEach(element => {
                        if (element.status == "A")
                            this.carriersMainData.push(element);
                    });
                    this.localService.setCarrierData(this.carriersData);
                    this.retrieveBrands();
                    // for carrier search
                    this.filteredCarrierOptions = this.frmGroupMain.controls.carrierSearch.valueChanges
                        .pipe(
                            startWith<string>(''),
                            map((name: any) => this._filter(name, 'carrierInput'))
                        );
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }
 // filter for multiple dropdown search
 private _filter(arg: string, choice) {
    let name = arg;
    if (name)
        name = name;
    const filterValue = name;
    // Set selected values to retain the selected checkbox state
    this.setSelectedValues(choice);
    let filteredList;
    
    if (choice == "carrierInput") {
        this.frmGroupMain.controls.carrier.patchValue(this.carriersData);
        filteredList = this.carriersMainData.filter((option: any) =>
            option.carrier.toLowerCase().indexOf(filterValue) > -1);
    }
    return filteredList;
}

// setting selected values
setSelectedValues(choice) {
    if (choice == "carrierInput") {
        if (this.frmGroupMain.controls.carrier.value && this.frmGroupMain.controls.carrier.value.length > 0) {
            this.frmGroupMain.controls.carrier.value.forEach((e) => {
                if (this.carriersData.indexOf(e) == -1) {
                    this.carriersData.push(e);
                }
            });
        }
    }
}
    // to retrieve brands
    public retrieveBrands() {
        this.brandsData = [];
        this.brandsMainData = [];
        this.showLoadingScreen = true;
        this.retailTraitService.getBrands().pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_BRANDS_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_BRANDS_ERROR_MESSAGE")
                        );
                    data[0].forEach(element => {
                        if (element.status == "A")
                            this.brandsMainData.push(element);
                    });
                    this.brandsData = [...this.brandsMainData];
                    this.localService.setBrandData(this.brandsData);
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
    * Creating search request to fetch locations
    */
    public createSearchLocationRequest(formData) {
        this.salesViewData = [];
        this.resetSearchResult();
        let obj: any = {};
        if (formData.parentId)
            obj.parentId = formData.parentId;
        if (formData.brand)
            obj.brand = formData.brand;
        if (formData.carrier && formData.carrier.length > 0)
            obj.carrier = formData.carrier.toString();
        if (this.enteredZipCodes)
            obj.zips = this.enteredZipCodes;
        this.lastSearchRequest = obj;
         if (this.closeBoolean) {
            this.fromDate = this.controlDateToStringDate(new Date(formData.fromDate), '-');
            this.toDate = this.controlDateToStringDate(new Date(formData.toDate), '-');

            if (this.fromDate <= this.toDate) {
                const fDate = new Date(this.fromDate),
                    tDate = new Date(this.toDate);

                const frm = Date.UTC(fDate.getFullYear(), fDate.getMonth(), fDate.getDate());
                const to = Date.UTC(tDate.getFullYear(), tDate.getMonth(), tDate.getDate());
                let diff = Math.floor((to - frm) / (1000 * 60 * 60 * 24));
                if (diff > 30) {
                    this.failedAlert(this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DATE_SELECTION_ERROR_MESSAGE"));
                    return;
                }

            } else {
                this.failedAlert(this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DATE_FORMAT_ERROR_MESSAGE"));
                return;
            }
            obj.fromDate = this.fromDate;
            obj.toDate = this.toDate;
            this.searchClosedStores(obj);
        } else {
            this.searchLocations(obj);
        }
    }

    /*
    * Fetching Locations
    */
    public searchLocations(requestData) {
        this.showLoadingScreen = true;
        this.retailTraitsColumns.push({ name: "Last Trait Run Date", prop: "lastUpdateDate", width: 200 });
        this.retailTraitService.searchLocations(requestData).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_LOCATION_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_LOCATION_ERROR_MESSAGE")
                        );
                    else
                        this.getLastRunTraitsDate(requestData.parentId);
                    this.retailTraitMainData = data[0];
                    this.retailTraitMainData.forEach(e1 => { e1.expanded = false;
                        if(e1.lastUpdateDate) {
                        e1.lastUpdateDate = e1.lastUpdateDate.split(".")[0]; 
                        }
                    });
                    this.retailTraitData = [...this.retailTraitMainData];

                    this.filterReportResults();
                    this.generateFilters();
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    public runTrait(rowData) {
        this.showLoadingScreen = true;
        let obj : any = {};
        obj.objIds = rowData.objId;
        obj.storeNum = rowData.storeNum;
        obj.parentId = rowData.parentId;
        obj.radius = rowData.radius;
        obj.zip = rowData.zip;
        obj.storeName = rowData.storeName;
        obj = this.retailTraitsHelper.checkRequestObjectSetToNull(obj);
        this.retailTraitService.runTrait(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RUN_TRAIT_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    
                    this.retailTraitData.forEach( e => {
                        if( e.objId == rowData.objId) {
                            let date = new Date();
         
                            let hour =   date.getHours().toString();
                            let mint =  date.getMinutes().toString();
                            let sec = date.getSeconds().toString();
                            if(Number(hour) < 10) {
                                hour = 0 + ""+ hour;
                            } 
                            if(Number(mint) < 10) {
                             mint = 0 + ""+ mint;
                         }
                         if(Number(sec) < 10) {
                             sec = 0 +"" + sec;
                         }
                            e.lastUpdateDate = this.controlDateToStringDate(date, '-') + " " + hour 
                            + ":" + mint + ":" + sec;
                        }
                     });

                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RUN_TRAIT_SUCCESS_MESSAGE")
                    );
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
            
    }

    public searchClosedStores(requestData) {
        this.showLoadingScreen = true;
        this.retailTraitsColumns.push({ name: "Last Update Date", prop: "lastUpdateDate", width: 200 });
        this.retailTraitService.searchClosedStores(requestData).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CLOSED_STORES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    this.showServiceErr(data);
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CLOSED_STORES_ERROR_MESSAGE")
                    );
                else
                    this.getLastRunTraitsDate(requestData.parentId)
                this.retailTraitMainData = data[0];
                for (let i = 0; i < this.retailTraitMainData.length; i++) {
                    if (this.retailTraitMainData[i].lastUpdateDate)
                        this.retailTraitMainData[i].lastUpdateDate = this.retailTraitMainData[i].lastUpdateDate.split(" ")[0];
                }

                this.filterReportResults();
                this.generateFilters();
            },
            (err: any) => {
                this.showErr(err);
                return;
            }
            );
    }

    public controlDateToStringDate(controlDate: any, dateSeparator?: string): string {
        var formattedDate = '';

        if (dateSeparator == null) dateSeparator = '-';

        try {
            if (controlDate != null) {
                var year = controlDate.getFullYear();
                var month = controlDate.getMonth() + 1;
                var day = controlDate.getDate();
            }
        } catch (Exception) {
            return '';
        }

        if (month < 10) {
            month = 0 + "" + month;
        }
        if (day < 10) {
            day = 0 + "" + day;
        }
        // Format YYYY-MM-DD.
        if (year != null && month != null && day != null) {
            formattedDate = year + dateSeparator + month + dateSeparator + day;
        }

        return formattedDate;
    }

    onChangeCheckbox(event) {
        this.retailTraitData = [];
        this.retailTraitMainData = [];
        this.lastTraitRunDate = "";
        this.alerts = [];
        if (event.checked) {
            this.closeBoolean = true;
            this.frmGroupMain.addControl('fromDate', this._formBuilder.control('', [Validators.required]));
            this.frmGroupMain.addControl('toDate', this._formBuilder.control('', [Validators.required]));
        } else {
            this.closeBoolean = false;
            if (this.frmGroupMain.controls['fromDate']) {
                this.frmGroupMain.removeControl('fromDate');
                this.frmGroupMain.removeControl('toDate');
            }
        }
    }

        private failedAlert(errorMsg: string) {
        this.alerts = [];
        this.alerts.push(
            {
                id: 4,
                type: 'danger',
                message: errorMsg
            }
        );
    }
    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFormGroup.value;
        this.filteredValues.storeName = filterFormObject.storeName;
        this.filteredValues.storeNum = filterFormObject.storeNum;
        this.filteredValues.radius = filterFormObject.radius;
        this.filteredValues.zip = filterFormObject.zip;
        this.filteredValues.lastUpdateDate = filterFormObject.lastUpdateDate;
        this.filteredValues.state = filterFormObject.state;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.retailTraitMainData);

        this.retailTraitData = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.retailTraitsColumns)
            .map(i => this.retailTraitsColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.retailTraitData.reduce((set, row) => set.add(row[columnName]), new Set());
                let val =  [];
               val =  Array.from(uniqueValuesPerRow);
              if(!isNaN(Date.parse(val[0]))){
                    filterObject[columnName] = val.sort(function(date1, date2) {
                    date1 = new Date(date1);
                    date2 = new Date(date2);
                    if (date1 > date2) return 1;
                    if (date1 < date2) return -1;
                    })
                } else if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                  
              }
                return filterObject;
            }, {});
    }

    // to filter columns for child table
    public childFilterReportResults(): void {
        const filterFormObject = this.childTableFormGroup.value;
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.traitsDetailsMainData);

        this.traitDetailsData = newRows;
    }

    public childGenerateFilters(): void {
        this.childFilteredRows = Object.keys(this.availableColumns)
            .map(i => this.availableColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.traitDetailsData.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
              if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                  
              }
                return filterObject;
            }, {});
    }

    //Filter Table data based on all the columns values
    public filterLocationTable(event) {
        let val: any;
        if (event.target)
            val = event.target.value.toLowerCase();
        else
            val = event.toLowerCase();
        // filter our data
        const temp = this.retailTraitMainData.filter(function (d) {
            return (d.zip ? d.zip.indexOf(val) !== -1 : !val) || !val
                || (d.radius ? d.radius.indexOf(val) !== -1 : !val) || !val
                || (d.storeName ? d.storeName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.storeNum ? d.storeNum.indexOf(val) !== -1 : !val) || !val
                || (d.state ? d.state.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.lastUpdateDate ? d.lastUpdateDate.toLowerCase().indexOf(val) !== -1 : !val) || !val                
        });
        // update the rows
        this.retailTraitData = temp;
    }

    checkReturnData(returnedData) {
        if (returnedData.status == "selected") {
            this.carriersData = [...returnedData.data];
        }
    }
    
    /*
    * Search Criteria form and table data will get reset
    */
    public resetForm() {
        this.exportConsolidatedBoolean = false;
        this.exportConsolidatedListCount = 0;
        this.exportConsolidatedListCountCalled = 0;
        this.exportConsolidatedList = [];
        this.carriersData = [];
        this.frmGroupMain.controls.parentId.patchValue('');
        this.frmGroupMain.controls.carrier.patchValue('');
        this.frmGroupMain.controls.brand.patchValue('');
        this.frmGroupMain.controls.zips.patchValue('');
        // this.frmGroupMain.reset();
        this.panelOpenState = false;
        this.defaultColumns = [...this.defaultColumnsMainData];
        this.selectedAvailableColumns = [...this.defaultColumns];
        this.selectedFields = [...this.defaultColumns];
        this.retailTraitMainData = [];
        this.retailTraitData = [];
        this.bulkEditBoolean = false;
        this.selectedRetailTraits = [];
        this.enteredZipCodes = "";
        this.viewAvailabilityBoolean = false;
        this.viewAvailabilityData = [];
        this.viewAvailabilityMainData = [];
        this.selected = [];
        this.errorMessage = "";
        this.rowAlreadyExpanded = false;
        this.editAlreadyEnabled = false;
        this.isEditable = {}
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.tableFormGroup.controls.storeName.patchValue([]);
        this.tableFormGroup.controls.storeNum.patchValue([]);
        this.tableFormGroup.controls.radius.patchValue([]);
        this.tableFormGroup.controls.lastUpdateDate.patchValue([]);
        this.tableFormGroup.controls.state.patchValue([]);
        this.tableFormGroup.controls.zip.patchValue([]);
        this.resetChildTableFormGroup();
        this.filteredValues = {};
        this.lastTraitRunDate = "";
        this.carrierValue = [];
    }
    /*
    * Search Table data will get reset
    */
    public resetSearchResult() {
        this.alerts = [];
        this.retailTraitMainData = [];
        this.retailTraitData = [];
        this.bulkEditBoolean = false;
        this.selectedRetailTraits = [];
        this.panelOpenState = false;
        this.viewAvailabilityBoolean = false;
        this.viewAvailabilityData = [];
        this.viewAvailabilityMainData = [];
        this.selected = [];
        this.rowAlreadyExpanded = false;
        this.editAlreadyEnabled = false;
        this.isEditable = {};
        this.editedRow = {};
        this.defaultEditedRow = {};
        this.tableFormGroup.controls.storeName.patchValue([]);
        this.tableFormGroup.controls.storeNum.patchValue([]);
        this.tableFormGroup.controls.radius.patchValue([]);
        this.tableFormGroup.controls.lastUpdateDate.patchValue([]);
        this.tableFormGroup.controls.state.patchValue([]);
        this.tableFormGroup.controls.zip.patchValue([]);
        this.resetChildTableFormGroup();
        this.filteredValues = {};
        this.retailTraitsColumns = this.retailTraitsColumns.slice(0,5);   
        this.lastTraitRunDate = "";     
    }

    public resetChildTableFormGroup() {
        this.childTableFormGroup.controls.brand.patchValue([]);
        this.childTableFormGroup.controls.bufferZips.patchValue([]);
        this.childTableFormGroup.controls.carrier.patchValue([]);
        this.childTableFormGroup.controls.dplyd.patchValue([]);
        this.childTableFormGroup.controls.extZipDplyd.patchValue([]);
        this.childTableFormGroup.controls.extPercDplyd.patchValue([]);
        this.childTableFormGroup.controls.extPopDplyd.patchValue([]);
        this.childTableFormGroup.controls.extPercPopdplyd.patchValue([]);
        this.childTableFormGroup.controls.percPopDplyd.patchValue([]);
        this.childTableFormGroup.controls.percZipDplyd.patchValue([]);
        this.childTableFormGroup.controls.pop.patchValue([]);
        this.childTableFormGroup.controls.popDplyd.patchValue([]);
        this.childTableFormGroup.controls.radius.patchValue([]);
        this.childTableFormGroup.controls.traits.patchValue([]);
        this.childTableFormGroup.controls.tech.patchValue([]);
        this.childTableFormGroup.controls.zipsDplyd.patchValue([]);
    }

    public openedChange(rowData) {
        if (rowData == "brandInput")
            this.brandsData = [...this.brandsMainData];
        else if (rowData == "parentInput")
            this.parentData = [...this.parentMainData];
    }

    public onKey(value, rowData) {
         if (rowData == "brandInput") {
            this.brandsData = [...this.brandsMainData];
            this.brandsData = this.search(value, "brandList");
        } else if (rowData == "parentInput") {
            this.parentData = [...this.parentMainData];
            this.parentData = this.search(value, "parentList");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "carrierList")
            return this.carriersMainData.filter(option => option.carrier.toLowerCase().indexOf(filter) > -1);
        else if (choice == "brandList")
            return this.brandsMainData.filter(option => option.brand.toLowerCase().indexOf(filter) > -1);
        else if (choice == "parentList")
            return this.parentMainData.filter(option => option.retailer.toLowerCase().indexOf(filter) > -1);
    }

    //Enable inline editing
    public editButtonClicked(rowIndex) {
        this.editAlreadyEnabled = true;
        let alreadyEnabled = false;
        for (let i = 0; i < this.retailTraitData.length; i++) {
            if (this.isEditable[i])
                alreadyEnabled = true;
        }
        if (!alreadyEnabled)
            this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        else
            this.toasterService.showErrorMessage(
                this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE"),
            );
    }

    // cancel inline editing
    public cancelEditForm(rowData, rowIndex) {
        this.showLoadingScreen = true;
        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
        this.retailTraitsColumns.forEach(parent => {
            if (document.getElementById(parent.prop + rowIndex)) {
                (<HTMLInputElement>(
                    document.getElementById(parent.prop + rowIndex)
                )).value = rowData[parent.prop] || '';
            }
        });
        this.matSelect._results.forEach(matSelectData => {
            if (matSelectData.id.indexOf('status' + rowIndex) == 0)
                matSelectData.value = rowData['status'] || '';
        });

        this.editedRow = {};
        this.showLoadingScreen = false;
        this.editAlreadyEnabled = false;
    }

    //check inline values
    public inputValueChanged(event, column, row, oldValue) {
        if (column != "status") {
            this.editedRow[column] = event.target.value;
            this.defaultEditedRow[column] = event.target.defaultValue;
        } else {
            this.editedRow[column] = event.value;
            this.defaultEditedRow[column] = oldValue;
        }
    }

     public showCarrierTechDropDown() {
        this.showTechDropDown = true;
    }
    /*
    * Creating View Availability Request
    */
    public createViewAvailabilityRequest() {
        if (!this.carrierTechInput._value) {
            this.toasterService.showErrorMessage(
                this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SELECT_CARRIER_TECH_ERROR_MESSAGE")
            )
            return;
        }
        this.viewAvailabilityBoolean = true;
        this.viewAvailabilityMainData = [];
        this.viewAvailabilityData = [];
        const element = document.getElementById("availability")
        if (element)
            element.scrollIntoView({ behavior: 'smooth' })
        let obj: any = {};
        let objIds = [];
        if (this.frmGroupMain.value.parentId)
            obj.parentId = this.frmGroupMain.value.parentId;
        if (this.frmGroupMain.value.brand)
            obj.brand = this.frmGroupMain.value.brand;
        if (this.frmGroupMain.value.carrier)
            obj.carrier = this.frmGroupMain.value.carrier;
        this.selectedRetailTraits.forEach(_e1 => {
            objIds.push(_e1.objId);
        });
        //obj.objIds = objIds.toString();

        this.callTimesViewAvailability = Math.ceil(objIds.length/500);
        this.calledTimeViewAvailability = 0;
        for(let i=0; i<this.callTimesViewAvailability; i++){
            obj.objIds = "";
            for(let j=500*i; j<objIds.length; j++){
                if(j < (i+1)*500)
                    obj.objIds += objIds[j]+',';
                else
                    break;
            }
            obj.objIds = obj.objIds.replace(/,\s*$/, "");
            this.viewAvailability(obj);
        }
    }
    /*
    * Fetching View Availability
    */
    public viewAvailability(requestData) {
        this.retailTraitService.viewAvailAbility(requestData).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_VIEW_AVAILABILITY_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.calledTimeViewAvailability += 1;
                    this.viewAvailabilityMainData = [...this.viewAvailabilityMainData, ...data[0]];
                    if(this.callTimesViewAvailability == this.calledTimeViewAvailability){
                        if (this.viewAvailabilityMainData && this.viewAvailabilityMainData.length == 0)
                            this.toasterService.showErrorMessage(
                                this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_VIEW_AVAILABILITY_ERROR_MESSAGE")
                            );
                        this.viewAvailabilityBoolean = false;
                        this.showLoadingScreen = false;
                        //Mapping data with CAPs keys
                        this.viewAvailabilityMainData.forEach(_e1 => {
                            _e1.RETAILER = _e1.retailer;
                            _e1.BRAND = _e1.brand;
                            _e1.ZIP = _e1.zip;
                            _e1.STORENAME = _e1.storeName;
                            _e1.STORENUM = _e1.storeNum;
                            _e1.RADIUS = _e1.radius;
                            _e1.STATE = _e1.state;
                        });
                        //Mapping data inside array
                        this.viewAvailabilityMainData.forEach(_e1 => {
                            let keys = Object.keys(_e1.carrierTechs);
                            keys.forEach(_e2 => {
                                if (_e1.carrierTechs[_e2] == null)
                                    _e1[_e2] = "";
                                else
                                    _e1[_e2] = _e1.carrierTechs[_e2];
                            });
                        });
                        let carrierTechsKeys = Object.keys(this.viewAvailabilityMainData[0].carrierTechs);
                        this.viewAvailabilityColumns = [...this.viewAvailabilityColumns, ...carrierTechsKeys];
                        this.viewAvailabilityData = [...this.viewAvailabilityMainData];
                        if (this.viewAvailabilityData.length > 0) {
                            this.exportToCSV();
                        }
                    }
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Used to Export CSV File
    public exportToCSV() {
        this.exportToCsvService.downloadFile(this.viewAvailabilityData, this.EXPORT_FILE_NAME, this.viewAvailabilityColumns);
        this.viewAvailabilityColumns = [...this.viewAvailabilityMainColumns];
        this.exportSalesViewToCSV();
    }

    public exportSalesViewToCSV() { 
        this.salesViewMainData = [...this.viewAvailabilityData];
        this.salesViewMainData.forEach(e => {
            let carrierTechATT;
            let carrierTechTMO;
            let carrierTechVZW;

            if(this.carrierTechInput._value == 'LTE') {
                carrierTechATT = e.ATT_WIRELESS_LTE;
                carrierTechTMO = e.TMO_LTE_WIRELESS_LTE;
                carrierTechVZW = e.VERIZON_WIRELESS_LTE;
            }
            if(this.carrierTechInput._value == 'CDMA') {
                carrierTechVZW = e.VERIZON_WIRELESS_CDMA;
            }
            if(this.carrierTechInput._value == '5G') {
                carrierTechVZW = e.VERIZON_WIRELESS_5G;
            }
            if(this.carrierTechInput._value == '3G') {
                carrierTechVZW = e.VERIZON_WIRELESS_3G;
                carrierTechTMO = e.TMOBILE_3G_3G;
            }
            if(this.carrierTechInput._value == '2G') {
                carrierTechTMO = e.TMOBILE_2GG;
            }

            if(carrierTechATT == "1") {
                e.ATT = "YES";
                e['TF/NET10 FEATURE (GSM or CDMA)'] =  'ATT' ;
                e['ANDROID TRACFONE $29'] =  'ATT' ;
                e['ANDROID NET10'] =  'ATT' ;
            } else {
                e.ATT = "NO";   
            }

            if(carrierTechTMO == "1") {
                e.TMO = "YES";
                e['TF/NET10 FEATURE (GSM or CDMA)'] = e['TF/NET10 FEATURE (GSM or CDMA)'] ? e['TF/NET10 FEATURE (GSM or CDMA)'] + '/TMO' : 'TMO';
                e['ANDROID TRACFONE $29'] = e['ANDROID TRACFONE $29'] ? e['ANDROID TRACFONE $29']+ '/TMO' : 'TMO';
                e['ANDROID NET10'] = e['ANDROID NET10'] ? e['ANDROID NET10']+ '/TMO' : 'TMO';
                e['TMO with BAND 12'] = 'YES';
            } else {
                e.TMO = "NO";
                e['TMO with BAND 12'] = 'NO';
            }

            if(carrierTechVZW == "1") {  
                e.VZW = "YES";
                e['TF/NET10 FEATURE (GSM or CDMA)'] = e['TF/NET10 FEATURE (GSM or CDMA)'] ? e['TF/NET10 FEATURE (GSM or CDMA)'] + '/VZW' : 'VZW';
                e['ANDROID TRACFONE $29'] = e['ANDROID TRACFONE $29'] ? e['ANDROID TRACFONE $29']+ '/VZW' : 'VZW';
                e['ANDROID NET10'] = e['ANDROID NET10'] ? e['ANDROID NET10']+ '/VZW' : 'VZW';
                e['ANDROID TOTAL WIRELESS'] = 'YES';
            } else {
                e.VZW = "NO";
                e['ANDROID TOTAL WIRELESS'] = 'NO';
            }
        });

        this.salesViewMainData.forEach(e => {
            if(e.VZW == 'YES') {
                e['ANDROID TRACFONE $49'] ='VZW' ;
            }  if(e.TMO == 'YES') {
                e['ANDROID TRACFONE $49'] = e['ANDROID TRACFONE $49'] ? e['ANDROID TRACFONE $49']+ '/TMO' :'TMO' ;
            }  if(e.ATT == 'YES') {
                e['ANDROID TRACFONE $49'] = e['ANDROID TRACFONE $49'] ? e['ANDROID TRACFONE $49']+ '/ATT' : 'ATT';
            } if(e.ATT == 'NO' && e.VZW == 'NO' && e.TMO == 'NO'){
                e['ANDROID TRACFONE $49'] = '';
            }

                if(!e['TF/NET10 FEATURE (GSM or CDMA)']) {
                e['TF/NET10 FEATURE (GSM or CDMA)'] ='';
                }
                if(!e['ANDROID TRACFONE $29']) {
                e['ANDROID TRACFONE $29'] = '';
                }
                if(!e['ANDROID NET10'] ) {
                e['ANDROID NET10'] = '';
                }

                if(e['TF/NET10 FEATURE (GSM or CDMA)'] && e['TF/NET10 FEATURE (GSM or CDMA)'][0] == '/') {
                    e['TF/NET10 FEATURE (GSM or CDMA)']= e['TF/NET10 FEATURE (GSM or CDMA)'].substring(1);
                }
                if(e['ANDROID TRACFONE $29'] && e['ANDROID TRACFONE $29'][0] == '/') {
                    e['ANDROID TRACFONE $29']= e['ANDROID TRACFONE $29'].substring(1);
                }
                if(e['ANDROID TRACFONE $49'] && e['ANDROID TRACFONE $49'][0] == '/') {
                    e['ANDROID TRACFONE $49']= e['ANDROID TRACFONE $49'].substring(1);
                }
                if(e['ANDROID NET10'] && e['ANDROID NET10'][0] == '/') {
                    e['ANDROID NET10']= e['ANDROID NET10'].substring(1);
                }
        });
        this.salesViewData = [...this.salesViewMainData];
        this.exportToCsvService.downloadFile(this.salesViewData, this.EXPORT_FILE_NAME_SALES_VIEW, this.salesViewColumns);
        this.showTechDropDown = false;
    }

    //Used for enable bulk edit radius
    public openBulkEdit() {
        if (!this.bulkEditBoolean)
            this.bulkEditBoolean = true;
    }

    //Used to close bulk edit radius
    public removeBulkEdit() {
        this.bulkEditBoolean = false;
    }

    /*
    * Updating radius based on the selection or inline edited row data
    */
    public updateRadius(row, rowIndex, radiusValue) {
        let obj: any = [];
        let editAction: any = "";
        //if bulk edit
        if (this.selectedRetailTraits.length > 0 && radiusValue) {
            obj = [...this.selectedRetailTraits];
            obj.forEach(_e1 => {
                _e1.objIds = _e1.objId
                _e1.radius = radiusValue;
            });
            editAction = "bulk";
        }
        //if inine edit
        else {
            obj = { ...row, ...this.editedRow };
            obj.objIds = row.objId;
            obj = [obj];
            editAction = "inline"
        }
        this.showLoadingScreen = true;
        this.retailTraitService.updateRadius(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_LOCATION_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.removeBulkEdit();
                    if (editAction == "bulk") {
                        this.resetSearchResult();
                        this.searchLocations(this.lastSearchRequest);
                        this.toasterService.showSuccessMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_LOCATION_SUCCESS_MESSAGE")
                        );
                    }
                    else if (editAction == "inline") {
                        this.retailTraitMainData.forEach(_e1 => {
                            obj.forEach(_e2 => {
                                if (_e1.objId == _e2.objId) {
                                    _e1.radius = _e2.radius;
                                }
                            });
                        });
                        this.retailTraitData = [...this.retailTraitMainData];
                        this.generateFilters();
                        this.tableFormGroup.controls.storeName.patchValue(this.filteredValues.storeName);
                        this.tableFormGroup.controls.storeNum.patchValue(this.filteredValues.storeNum);
                        this.tableFormGroup.controls.radius.patchValue(this.filteredValues.radius);
                        this.tableFormGroup.controls.lastUpdateDate.patchValue(this.filteredValues.lastUpdateDate);
                        this.tableFormGroup.controls.state.patchValue(this.filteredValues.state);
                        this.tableFormGroup.controls.zip.patchValue(this.filteredValues.zip);
                        this.filterReportResults();
                        if (this.filteredValues.mainTableFilter)
                            this.filterLocationTable(this.filteredValues.mainTableFilter);
                        this.editAlreadyEnabled = false;
                        this.isEditable[rowIndex] = !this.isEditable[rowIndex];
                        this.toasterService.showSuccessMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_LOCATION_SUCCESS_MESSAGE")
                        );
                    }
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    // // Approve/Reject Confirm dialog
    // public showApproveRejectTraitsConfirm(requestData, editAction, rowIndex) {
    //     this.confirmationService.confirm({
    //         key: 'confirm-approve-reject',
    //         message: this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_APPROVE_REJECT_TRAITS_CONFIRM_MESSAGE"),
    //         accept: () => {
    //             this.approveRejectTraits(requestData, "approved", editAction, rowIndex);
    //         },
    //         reject: () => {
    //             this.approveRejectTraits(requestData, "reject", editAction, rowIndex);
    //         }
    //     });
    // }

    // /*
    // * Approve/Reject Service call 
    // */
    // public approveRejectTraits(requestData, confirm, editAction, rowIndex) {
    //     let obj: any = {};
    //     let objIds: any = [];
    //     requestData.forEach(element => {
    //         objIds.push(element.objId);
    //     });
    //     if (confirm == "approved")
    //         obj.approveTrait = true;
    //     else
    //         obj.approveTrait = false;
    //     obj.objIds = objIds.toString();
    //     this.showLoadingScreen = true;
    //     this.retailTraitService.approveRejectTraits(obj).pipe(takeUntil(this.unsubscribe))
    //         .subscribe(
    //             (data: any) => {
    //                 if (data[0] === null || data[0] === undefined) {
    //                     this.showLoadingScreen = false;
    //                     this.toasterService.showErrorMessage(
    //                         this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_LOCATION_ERROR_MESSAGE")
    //                     );
    //                     return;
    //                 }
    //                 if (data[0] && data[0].ERR) {
    //                     this.showLoadingScreen = false;
    //                     this.showServiceErr(data);
    //                     return;
    //                 }
    //                 this.showLoadingScreen = false;
    //                 if (confirm == "approved" && editAction == "bulk") {
    //                     this.resetSearchResult();
    //                     this.searchLocations(this.lastSearchRequest);
    //                     this.toasterService.showSuccessMessage(
    //                         this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_LOCATION_SUCCESS_MESSAGE")
    //                     );
    //                 }
    //                 else if (confirm == "approved" && editAction == "inline") {
    //                     this.retailTraitMainData.forEach(_e1 => {
    //                         requestData.forEach(_e2 => {
    //                             if (_e1.objId == _e2.objId) {
    //                                 _e1.radius = _e2.radius;
    //                             }
    //                         });
    //                     });
    //                     this.retailTraitData = [...this.retailTraitMainData];
    //                     this.generateFilters();
    //                     this.tableFormGroup.controls.storeName.patchValue(this.filteredValues.storeName);
    //                     this.tableFormGroup.controls.storeNum.patchValue(this.filteredValues.storeNum);
    //                     this.tableFormGroup.controls.radius.patchValue(this.filteredValues.radius);
    //                     this.tableFormGroup.controls.lastUpdateDate.patchValue(this.filteredValues.lastUpdateDate);
    //                     this.tableFormGroup.controls.state.patchValue(this.filteredValues.state);
    //                     this.tableFormGroup.controls.zip.patchValue(this.filteredValues.zip);
    //                     this.filterReportResults();
    //                     if (this.filteredValues.mainTableFilter)
    //                         this.filterLocationTable(this.filteredValues.mainTableFilter);
    //                     this.editAlreadyEnabled = false;
    //                     this.isEditable[rowIndex] = !this.isEditable[rowIndex];
    //                     this.toasterService.showSuccessMessage(
    //                         this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPDATE_LOCATION_SUCCESS_MESSAGE")
    //                     );
    //                 }
    //             },
    //             (err: any) => {
    //                 this.showErr(err);
    //                 return;
    //             }
    //         );
    // }
    /*
    * Show Confirm dialog when click on close store button
    */
    public showConfirm() {
        if(this.selectedRetailTraits.length == this.retailTraitMainData.length) {
            this.countStores();
            
        }else {
            this.showCloseStoreConfirm();
        }
        
    }

    showCloseStoreConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-close-store',
            message: this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_CLOSE_STORE_CONFIRM_MESSAGE"),
            accept: () => {
                this.reOpenBoolean = true;
                this.showLoadingScreen = true;
                let obj: any = {};
                let objIds: any = [];
                this.selectedRetailTraits.forEach(_e1 => {
                    objIds.push(_e1.objId);
                });
                //obj.objIds = objIds.toString();
                this.callTimesCloseStores = Math.ceil(objIds.length/500);
                this.calledTimeCloseStores = 0;
                for(let i=0; i<this.callTimesCloseStores; i++){
                    obj.objIds = "";
                    for(let j=500*i; j<objIds.length; j++){
                        if(j < (i+1)*500)
                            obj.objIds += objIds[j]+',';
                        else
                            break;
                    }
                    obj.objIds = obj.objIds.replace(/,\s*$/, "");
                    this.closeStores(obj);
                }
            }
        });
    }

    public countStores() {
        this.showLoadingScreen = true;
        this.totalStores = 0;
        let obj : any = {};
        obj.parentId = this.frmGroupMain.controls['parentId'].value;
        this.retailTraitService.countStores(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_COUNT_STORE_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.totalStores = Number(data[0].message);

                    if(this.totalStores == this.selectedRetailTraits.length) {
                        this.confirmationService.confirm({
                            key: 'confirm-close-last-store',
                            message: this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_CLOSE_LAST_STORE_CONFIRM_MESSAGE"),
                            accept: () => {
                                        this.showCloseStoreConfirm();
                                }
                            });

                    } else {
                        this.showCloseStoreConfirm();
                    }
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //Close Stores
    public closeStores(obj) {
        obj.parentId = this.frmGroupMain.controls['parentId'].value;
        this.retailTraitService.closeStores(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_CLOSE_STORE_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.calledTimeCloseStores += 1;
                    if(this.callTimesCloseStores == this.calledTimeCloseStores){
                        this.showLoadingScreen = false;
                        this.toasterService.showSuccessMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_CLOSER_STORE_SUCCESS_MESSAGE")
                        );
                        this.lastClosedStoresList = obj;    
                    }
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    //ReOpen Stores
    public reOpenStores() {
        let obj: any = {};
        let objIds: any = [];
        this.selectedRetailTraits.forEach(_e1 => {
            objIds.push(_e1.objId);
        });
        obj.objIds = objIds.toString();
        obj.parentId = this.frmGroupMain.controls['parentId'].value;

        this.showLoadingScreen = true;
        this.retailTraitService.reOpenStores(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_REOPEN_STORE_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.toasterService.showSuccessMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_REOPEN_STORE_SUCCESS_MESSAGE")
                    );
                    this.reOpenBoolean = false;
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }
    /*
    * Show Confirm dialog when click on delete store button
    */
    public showDeleteStoreConfirm() {
        this.confirmationService.confirm({
            key: 'confirm-delete-store',
            message: `<strong>THIS OPERATION CANNOT BE UNDONE !</strong><br/>Are you sure you want to delete these Stores ?`,
            accept: () => {
                this.showLoadingScreen = true;
                let obj: any = {};
                let objIds: any = [];
                this.selectedRetailTraits.forEach(_e1 => {
                    objIds.push(_e1.objId);
                });
                //obj.objIds = objIds.toString();
                this.callTimesDeleteStores = Math.ceil(objIds.length/500);
                this.calledTimeDeleteStores = 0;
                let i = this.calledTimeDeleteStores;
                obj.objIds = "";
                for(let j=500*i; j<objIds.length; j++){
                    if(j < (i+1)*500)
                        obj.objIds += objIds[j]+',';
                    else
                        break;
                }
                obj.objIds = obj.objIds.replace(/,\s*$/, "");
                this.delelteStores(obj);
            }
        });
    }

    //Delete Stores
    public delelteStores(obj) {
        this.retailTraitService.deleteStores(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DELETE_STORE_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        this.showServiceErr(data);
                        return;
                    }
                    this.calledTimeDeleteStores += 1;
                    if(this.callTimesDeleteStores == this.calledTimeDeleteStores){
                        this.showLoadingScreen = false;
                        this.retailTraitMainData.forEach((_e1, index) => {
                            this.selectedRetailTraits.forEach(_e2 => {
                                if (_e1.objId == _e2.objId) {
                                    this.retailTraitMainData.splice(index, 1);
                                }
                            });
                        });
                        this.retailTraitData = [...this.retailTraitMainData];
                        this.selectedRetailTraits = [];
                        this.selected = [];
                        this.toasterService.showSuccessMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DELETE_STORE_SUCCESS_MESSAGE")
                        );
                        this.generateFilters();
                        this.filterReportResults();
                    }else{
                        let obj: any = {};
                        let objIds: any = [];
                        this.selectedRetailTraits.forEach(_e1 => {
                            objIds.push(_e1.objId);
                        });
                        let i = this.calledTimeDeleteStores;
                        obj.objIds = "";
                        for(let j=500*i; j<objIds.length; j++){
                            if(j < (i+1)*500)
                                obj.objIds += objIds[j]+',';
                            else
                                break;
                        }
                        obj.objIds = obj.objIds.replace(/,\s*$/, "");
                        this.delelteStores(obj);
                    }
                },
                (err: any) => {
                    this.showErr(err);
                    return;
                }
            );
    }

    /*
    * Show error if any service call fails to complete
    */
    public showErr(err) {
        this.showLoadingScreen = false;
        if (err.error === undefined || err.error === null)
            this.toasterService.showErrorMessage(
                this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
            );
        else if (err.error && err.error.ERR) {
            const commaSeperatedArr = err.error.ERR.split(",");
            for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                if (commaSeperatedArr[i] != "")
                    this.toasterService.showErrorMessage(
                        commaSeperatedArr[i]
                    );
            }
        }
        else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
            return;
        else this.toasterService.showErrorMessage(err.error);
    }

    /*
    * Show error when service returns error
    */
    public showServiceErr(data) {
        const commaSeperatedArr = data[0].ERR.split(",");
        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
            if (commaSeperatedArr[i] != "")
                this.toasterService.showErrorMessage(commaSeperatedArr[i]);
        }
        return;
    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    public zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

    //Filter Table data based on all the columns values
    public filterTraitDetailsTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.traitsDetailsMainData.filter(function (d) {
            return (d.brand ? d.brand.indexOf(val) !== -1 : !val) || !val
                || (d.bufferZips ? d.bufferZips.indexOf(val) !== -1 : !val) || !val
                || (d.carrier ? d.carrier.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.dplyd ? d.dplyd.indexOf(val) !== -1 : !val) || !val
                || (d.extZipDplyd ? d.extZipDplyd.indexOf(val) !== -1 : !val) || !val
                || (d.extPercDplyd ? d.extPercDplyd.indexOf(val) !== -1 : !val) || !val
                || (d.extPopDplyd ? d.extPopDplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.extPercPopdplyd ? d.extPercPopdplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.percPopDplyd ? d.percPopDplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.percZipDplyd ? d.percZipDplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.pop ? d.pop.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.popDplyd ? d.popDplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.radius ? d.radius.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.traits ? d.traits.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.tech ? d.tech.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.zipsDplyd ? d.zipsDplyd.toLowerCase().indexOf(val) !== -1 : !val) || !val

        });
        // update the rows
        this.traitDetailsData = temp;
    }

    getRowClass = (row) => {
        if (row.expanded)
            return {
                'row-color': true
            };
    }

    public getLastRunTraitsDate(parentId){
        this.showLoadingScreen = true;
        this.retailTraitService.getLastRunTraitDate(parentId).pipe(takeUntil(this.unsubscribe))
        .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DELETE_STORE_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    this.showServiceErr(data);
                    return;
                }
                this.showLoadingScreen = false;
                this.lastTraitRunDate = data[0].message.split(".")[0];
            },
            (err: any) => {
                this.showErr(err);
                return;
            }
        );
    }

    dateChanged(value, frm, control){
		if(value && !/^([1-9]|1[0-2])\/([1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(value)){
			this[frm].controls[control].setValue('');
		}
	}

    exportSearchResultToCSV() {
        this.exportConsolidatedListCount = 0;
        this.exportConsolidatedListCountCalled = 0;
        this.exportConsolidatedList = [];
        this.exportConsolidatedBoolean = true;
 
        let parentData = [...this.selectedRetailTraits];
        parentData.forEach((x,index)=>{
            if(index < 500){
                this.exportConsolidatedListCount = index+1;
                this.getTraitsData(x)
            }
        })
    }

    public getTraitsData(obj){
        this.retailTraitService.getTraitsDetails(obj.objId).pipe(takeUntil(this.unsubscribe))
        .subscribe(
            (data: any) => {
                this.exportConsolidatedListCountCalled = this.exportConsolidatedListCountCalled+1;
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    this.showServiceErr(data);
                    return;
                }
                this.showLoadingScreen = false;

                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_PARENT_ERROR_MESSAGE")
                    );

                data[0].forEach(element => {
                    element.traitbrand = element.brand
                    element.traitradius = element.radius
                    this.exportConsolidatedList.push({...element, ...obj})
                });

                let columns = [];
                this.retailTraitsColumns.forEach(x=>{
                    columns.push(x.prop)            
                })
                this.availableColumns.forEach(x=>{
                    if(x.prop == "radius")
                        columns.push("traitradius")
                    else if(x.prop == "brand")
                        columns.push("traitbrand")
                    else
                        columns.push(x.prop)
                })

                if(this.exportConsolidatedListCount == this.exportConsolidatedListCountCalled){
                    this.exportConsolidatedBoolean = false;
                    this.exportToCsvService.downloadFile(this.exportConsolidatedList, "RetailTraitsExport", columns);
                }
            },
            (err: any) => {
                this.showErr(err);
                return;
            }
        );
    }
}