import { Injectable } from "@angular/core";

@Injectable({
    providedIn: "root"
})
export class RetailTraitsComponentService {
    private _parentData: any;
    private _carrierData: any;
    private _brandData: any;

    public getParentData(): any {
        return this._parentData;
    }
    public setParentData(value: any) {
        this._parentData = value;
    }
    public getCarrierData(): any {
        return this._carrierData;
    }
    public setCarrierData(value: any) {
        this._carrierData = value;
    }
    public getBrandData(): any {
        return this._brandData;
    }
    public setBrandData(value: any) {
        this._brandData = value;
    }

    resetAll(){
        this._parentData = [];
        this._brandData = [];
        this._carrierData = [];
    }
}