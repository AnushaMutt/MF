import { Component, ViewEncapsulation, OnInit, ViewChild } from "@angular/core";
import { ExportToCsvService } from "../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../Services/import-from-csv.service";
import { RetailTraitsHelper } from "../retail-traits-helper";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { RetailTraitsService } from "../../../../Services/retailTraits.service";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../Services/toaster.service";
import { Subject } from "rxjs";
import { RetailTraitsComponentService } from "../retail-traits.service";
import { environment } from 'src/environments/environment';

@Component({
    selector: "retail-analysis",
    templateUrl: "./retail-analysis.component.html",
    styleUrls: ["./retail-analysis.component.scss",
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class RetailAnalysisComponent implements OnInit {
    @ViewChild('table') table: any;
    public frmGroupMain: FormGroup;
    public tableFormGroup: FormGroup;
    public parentData: any = [];
    public parentMainData: any = [];
    public carriersData = [];
    public carriersMainData = [];
    public brandsData = [];
    public brandsMainData: any = [];
    public showLoadingScreen: boolean;
    public unsubscribe = new Subject<void>();
    public limit: any;
    public filteredRows: any;
    public selected = [];
    public errorMessage = "";
    public retailTraitData = [];
    public retailTraitMainData = [];
    public retailTraitsColumns = [];
    public selectedRetailTraits = [];
    public enteredZipCodes: any;
    public radiusMainData: any = [];
    public radiusData: any = [];
    public runBoolean = false;
    public filteredValues: any = {};
    public isMock: any;

    constructor(
        private retailTraitsHelper: RetailTraitsHelper,
        private _formBuilder: FormBuilder,
        private toasterService: ToasterService,
        private retailTraitService: RetailTraitsService,
        private exportToCsvService: ExportToCsvService,
        private localService: RetailTraitsComponentService,        
    ) { this.frmGroupMain = new FormGroup({}); }

    ngOnInit() {
        this.isMock = environment.mock;
        this.limit = this.retailTraitsHelper.tableLimit;
        this.runBoolean = false;
        this.retailTraitsColumns = [
            { name: "Store Name", prop: "storeName", width: 50 },
            { name: "Store Num", prop: "storeNum", width: 50 },
            { name: "Zip", prop: "zip", width: 50 },
            { name: "Radius", prop: "radius", width: 30 },
            { name: "Tech Analysis", prop: "techAnalysis", width: 60 }
        ];
        this.createSearchForm();
        this.createTableForm();
        // fetching values for drop downs from previously fired services
        if (this.localService.getParentData() && this.localService.getParentData().length > 0) {
        this.localService.getParentData().forEach(e1 => {
            this.parentData.push(e1)
        });
        this.parentMainData = [...this.parentData];
        this.localService.getBrandData().forEach(e3 => {
            this.brandsData.push(e3)
        });
        this.brandsMainData = [...this.brandsData];
        this.localService.getCarrierData().forEach(e2 => {
            this.carriersData.push(e2)
        });
        this.carriersMainData = [...this.carriersData];
        this.retrieveradius();
        }else{
        this.retrieveParent();
        }
    }

    // column level filters
    createTableForm() {
        this.tableFormGroup = this._formBuilder.group({
            storeName: [''],
            storeNum: [''],
            radius: [''],
            zip: [''],
            techAnalysis: ['']
        });
    }

    // search form
    createSearchForm() {
        this.frmGroupMain = this._formBuilder.group({
            parentId: ['', [Validators.required]],
            brand: [''],
            carrier: [''],
            zip: ['', [Validators.pattern("^[0-9\n ,]*$")]],
            runBrand: [],
            radius: []
        })
    }

    // Checkbox selection from search result table
    public onSelect(row) {
        this.selectedRetailTraits = [];
        if (row && row.selected) {
            for (let i = 0; i < row.selected.length; i++) {
                let obj = { ...row.selected[i] };
                this.selectedRetailTraits.push(obj);
            }
        }
        this.selectedRetailTraits = [...this.selectedRetailTraits];
        if(this.selected.length == 0){
        this.frmGroupMain.controls.runBrand.patchValue("");
        this.frmGroupMain.controls.radius.patchValue("");   
        this.runBoolean = false;         
        }
    }

    // to retrieve parents
    public retrieveParent() {
        this.showLoadingScreen = true;
        this.retailTraitService.getParents().pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_PARENT_ERROR_MESSAGE")
                    );
                this.parentMainData = data[0];
                this.parentData = [...this.parentMainData];
                this.retrieveCarriers();
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to retrieve carriers
    public retrieveCarriers() {
        this.showLoadingScreen = true;
        this.carriersData = [];
        this.carriersMainData = [];
        let obj: any = {};
        this.retailTraitService.getCarriers().pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_CARRIERS_ERROR_MESSAGE")
                    );
                this.carriersMainData = data[0];
                this.carriersData = [...this.carriersMainData];
                this.retrieveBrands();
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to retrieve brands
    public retrieveBrands() {
        this.brandsData = [];
        this.brandsMainData = [];
        this.showLoadingScreen = true;
        this.retailTraitService.getBrands().pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_BRANDS_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_BRANDS_ERROR_MESSAGE")
                    );
                this.brandsMainData = data[0];
                this.brandsData = [...this.brandsMainData];
                this.retrieveradius();
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to retrieve radius
    public retrieveradius() {
        this.radiusData = [];
        this.radiusMainData = [];
        this.showLoadingScreen = true;
        this.retailTraitService.getRadius().pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_RADIUS_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_RADIUS_ERROR_MESSAGE")
                    );
                this.radiusMainData = data[0];
                this.radiusData = [...this.radiusMainData];
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    /*
    * Creating search request to fetch locations
    */
    public createRetailStoreRequest(formData) {
        this.retailTraitMainData = [];
        this.retailTraitData = [];
        this.selectedRetailTraits = [];
        this.selected = [];
        let obj: any = {};
        if (formData.parentId)
            obj.parentId = formData.parentId;
        if (formData.brand)
            obj.brand = formData.brand;
        if (formData.carrier)
            obj.carrier = formData.carrier;
        if (this.enteredZipCodes)
            obj.zips = this.enteredZipCodes;
        this.searchRetailStores(obj);
        this.frmGroupMain.controls.runBrand.patchValue("");
        this.frmGroupMain.controls.radius.patchValue("");
        this.runBoolean = false;
        this.tableFormGroup.controls.storeName.patchValue([]);
        this.tableFormGroup.controls.storeNum.patchValue([]);
        this.tableFormGroup.controls.radius.patchValue([]);
        this.tableFormGroup.controls.techAnalysis.patchValue([]);
        this.tableFormGroup.controls.zip.patchValue([]);
        this.filteredValues = {};
    }

    /*
    * Fetching Locations
    */
    public searchRetailStores(requestData) {
        this.showLoadingScreen = true;
        this.retailTraitService.searchLocations(requestData).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_RETAIL_STORES_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                this.showLoadingScreen = false;
                if (data[0] && data[0].length == 0)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_RETAIL_STORES_ERROR_MESSAGE")
                    );
                this.retailTraitMainData = data[0];
                this.retailTraitData = [...this.retailTraitMainData];
                this.filterReportResults();
                this.generateFilters();
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to filter columns
    public filterReportResults(): void {
        const filterFormObject = this.tableFormGroup.value;
        this.filteredValues.storeNum = filterFormObject.storeNum;
        this.filteredValues.storeName = filterFormObject.storeName
        this.filteredValues.radius = filterFormObject.radius
        this.filteredValues.zip = filterFormObject.zip
        this.filteredValues.techAnalysis = filterFormObject.techAnalysis
        const newRows = Object.keys(filterFormObject).reduce((acc, key) => {
            if (!filterFormObject[key].length) return acc;
            const filteredRows = acc.filter(val => filterFormObject[key].indexOf(val[key]) > -1);
            return filteredRows;
        }, this.retailTraitMainData);

        this.retailTraitData = newRows;
    }

    public generateFilters(): void {
        this.filteredRows = Object.keys(this.retailTraitsColumns)
            .map(i => this.retailTraitsColumns[i].prop)
            .reduce((filterObject, columnName) => {
                const uniqueValuesPerRow = this.retailTraitData.reduce((set, row) => set.add(row[columnName]), new Set());
                let val:any = Array.from(uniqueValuesPerRow);
              if( /^[0-9]*$/.test(val[0])){
                   filterObject[columnName] = val.sort(function(a,b){return a - b});
              }else{
                   filterObject[columnName] =val.sort((a, b) => {
                    a = a || '';
                    b = b || '';
                    return a.localeCompare(b);
                });                   
              }
                return filterObject;
            }, {});
    }

    //Filter Table data based on all the columns
    public filterLocationTable(event) {
        let val :any;
        if(event.target)
             val = event.target.value.toLowerCase();
        else
             val= event.toLowerCase();
        this.filteredValues.mainTableFilter = val;
        // filter our data
        const temp = this.retailTraitMainData.filter(function (d) {
            return (d.zip ? d.zip.indexOf(val) !== -1 : !val) || !val
                || (d.radius ? d.radius.indexOf(val) !== -1 : !val) || !val
                || (d.storeName ? d.storeName.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.storeNum ? d.storeNum.indexOf(val) !== -1 : !val) || !val
                || (d.techAnalysis ? d.techAnalysis.toLowerCase().indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.retailTraitData = temp;
    }

    // to rest search form
    public reset() {
        this.frmGroupMain.reset();
        this.retailTraitMainData = [];
        this.retailTraitData = [];
        this.selectedRetailTraits = [];
        this.enteredZipCodes = "";
        this.errorMessage = "";
        this.selected = [];
        this.runBoolean = false;
        this.tableFormGroup.controls.storeName.patchValue([]);
        this.tableFormGroup.controls.storeNum.patchValue([]);
        this.tableFormGroup.controls.radius.patchValue([]);
        this.tableFormGroup.controls.techAnalysis.patchValue([]);
        this.tableFormGroup.controls.zip.patchValue([]);
        this.filteredValues = {};
    }

    public openedChange(rowData) {
        if (rowData == "carrierInput")
            this.carriersData = [...this.carriersMainData];
        else if (rowData == "brandInput")
            this.brandsData = [...this.brandsMainData];
        else if (rowData == "parentInput")
            this.parentData = [...this.parentMainData];
        else if (rowData == "radiusInput")
            this.radiusData = [...this.radiusMainData];
    }

    public onKey(value, rowData) {
        if (rowData == "carrierInput") {
            this.carriersData = [...this.carriersMainData];
            this.carriersData = this.search(value, "carrierList");
        } else if (rowData == "brandInput") {
            this.brandsData = [...this.brandsMainData];
            this.brandsData = this.search(value, "brandList");
        } else if (rowData == "parentInput") {
            this.parentData = [...this.parentMainData];
            this.parentData = this.search(value, "parentList");
        } else if (rowData == "radiusInput") {
            this.radiusData = [...this.radiusMainData];
            this.radiusData = this.search(value, "radiusList");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "carrierList")
            return this.carriersMainData.filter(option => option.carrier.toLowerCase().indexOf(filter) > -1);
        else if (choice == "brandList")
            return this.brandsMainData.filter(option => option.brand.toLowerCase().indexOf(filter) > -1);
        else if (choice == "parentList")
            return this.parentMainData.filter(option => option.retailer.toLowerCase().indexOf(filter) > -1);
        else if (choice == "radiusList")
            return this.radiusMainData.filter(option => option.toString().indexOf(filter) > -1);
    }

    // for Run Analysis
    public analyseTraits() {
        this.showLoadingScreen = true;
        let obj: any = {};
        let objIds = [];
        obj.brand = this.frmGroupMain.value.runBrand;
        obj.radius = this.frmGroupMain.value.radius;

        this.selectedRetailTraits.forEach(_e1 => {
            objIds.push(_e1.objId);
        })
        obj.objIds = objIds.toString();

        this.retailTraitService.analyseTraits(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
            (data: any) => {
                if (data[0] === null || data[0] === undefined) {
                    this.showLoadingScreen = false;
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RUN_ANALYSIS_ERROR_MESSAGE")
                    );
                    return;
                }
                if (data[0] && data[0].ERR) {
                    this.showLoadingScreen = false;
                    const commaSeperatedArr = data[0].ERR.split(",");
                    for (
                        let i = commaSeperatedArr.length - 1;
                        i >= 0;
                        i--
                    ) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                    return;
                }
                let techData = Object.keys(data[0]);
                this.selectedRetailTraits.forEach(e1 => {
                    techData.forEach(e2 => {
                        if (e1.objId == e2) {
                            e1.techAnalysis = data[0][e2]
                        }
                    })

                })
                this.retailTraitMainData.forEach(e1 => {
                    techData.forEach(e2 => {
                        if (e1.objId == e2) {
                            e1.techAnalysis = data[0][e2]
                        }
                    })

                })
                this.retailTraitData = [...this.retailTraitMainData];
                if(!this.isMock){
                this.generateFilters();
                this.tableFormGroup.controls.storeName.patchValue(this.filteredValues.storeName);
                this.tableFormGroup.controls.storeNum.patchValue(this.filteredValues.storeNum);
                this.tableFormGroup.controls.radius.patchValue(this.filteredValues.radius);
                this.tableFormGroup.controls.techAnalysis.patchValue(this.filteredValues.techAnalysis);
                this.tableFormGroup.controls.zip.patchValue(this.filteredValues.zip);
                this.filterReportResults();
                }
                if(this.filteredValues.mainTableFilter){
                    this.filterLocationTable(this.filteredValues.mainTableFilter);
                }
                this.showLoadingScreen = false;
                this.toasterService.showSuccessMessage(
                    this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_ANALYSE_TRAITS_SUCCESS_MESSAGE")
                );
            },
            (err: any) => {
                this.showLoadingScreen = false;
                if (err.error === undefined || err.error === null)
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                    );
                else if (err.error && err.error.ERR) {
                    const commaSeperatedArr = err.error.ERR.split(",");
                    for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                        if (commaSeperatedArr[i] != "")
                            this.toasterService.showErrorMessage(
                                commaSeperatedArr[i]
                            );
                    }
                }
                else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                    return;
                else this.toasterService.showErrorMessage(err.error);
            }
            );
    }

    // to Export CSV File
    exportToCSV() {
        let columns = ["STORENUM", "STORENAME", "ZIP", "RADIUS", "TECHANALYSIS"];

        this.selectedRetailTraits.forEach(_e1 => {
            _e1.STORENUM = _e1.storeNum;
            _e1.STORENAME = _e1.storeName;
            _e1.ZIP = _e1.zip;
            _e1.RADIUS = _e1.radius;
            _e1.TECHANALYSIS = _e1.techAnalysis;
        });

        this.selectedRetailTraits.forEach(_e1 => {
            let keys = Object.keys(_e1);
            keys.forEach(_e2 => {
                if (_e1[_e2] == null)
                    _e1[_e2] = "";
                else
                    _e1[_e2] = _e1[_e2];
            });
        });
        this.exportToCsvService.downloadFile(this.selectedRetailTraits, "Retail Analysis", columns);
    }

    public runAnalysis() {
        if (this.frmGroupMain.value.runBrand != "" && this.frmGroupMain.value.radius != "") {
            this.runBoolean = true;
        }

    }

    /*
     * Validate Zip Code text area
     * Validation Criteria- Limit -> 40,000 | Size -> 5 per zip code
     */
    zipCodeValidation(event) {
        this.errorMessage = "";
        //Splitting string based on the new line
        let zip = event.split("\n")
        let zipcodes: any = [];
        for (let i = 0; i < zip.length; i++) {
            //removing spaces
            zip[i] = zip[i].replace(/\s/g, "");
            //checking if any value with comma exists
            if (zip[i].indexOf(',') > -1) {
                //Sliting String based on the comma
                let commaSeperatedArr = zip[i].split(",");
                /*
                 * Validate Zip Code based on the length
                 * if Zip Codes are valid then pushing into 'zipcodes' array
                */
                for (let j = 0; j < commaSeperatedArr.length; j++) {
                    if (commaSeperatedArr[j].length != 0) {
                        if (commaSeperatedArr[j].length < 5) {
                            this.errorMessage = "Zip Code cannot have less than 5 digits."
                            break;
                        } else if (commaSeperatedArr[j].length > 5) {
                            this.errorMessage = "Zip Code cannot have more than 5 digits."
                            break;
                        } else {
                            zipcodes.push(commaSeperatedArr[j]);
                            //check if zip codes exceeds 40,000
                            if (zipcodes.length > 40000) {
                                this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                                break;
                            }
                        }
                    }
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length < 5) {
                if (zip[i].length != 0) {
                    this.errorMessage = "Zip Code cannot have less than 5 digits."
                    break;
                }
            }//Validate Zip Code based on the length 
            else if (zip[i].length > 5) {
                this.errorMessage = "Zip Code cannot have more than 5 digits."
                break;
            }//if Zip Codes are valid then pushing into 'zipcodes' array
            else {
                zipcodes.push(zip[i]);
                //check if zip codes exceeds 40,000
                if (zipcodes.length > 40000) {
                    this.errorMessage = "Zip Codes cannot exceed 40,000 limit"
                    break;
                }
            }
        }
        let returnedZip: any = [];
        this.enteredZipCodes = "";
        if (this.errorMessage == "") {
            zipcodes.forEach(element => {
                if (element.length != 0)
                    returnedZip.push(element);
            });
            this.enteredZipCodes = returnedZip.toString();
        } else {
            this.enteredZipCodes = null;
        }
    }

}

