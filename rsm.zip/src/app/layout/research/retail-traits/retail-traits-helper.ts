import { Injectable } from '@angular/core';

@Injectable()
export class RetailTraitsHelper {
  public 'dbEnv': String;
  public tableLimit = 20;
  public privilegedUser: any;

  constructor() { }

  public setDbEnv(dbEnv) {
    this.dbEnv = dbEnv;
  }

  public getDbEnv() {
    return this.dbEnv;
  }

  public checkRequestObject(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkRequestObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  public checkRequestObjectSetToEmpty(obj) {
    Object.keys(obj).forEach(key => {
      if (!obj[key]) obj[key] = '';
    });
    return obj;
  }

  public checkReqForObjectInsideObject(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key];
    });
    return obj;
  }

  public checkReqForObjectInsideObjectSetToNull(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObject(obj[key])
        if (innerArray === undefined) {
          obj[key] = null;
        }
      }
      else if (!obj[key]) obj[key] = null;
    });
    return obj;
  }

  checkRequestObjectForArray(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        const innerArray = this.checkRequestObjectForArray(obj[key])
        if (innerArray === undefined) {
          delete obj[key];
          obj.pop();
        } else if (innerArray && innerArray.constructor === Array && innerArray.length === 0) {
          delete obj[key]
        }
      }
      else if (!obj[key]) delete obj[key]
    });
    return Object.keys(obj).length > 0 || obj instanceof Array ? obj : undefined;
  };

  public carrierMaintenanceComponentConstantObject = {

    //Common
    "TRACFONE_DEFAULT_ERROR_MESSAGE": "Unable to process request",
    "TRACFONE_COMPLETE_PREVIOUS_OPERATION_ERROR_MESSAGE": "Please complete previous operation",
    "TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE": "Please fix validation errors",
    "TRACFONE_CLOSE_STORE_CONFIRM_MESSAGE": "Are you sure you want to close these stores ?",
    "TRACFONE_UPLOAD_TEMPLATE_NO_DATA_ERROR_MESSAGE": "There is no data to upload in this file",
    "TRACFONE_APPROVE_REJECT_TRAITS_CONFIRM_MESSAGE": "Please confirm whether you would like to approve or reject this change.",
    "TRACFONE_UPLOAD_FILE_ERROR_MESSAGE" : "Please select a valid file to upload",
    "TRACFONE_CLOSE_LAST_STORE_CONFIRM_MESSAGE": "Are you sure you want to close all the stores associated to the parent ?",

    //Carriers
    "TRACFONE_RETRIEVE_CARRIERS_ERROR_MESSAGE": "Unable to retrieve Carriers",
    "TRACFONE_SEARCH_CARRIERS_ERROR_MESSAGE": "No Carriers found",

    //Brands
    "TRACFONE_RETRIEVE_BRANDS_ERROR_MESSAGE": "Unable to retrieve Brands",
    "TRACFONE_SEARCH_BRANDS_ERROR_MESSAGE": "No Brands found",

    // Parent admin
    "TRACFONE_RETRIEVE_PARENT_ERROR_MESSAGE": "Unable to retrieve Parent",
    "TRACFONE_SEARCH_PARENT_ERROR_MESSAGE": "No Parent found",

    //Retail Master
    "TRACFONE_RETRIEVE_MASTER_ERROR_MESSAGE": "Unable to retrieve Retail Masters",
    "TRACFONE_SEARCH_MASTER_ERROR_MESSAGE": "No Retail Masters found",

    //serach location
    "TRACFONE_RETRIEVE_LOCATION_ERROR_MESSAGE": "Unable to retrieve Locations",
    "TRACFONE_SEARCH_LOCATION_ERROR_MESSAGE": "No Locations found",
    "TRACFONE_UPDATE_LOCATION_ERROR_MESSAGE": "Unable to update Retail Stores",
    "TRACFONE_UPDATE_LOCATION_SUCCESS_MESSAGE": "Retail Stores have been updated succesfully",
    "TRACFONE_DATE_FORMAT_ERROR_MESSAGE" : "Please choose a To Date that is after the From Date",
    "TRACFONE_DATE_SELECTION_ERROR_MESSAGE" : "Please choose a date range that is for a period of one month",  
    "TRACFONE_RETRIEVE_CLOSED_STORES_ERROR_MESSAGE": "Unable to retrieve Closed Stores",
    "TRACFONE_SEARCH_CLOSED_STORES_ERROR_MESSAGE": "No Closed Stores found for the date range selected.",  

    //view Availability
    "TRACFONE_RETRIEVE_VIEW_AVAILABILITY_ERROR_MESSAGE": "Unable to retrieve Availability",
    "TRACFONE_SEARCH_VIEW_AVAILABILITY_ERROR_MESSAGE": "No Availability found",

    //Close Store
    "TRACFONE_CLOSE_STORE_ERROR_MESSAGE": "Unable to close Stores",
    "TRACFONE_CLOSER_STORE_SUCCESS_MESSAGE": "Stores has been closed successfully",
    "TRACFONE_COUNT_STORE_ERROR_MESSAGE" : "Unable to count Stores",

    //Reopen Stores
    "TRACFONE_REOPEN_STORE_ERROR_MESSAGE": "Unable to reopen Stores",
    "TRACFONE_REOPEN_STORE_SUCCESS_MESSAGE": "Stores has been reopened successfully",

    //Delete Stores
    "TRACFONE_DELETE_STORE_ERROR_MESSAGE": "Unable to delete Stores",
    "TRACFONE_DELETE_STORE_SUCCESS_MESSAGE": "Stores have been deleted successfully",

    //Retail Analysis
    "TRACFONE_RUN_ANALYSIS_ERROR_MESSAGE": "Unable to analyse Traits",
    "TRACFONE_RETRIEVE_RADIUS_ERROR_MESSAGE": "Unable to retrieve Radius",
    "TRACFONE_SEARCH_RADIUS_ERROR_MESSAGE": "No Radius found",
    "TRACFONE_RETRIEVE_RETAIL_STORES_ERROR_MESSAGE": "Unable to search Retail Stores",
    "TRACFONE_SEARCH_RETAIL_STORES_ERROR_MESSAGE": "No Retail Stores found",
    "TRACFONE_ANALYSE_TRAITS_SUCCESS_MESSAGE": "Run Analysis Completed successfully",

    // run trait
    "TRACFONE_RUN_TRAIT_ERROR_MESSAGE": "Unable to Run Trait",
    "TRACFONE_RUN_TRAIT_SUCCESS_MESSAGE": "Trait Run successfully",
    "TRACFONE_SELECT_CARRIER_TECH_ERROR_MESSAGE" : "Please select Carrier Tech",
  }

  public getTracfoneConstantMethod(msg) {
    return this.carrierMaintenanceComponentConstantObject[msg];
  }
}
