import { Component, ViewEncapsulation, OnInit, ViewChild } from "@angular/core";
import { ExportToCsvService } from "../../../../Services/export-to-csv.service";
import { ImportFromCsvService } from "../../../../Services/import-from-csv.service";
import { RetailTraitsHelper } from "../retail-traits-helper";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { RetailTraitsService } from "../../../../Services/retailTraits.service";
import { takeUntil } from "rxjs/operators";
import { ToasterService } from "../../../../Services/toaster.service";
import { Subject } from "rxjs";
import { RetailTraitsComponentService } from "../retail-traits.service";

@Component({
    selector: "add-stores",
    templateUrl: "./add-stores.component.html",
    styleUrls: ["./add-stores.component.scss",
        '../../../components/ngxtable/material.scss',
        '../../../components/ngxtable/datatable.component.scss',
        '../../../components/ngxtable/icons.css',
        '../../../components/ngxtable/app.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [ExportToCsvService, ImportFromCsvService]
})

export class AddNewStoresComponent implements OnInit {

    public exportColumns = [];
    public newStoreData = [];
    public newStoreMainData = [];
    public filename: string = null;
    public fileContent: Boolean;
    public showLoadingScreen: boolean;
    public tableColmns = [];
    public limit: any;
    public frmGroupMain: FormGroup;
    public parentData: any = [];
    public parentMainData: any = [];
    public unsubscribe = new Subject<void>();
    public retailMasterMainData = [];
    public retailMasterData = [];
    public showUpload: boolean = true;
    public selectedParent: any;
    public selectedStore: any;
    public openStoreSuccessBoolean: boolean = false
    public insertBoolean: boolean = false;
    public multiColumnEditSection = false;
    @ViewChild('multicolumnEditCheckbox') private multicolumnEditCheckbox: any;
    public multiColumnEditColumns = [];
    readonly EXPORT_FILE_NAME = "new_stores";
    public bulkEditFormGroup: FormGroup;

    constructor(
        private exportToCsvService: ExportToCsvService,
        private importFromCsvService: ImportFromCsvService,
        private retailTraitsHelper: RetailTraitsHelper,
        private _formBuilder: FormBuilder,
        private retailTraitsService: RetailTraitsService,
        private toasterService: ToasterService,
        private localService: RetailTraitsComponentService
    ) { }

    ngOnInit() {
        this.multiColumnEditColumns = [];

        //Getting parent data from local service
        this.parentMainData = [...this.localService.getParentData()];
        this.parentData = [...this.parentMainData];

        this.limit = this.retailTraitsHelper.tableLimit;
        this.exportColumns = ["STORENUM", "ZIP", "RADIUS"];
        this.tableColmns = [
            { name: "Store Num", prop: "storeNum", width: 100 },
            { name: "Zip Code", prop: "zip", width: 100 },
            { name: "Radius", prop: "radius", width: 100 }
        ];
        this.multiColumnEditColumns = [...this.tableColmns];
        this.createForm();
        this.createBulkEditForm();
    }

    createForm() {
        this.frmGroupMain = this._formBuilder.group({
            parentId: ['', [Validators.required]],
            storeName: ['', [Validators.required]]
        });
    }

    createBulkEditForm() {
        this.bulkEditFormGroup = this._formBuilder.group({
            radius: ['', [Validators.required, Validators.pattern("^[0-9]*$")]]
        })
    }
    //Get Retail Master based on selected Parent Id
    getRetailMaster(parentId) {
        this.showLoadingScreen = true;
        this.retailMasterMainData = [];
        this.retailMasterData = [];
        this.retailTraitsService.getMaster(parentId).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_MASTER_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    if (data[0] && data[0].length == 0)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_SEARCH_MASTER_ERROR_MESSAGE")
                        );
                    this.retailMasterMainData = data[0];
                    this.retailMasterData = [...this.retailMasterMainData];
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    //Used to Download Template
    exportToCSV() {
        this.exportToCsvService.downloadFile([], this.EXPORT_FILE_NAME, this.exportColumns);
    }

    //Read File and show data on the table
    public changeListener(files: FileList) {
        if (files && files.length > 0) {
            this.fileContent = true;
            let file: File = files.item(0);
            let name = file.name
            var ext = name.substring(name.lastIndexOf('.') + 1);
            if (ext.toLowerCase() == 'csv') {
                this.filename = name.substr(0, name.lastIndexOf("."));
                if (this.filename.split(" ")[0] != "new_stores") {
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPLOAD_FILE_ERROR_MESSAGE"))
                    return
                }
            } else {
                this.toasterService.showErrorMessage(
                    this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPLOAD_FILE_ERROR_MESSAGE"))
                return
            }
            let reader: FileReader = new FileReader();
            reader.readAsText(file);
            reader.onload = (e) => {
                let storeData = this.importFromCsvService.csvToArray(reader.result);
                this.openStoreSuccessBoolean = false;
                if (storeData.length == 0) {
                    this.toasterService.showErrorMessage(
                        this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPLOAD_TEMPLATE_NO_DATA_ERROR_MESSAGE")
                    );
                } else {
                    if (Object.keys(storeData[0])[1] != "STORENUM" &&
                        Object.keys(storeData[0])[2] != "ZIP" &&
                        Object.keys(storeData[0])[3] != "RADIUS"
                    ) {
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_UPLOAD_FILE_ERROR_MESSAGE"))
                        return
                    }
                    storeData.forEach(_e1 => {
                        _e1.storeNum = _e1.STORENUM;
                        _e1.zip = _e1.ZIP;
                        _e1.radius = _e1.RADIUS;
                    });
                    this.newStoreData = [...this.checkUploadedData(storeData)];
                }
            }
        }
    }

    //Removes file and table from the screen
    public removeFile() {
        this.fileContent = false;
        this.filename = null;
        this.newStoreData = [];
        this.newStoreMainData = [];
    }

    public resetForm() {
        this.frmGroupMain.reset();
        this.retailMasterData = [];
        this.retailMasterMainData = [];
        this.showUpload = true
    }

    //Removes Row from the table
    deleteRow(row, rowIndex) {
        this.newStoreMainData.forEach((data, key) => {
            if (row.rowNum == data.rowNum) {
                this.newStoreMainData.splice(key, 1);
            }
        });
        this.newStoreData = [...this.newStoreMainData];
    }

    //inline values changes
    public editValueChanged(event, column, row, oldValue) {
        for (let i = 0; i < this.newStoreMainData.length; i++) {
            if (this.newStoreMainData[i].rowNum == row.rowNum) {
                this.newStoreMainData[i][column] = event.target.value;
            }
        }
        this.newStoreData = [...this.newStoreMainData];
    }

    //Open Stores
    public openStores() {
        if (document.getElementsByClassName("alert") && document.getElementsByClassName("alert").length > 0) {
            this.toasterService.showErrorMessage(
                this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_COMPLETE_VALIDATION_ERROR_MESSAGE")
            )
            return;
        }
        this.showLoadingScreen = true;
        let obj: any = [];
        obj = [...this.newStoreMainData];
        obj.forEach(element => {
            element.parentId = this.selectedParent;
            element.storeName = this.selectedStore;
        });
        obj.forEach(element => {
            delete element['S.NO'];
            delete element.rowNum;
            delete element.STORENUM;
            delete element.ZIP;
            delete element.RADIUS;
        });
        this.retailTraitsService.openStores(obj).pipe(takeUntil(this.unsubscribe))
            .subscribe(
                (data: any) => {
                    if (data[0] === null || data[0] === undefined) {
                        this.showLoadingScreen = false;
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_RETRIEVE_MASTER_ERROR_MESSAGE")
                        );
                        return;
                    }
                    if (data[0] && data[0].ERR) {
                        this.showLoadingScreen = false;
                        const commaSeperatedArr = data[0].ERR.split(",");
                        for (
                            let i = commaSeperatedArr.length - 1;
                            i >= 0;
                            i--
                        ) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                        return;
                    }
                    this.showLoadingScreen = false;
                    this.openStoreSuccessBoolean = true;
                    this.removeFile();
                    this.resetForm();
                },
                (err: any) => {
                    this.showLoadingScreen = false;
                    if (err.error === undefined || err.error === null)
                        this.toasterService.showErrorMessage(
                            this.retailTraitsHelper.getTracfoneConstantMethod("TRACFONE_DEFAULT_ERROR_MESSAGE")
                        );
                    else if (err.error && err.error.ERR) {
                        const commaSeperatedArr = err.error.ERR.split(",");
                        for (let i = commaSeperatedArr.length - 1; i >= 0; i--) {
                            if (commaSeperatedArr[i] != "")
                                this.toasterService.showErrorMessage(
                                    commaSeperatedArr[i]
                                );
                        }
                    }
                    else if (err.error.errorCode == "AE01" && err.error.httpCode == 401)
                        return;
                    else this.toasterService.showErrorMessage(err.error);
                }
            );
    }

    public openedChange(rowData) {
        if (rowData == "masterInput")
            this.retailMasterData = [...this.retailMasterMainData];
        else if (rowData == "parentInput")
            this.parentData = [...this.parentMainData];
    }

    public onKey(value, rowData) {
        if (rowData == "masterInput") {
            this.retailMasterData = [...this.retailMasterMainData];
            this.retailMasterData = this.search(value, "masterList");
        } else if (rowData == "parentInput") {
            this.parentData = [...this.parentMainData];
            this.parentData = this.search(value, "parentList");
        }
    }

    //filter for dropdown
    public search(value: string, choice: string) {
        let filter = value.toLowerCase();
        if (choice == "masterList")
            return this.retailMasterMainData.filter(option => option.storeName.toLowerCase().indexOf(filter) > -1);
        else if (choice == "parentList")
            return this.parentMainData.filter(option => option.retailer.toLowerCase().indexOf(filter) > -1
                || option.objId.toLowerCase().indexOf(filter) > -1);
    }

    //Getting Values of Parent and Store Name from Dropdowns
    parentStoreNameValues(parentId, storeName) {
        this.selectedParent = parentId;
        this.selectedStore = storeName;
        if (this.selectedParent && this.selectedStore) {
            this.showUpload = false
        }
    }

    //Remove Success Message
    removeOpenStoreBoolean() {
        this.openStoreSuccessBoolean = false;
    }

    public multiColumnEdit(isChecked) {
        if (isChecked.checked) {
            this.bulkEditFormGroup.reset();
            this.multiColumnEditSection = true;
        }
        else {
            this.bulkEditFormGroup.reset();
            this.multiColumnEditSection = false;
        }
    }

    //update bulk values
    public updatemultiColumnEdit(formData) {
        for (let i = 0; i < this.newStoreMainData.length; i++) {
            this.newStoreMainData[i]['radius'] = formData.radius;
        }
        this.newStoreData = [...this.newStoreMainData];
        this.multicolumnEditCheckbox.checked = false;
        this.multiColumnEditSection = false;
        this.bulkEditFormGroup.reset();
    }

    //Filter for search table
    public filterNewStoreTable(event) {
        const val = event.target.value.toLowerCase();
        // filter our data
        const temp = this.newStoreMainData.filter(function (d) {
            return (d.radius ? d.radius.indexOf(val) !== -1 : !val) || !val
                || (d.rowNum ? d.rowNum.indexOf(val) !== -1 : !val) || !val
                || (d.zip ? d.zip.toLowerCase().indexOf(val) !== -1 : !val) || !val
                || (d.storeNum ? d.storeNum.indexOf(val) !== -1 : !val) || !val
        });
        // update the rows
        this.newStoreData = temp;
    }

    public checkUploadedData(data) {
        let errorData = [];
        let successData = [];
        let radiusData: any;
        data.forEach(element => {
            element.rowNum = element['S.NO'];
        });
        data.forEach(element => {
            //Checking length of radius,zip and storeNum
            if (element.ZIP.length != 0 && element.RADIUS.length != 0 && element.STORENUM.length != 0) {
                radiusData = Number(element.RADIUS);
                if (!Number.isNaN(radiusData))
                    element.RADIUS = radiusData;
                //Checking if enterd values are number or not
                if (/^\d+$/.test(element.RADIUS) && /^\d+$/.test(element.STORENUM) && /^\d+$/.test(element.ZIP)) {
                    //Checking if zip code length is 5 or not
                    if (element.ZIP.length == 5) {
                        element.RADIUS = element.RADIUS.toString();
                        successData.push(element);
                    }
                    //if zipcodes length check fails 
                    else {
                        element.RADIUS = element.RADIUS.toString();
                        errorData.push(element);
                    }
                }
                //if number check fails 
                else {
                    element.RADIUS = element.RADIUS.toString();
                    errorData.push(element);
                }
            }
            //if length check fails 
            else
                errorData.push(element);
        });
        this.newStoreMainData = [...errorData, ...successData];
        return this.newStoreMainData;
    }
}