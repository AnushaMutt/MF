import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RetailTraitsComponent } from './retail-traits.component';

const routes: Routes = [
	{
		path: '',
	    component: RetailTraitsComponent
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RetailTraitsRoutingModule { }
