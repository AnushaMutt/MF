// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// ng build --env=prod (angular2)
// ng build --configuration=prod (angular6+)
// then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environmentLocal = {
  production: false,
  mock:false,
  HTTP_URL_APIFULL: "https://sit1apifull.tracfone.com/oauth/ro",
  HTTP_URL_ADMIN: "http://localhost:8080/tracfone/main/",
  HTTP_URL_REPORT: "http://localhost:8080/tracfone/reports/",
  HTTP_URL_ACTION: "http://localhost:8080/tracfone/action/",
  HTTP_URL_TOOLS: "http://localhost:8080/tracfone/tool/",
  HTTP_URL_USER_INQUIRY: "http://localhost:8080/tracfone/userinquiry/",
  HTTP_URL_TRANSACTION: "http://localhost:8080/tracfone/transactions/",
  HTTP_URL_CARRIER: "http://localhost:8080/tracfone/carriers/",
  HTTP_URL_SERVICERATEPLANWIZARD: "http://localhost:8080/tracfone/rateplan/rateplanmaintenance/",
  HTTP_URL_WIZARD: "http://localhost:8080/tracfone/wizard/",
  HTTP_URL_SERVICEPLANVIEW: "http://localhost:8080/tracfone/serviceplan/servicerateplanview/",
  HTTP_URL_MIRRORSERVICEPLANWIZARD: "http://localhost:8080/tracfone/mirrorserviceplan/serviceplanwizard/",
  HTTP_URL_CARRIERMAINTENANCEWIZARD: "http://localhost:8080/tracfone/carrier/carriermaintenance/",
  HTTP_URL_RETAILSTOREWIZARD: "http://localhost:8080/tracfone/admin/retailmanagement/",
  HTTP_URL_RETAILTRAITSANALYSIS: "http://localhost:8080/tracfone/traitanalysis/retailmanagementview/",
  RETAILSTOREWIZARD_DATABASE: [{"description": "SIT", "id": 3 ,"name": "prod"}],
  HTTP_URL_CARRIEROUTAGE: "http://localhost:8080/tracfone/carrieroutagemanagement/carrieroutage/",
  HTTP_URL_USER_REPORTING: "http://localhost:8080/tracfone/dashboard/userreporting/",
  HTTP_URL_THROTTLE_TRANS : "http://localhost:8080/tracfone/throttle/throttletransactions/",
  HTTP_URL_PCRF_TRANS : "http://localhost:8080/tracfone/pcrf/pcrftransactions/",
  HTTP_URL_DB2_IG_VIEW : "http://localhost:8080/tracfone/db2ig/db2igview/",
  HTTP_URL_DB2_IG_MAINTENANCE : "http://localhost:8080/tracfone/db2igupdate/db2igmaintenance/",
  HTTP_URL_IG_CONFIG: "http://localhost:8080/tracfone/igcarrierconfig/igconfig/",
  HTTP_URL_IG_CONFIG_MAINTENANCE : "http://localhost:8080/tracfone/igcarrierconfigupdate/igconfigmaintenance/",
  HTTP_URL_ZIP2TECH_MAINTENANCE : "http://localhost:8080/tracfone/zip2tech/zip2techmaintenance/",
  HTTP_URL_CARRIER_ZONES_DEPLOYMENT : "http://localhost:8080/tracfone/czdeploy/carrierzonesdplymnt/",
  HTTP_URL_MULE: "http://dp-sit-mulecarrier",
  HTTP_URL_BALANCE_INQUIRY: "http://localhost:8905"
};
