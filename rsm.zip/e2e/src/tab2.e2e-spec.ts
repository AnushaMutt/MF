import { AppAddStorePage } from './tab2.po';
import { browser, by, element } from 'protractor';

describe('workspace-project App', () => {
    let page: AppAddStorePage;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

    beforeEach(() => {
        page = new AppAddStorePage();
    });

    it('check Add Stores tab label', () => {
        browser.ignoreSynchronization = true;
        // page.navigateTo();
        browser.sleep(2000)
        let elems = element.all(by.css('.mat-tab-label'))
        elems.get(1).click();
        expect(page.checkTab()).toMatch('Add New Stores')
    });

    it('required validation for parent', () => {
        browser.sleep(1000)
        element(by.id('parent')).click();
        element(by.tagName('body')).click();
        expect(page.validateParent()).toEqual('Parent is required.');
        browser.sleep(100)
    });

    it('select parent', () => {
        browser.sleep(100)
        element(by.id('parent')).click();
        element(by.cssContainingText('mat-option .mat-option-text', 'AAFES_TRAITS')).click();
        expect(page.selectParent()).toEqual('AAFES_TRAITS');
        element(by.tagName('body')).click();
    });

    it('required validation for store name', () => {
        browser.sleep(100)
        element(by.id('storeName')).click();
        element(by.tagName('body')).click();
        expect(page.validateParent()).toEqual('Store Name is required.');
        browser.sleep(100)
    });

    it('select store name', () => {
        browser.sleep(100)
        element(by.id('storeName')).click();
        element(by.cssContainingText('mat-option .mat-option-text', 'AAFES')).click();
        expect(page.selectStore()).toEqual('AAFES');
        element(by.tagName('body')).click();
    });

    it('check file upload header', () => {
        browser.sleep(100)
        expect(page.checkHeader()).toEqual('Upload your File');
    });

    it('select file icon', () => {
        browser.sleep(100)
        expect(page.selectFileIcon()).toEqual('Select a file');
    });

    it('csv icon', () => {
        browser.sleep(100)
        expect(page.exportFileIcon()).toEqual('Download Template');
    });

    // afterEach(async () => {
    //   // Assert that there are no errors emitted from the browser
    //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    //   expect(logs).not.toContain(jasmine.objectContaining({
    //     level: logging.Level.SEVERE,
    //   } as logging.Entry));
    // });
});
