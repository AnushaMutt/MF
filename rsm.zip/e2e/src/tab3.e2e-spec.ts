import { AppRetailAnalysisPage } from './tab3.pop';
import { browser, by, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppRetailAnalysisPage;
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

  beforeEach(() => {
    page = new AppRetailAnalysisPage();
  });

  it('check View Retail Traits tab label', () => {
    browser.ignoreSynchronization = true;
    // page.navigateTo();
    browser.sleep(2000)
    let elems = element.all(by.css('.mat-tab-label'))
    browser.sleep(200)
    elems.get(2).click();
    expect(page.checkTab()).toMatch('Retail Analysis')
  });

  it('select parent', () => {
    browser.sleep(1000)
    element(by.id('parent')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'AAFES_TRAITS')).click();
    expect(page.selectParent()).toEqual('AAFES_TRAITS');
    element(by.tagName('body')).click();
  });

  it('select brand', () => {
    browser.sleep(100)
    element(by.id('brand')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'BYOP')).click();
    expect(page.selectBrand()).toEqual('BYOP');
    element(by.tagName('body')).click();
  });

  it('enter zip code', () => {
    element(by.tagName('body')).click();
    browser.sleep(100)
    page.enterZipCode('12345');
    expect(page.checkZipCode()).toEqual('12345');
  });

  it('search results', () => {
    browser.sleep(100)
    element(by.id('search')).click();
    expect(element(by.tagName('ngx-datatable')).isPresent()).toBeTruthy();
    browser.sleep(100)
  });

  it('select search results', () => {
    browser.sleep(100)
    let elems = element.all(by.css('input[type=checkbox]'))
    elems.get(1).click();
    elems.get(2).click();
  });

  it('select brand', () => {
    browser.sleep(100)
    element(by.id('brandValue')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'BYOP')).click();
    expect(page.selectBrandForAnalysis()).toEqual('BYOP');
    element(by.tagName('body')).click();
  });

  it('select radius', () => {
    browser.sleep(1000)
    element(by.id('radiusValue')).click();
    element(by.cssContainingText('mat-option .mat-option-text', '5')).click();
    expect(page.selectRadiusForAnalysis()).toEqual('5');
    element(by.tagName('body')).click();
  });

  it('run analysis', () => {
    browser.sleep(1000)
    element(by.id('runButton')).click();
    expect(page.runAnalysis()).toMatch('Run Analysis Completed successfully')
  });

  // afterEach(async () => {
  //   // Assert that there are no errors emitted from the browser
  //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
  //   expect(logs).not.toContain(jasmine.objectContaining({
  //     level: logging.Level.SEVERE,
  //   } as logging.Entry));
  // });
});
