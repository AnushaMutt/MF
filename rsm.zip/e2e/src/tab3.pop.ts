import { browser, by, element } from 'protractor';

export class AppRetailAnalysisPage {
  navigateTo(): Promise<unknown> {
    return browser.get(browser.baseUrl) as Promise<unknown>;
  }

  checkTab() {
    return element.all(by.css('#mat-tab-label-0-2 > div')).getText() as Promise<string>;
  }

  selectParent() {
    return element(by.id('parent')).getText() as Promise<string>;
  }

  selectCarrier() {
    return element(by.id('carrier')).getText() as Promise<string>;
  }

  selectBrand() {
    return element(by.id('brand')).getText() as Promise<string>;
  }

  enterZipCode(column: string) {
    return element(by.id('zipCode')).sendKeys(column);
  }

  checkZipCode() {
    return element(by.tagName('textarea#zipCode')).getAttribute('value') as Promise<string>;
  }

  selectBrandForAnalysis() {
    return element(by.id('brandValue')).getText() as Promise<string>;
  }

  selectRadiusForAnalysis() {
    return element(by.id('radiusValue')).getText() as Promise<string>;
  }

  runAnalysis() {
    return element.all(by.css('div.ui-toast-detail')).getText() as Promise<string>;
  }


}
