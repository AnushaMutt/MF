import { AppViewTraitsPage } from './tab1.po';
import { browser, by, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppViewTraitsPage;
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

  beforeEach(() => {
    page = new AppViewTraitsPage();
  });

  it('check View Retail Traits tab label', () => {
    browser.ignoreSynchronization = true;
    page.navigateTo();
    expect(page.checkTab()).toMatch('View Retail Traits')
  });

  it('select parent', () => {
    browser.sleep(100)
    element(by.id('parent')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'AAFES_TRAITS')).click();
    expect(page.selectParent()).toEqual('AAFES_TRAITS');
    element(by.tagName('body')).click();
  });

  it('select brand', () => {
    browser.sleep(100)
    element(by.id('brand')).click();
    element(by.cssContainingText('mat-option .mat-option-text', 'BYOP')).click();
    expect(page.selectBrand()).toEqual('BYOP');
    element(by.tagName('body')).click();
  });

  it('enter zip code', () => {
    browser.sleep(100)
    page.enterZipCode('12345');
    expect(page.checkZipCode()).toEqual('12345');
  });

  it('available columns accordian', () => {
    browser.sleep(100)
    element(by.tagName('body')).click();
    expect(page.checkAccordian()).toEqual('Available Columns for Traits Details');
  });

  it('search results', () => {
    browser.sleep(100)
    element(by.id('search')).click();
    expect(element(by.tagName('ngx-datatable')).isPresent()).toBeTruthy();
    browser.sleep(100)
  });

  it('click edit icon', () => {
    browser.sleep(100)
    browser.executeScript('window.scrollTo(0,400)')
    element(by.className('fa fa-pencil')).click();
    browser.sleep(100)
  });

  it('update radius', () => {
    browser.sleep(100)
    element.all(by.id('radius0')).clear();
    page.updateradius('10');
    element(by.className('fa fa-floppy-o')).click();
    expect(page.update()).toMatch('Retail Stores have been updated succesfully')
  });

  it('open details', () => {
    browser.sleep(100)
    element(by.className('pi pi-chevron-right')).click();
    expect(element(by.tagName('ngx-datatable')).isPresent()).toBeTruthy();
    browser.executeScript('window.scrollTo(0,0)')
    browser.sleep(5000)
  });

});
