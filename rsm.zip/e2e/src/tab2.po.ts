import { browser, by, element } from 'protractor';

export class AppAddStorePage {
  navigateTo(): Promise<unknown> {
    return browser.get(browser.baseUrl) as Promise<unknown>;
  }

  checkTab() {
    return element.all(by.css('#mat-tab-label-0-1 > div')).getText() as Promise<string>;
  }

  validateParent() {
    return element(by.className('alert-danger')).getText() as Promise<string>;
  }

  selectParent() {
    return element(by.id('parent')).getText() as Promise<string>;
  }

  validateStore() {
    return element(by.className('alert-danger')).getText() as Promise<string>;
  }

  selectStore() {
    return element(by.id('storeName')).getText() as Promise<string>;
  }

  checkHeader() {
    return element(by.tagName('h4')).getText() as Promise<string>;
  }

  selectFileIcon() {
    return element(by.id('tooltipText')).getAttribute('matTooltip') as Promise<string>;
  }

  exportFileIcon() {
    return element(by.id('exportText')).getAttribute('matTooltip') as Promise<string>;
  }

}
